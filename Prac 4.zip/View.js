document.addEventListener("DOMContentLoaded", function() {
  // Get the radio buttons for theme selection
  var lightRadio = document.querySelector('input[value="light"]');
  var darkRadio = document.querySelector('input[value="dark"]');

  // Listen for click event on the radio buttons
  lightRadio.addEventListener('click', function(event) {
      event.preventDefault();
    // Set the theme to light when the light radio button is clicked
      //   document.documentElement.setAttribute('data-theme', 'light');
      console.log("Light clicked");
      // send request to api to change the theme in the database 
      fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
      
          // type "changeTheme", theme "newTheme"
          var Obj = {}
          Obj['type'] = "ChangeTheme";
          Obj['NewTheme'] = "light";
          Obj['apikey'] = data.apikey;
          var jsonObj = JSON.stringify(Obj);

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function() {
              if(xhr.readyState === XMLHttpRequest.DONE) {
                          
                  //console.log(responseData);
                    if(xhr.status === 200) {
                      // update was successfull

                      console.log("Update was successfull");
                    } else {
                      console.log("Update was not successfull");
                    }
              }
          };
        
          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);

          this.checked = true;
      location.reload();
          })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
  });

  darkRadio.addEventListener('click', function(event) {
      event.preventDefault();
    // Set the theme to dark when the dark radio button is clicked
    console.log("Dark clicked");
  //   document.documentElement.setAttribute('data-theme', 'dark');
  fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
      
          // type "changeTheme", theme "newTheme"
          var Obj = {}
          Obj['type'] = "ChangeTheme";
          Obj['NewTheme'] = "dark";
          Obj['apikey'] = data.apikey;
          var jsonObj = JSON.stringify(Obj);

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function() {
              if(xhr.readyState === XMLHttpRequest.DONE) {
                          
                  //console.log(responseData);
                    if(xhr.status === 200) {
                      // update was successfull
                      console.log("Update was successfull");
                    } else {
                      console.log("Update was not successfull");
                    }
              }
          };
        
          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);

          this.checked = true;
      location.reload();
          })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
      
  });
});

var myObj = {
  "type": "GetAllListings",
  "return": "*"
}

document.addEventListener('DOMContentLoaded', function() {
  setTimeout(function() {
      var loadingContainer = document.getElementById('loading');
      var gridContainer = document.getElementById('BigContainer');

      loadingContainer.style.display = 'none';
      gridContainer.style.display = 'block'; 
  }, 500); 
});

document.addEventListener('DOMContentLoaded',function(){
  var view = {};

  for(var i=0; i< localStorage.length; i++){
    var key = localStorage.key(i);

    if(key.startsWith('View')){
      var item = localStorage.getItem(key);
      view = JSON.parse(item);
      break;
    }
  }

  console.log(view);

    var Title = view.title;
    var location = view.located;
    var price = parseFloat(view.price.substring(1));

    var newObj = {
      "title" : Title,
      "location": location,
      "price_min": price,
      "price_max": price
    }

    myObj["search"] = newObj;
    var stringObj = JSON.stringify(myObj);
    console.log(stringObj);

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
      if(xhr.readyState === XMLHttpRequest.DONE) {
        if(xhr.status === 200) {
          var response = JSON.parse(xhr.responseText);
          var array = response.data;
          ID = array[0].id;
        } else {
          console.error('First request failed with status:', xhr.status);
        }
      }
    }
    xhr.open('POST', 'https://wheatley.cs.up.ac.za/api/', false);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(stringObj); 
});

// create image carousel
// on the click of the button the images should be changed
// get the specific id from other page

// make call to API and then populate the array
var CurrentImg =0;
var ImgOfListing = [];
document.addEventListener('DOMContentLoaded', function(){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if(xhr.readyState === XMLHttpRequest.DONE) {
      if(xhr.status === 200) {
        var response = JSON.parse(xhr.responseText);
        var array = response.data;
        
        // populate the array
        for(var i=0; i<array.length-1; i++){
          ImgOfListing.push(array[i]);
        }

        // populate carousel
        var farLeft = document.getElementById('farLeft');
        var flimg = document.createElement('img');
        flimg.src = ImgOfListing[CurrentImg];
        flimg.alt='';
        farLeft.append(flimg);
        CurrentImg++;

        var left = document.getElementById('itemLeft');
        var limg = document.createElement('img');
        limg.src = ImgOfListing[CurrentImg];
        limg.alt = '';
        left.append(limg);
        CurrentImg++;

        var front = document.getElementById('item_1');
        var img = document.createElement('img');
        img.src = ImgOfListing[CurrentImg];
        img.alt = '';
        front.append(img);
        CurrentImg++;

        var right = document.getElementById('itemRight');
        var rimg = document.createElement('img');
        rimg.src = ImgOfListing[CurrentImg];
        rimg.alt='';
        right.append(rimg);
        CurrentImg++;

        var farRight = document.getElementById('farRight');
        var frimg = document.createElement('img');
        frimg.src = ImgOfListing[CurrentImg];
        frimg.alt = '';
        farRight.append(frimg);
        CurrentImg = 2;
        


      }
    }
  }
  xhr.open('GET', 'https://wheatley.cs.up.ac.za/api/getimage?listing_id='+ID , false);
  xhr.send();
});


// get description
var object ;
// var myObj = {
//   "studentnum": "u22512374",
//   "apikey": "e7c1e5d12f5eeab28e47645a8445d161",
//   "type": "GetAllListings",
//   "return": "*"
// }

var characteristics = document.getElementById('charactersitics');
var description = document.getElementById("description");



document.addEventListener("DOMContentLoaded", function(){
  myObj['search'] = {'id' : ID};
  var jsonObj = JSON.stringify(myObj);
  console.log(jsonObj);
  var xhr2 = new XMLHttpRequest();
  xhr2.onreadystatechange = function() {
    if(xhr2.readyState === XMLHttpRequest.DONE) {
      if(xhr2.status === 200) {
        var responseData = JSON.parse(xhr2.responseText);
        var array = responseData.data; 
        // console.log(array);
        // console.log(ID);
        object = array[0];
        // console.log(object);

        // populate characteristics and description
        var ul = document.createElement('ul');
  var price = document.createElement('li');
  price.textContent ="Price: R"+ object.price;
  var location = document.createElement('li');
  location.textContent = "Location: "+ object.location;
  var bedrooms = document.createElement('li');
  bedrooms.textContent = "Bedrooms: "+object.bedrooms;
  var bathrooms = document.createElement('li');
  bathrooms.textContent = "Bathrooms: "+object.bathrooms;
  var parking = document.createElement('li');
  parking.textContent ="Parking spaces: "+ object.parking_spaces;
  var amenities = document.createElement('li');
  var output = object.amenities;
  output = output.slice(2);
  amenities.textContent = "Amenities: "+output;
  
  ul.appendChild(price);
  ul.appendChild(location);
  ul.appendChild(bedrooms);
  ul.appendChild(bathrooms);
  ul.appendChild(parking);
  ul.appendChild(amenities);

  characteristics.append(ul);

  var des = document.createElement('p');
  var substring = ', ';
  des.textContent = object.description.replace(substring,"");
  description.appendChild(des);
      }
    }
  }
  xhr2.open('POST', 'https://wheatley.cs.up.ac.za/api/', false);
  xhr2.setRequestHeader('Content-Type', 'application/json');
  xhr2.send(jsonObj);
});

var leftButton = document.getElementById("btnLeft");
var rightButton = document.getElementById("btnRight");


leftButton.addEventListener('click', function(){
  var farLeft = document.getElementById('farLeft');
  var left = document.getElementById('itemLeft');
  var front = document.getElementById('item_1');
  var right = document.getElementById('itemRight');
  var farRight = document.getElementById('farRight');
  // change images move each item to the right
  // current img beign displayed is 2
  // case current = 2
  if(CurrentImg === 2){
    farLeft.querySelector('img').src = ImgOfListing[ImgOfListing.length-1];
    left.querySelector('img').src = ImgOfListing[CurrentImg-2];
    front.querySelector('img').src = ImgOfListing[CurrentImg-1];
    right.querySelector('img').src = ImgOfListing[CurrentImg];
    farRight.querySelector('img').src = ImgOfListing[CurrentImg+1];
  } else if(CurrentImg === 1){
    farLeft.querySelector('img').src = ImgOfListing[ImgOfListing.length-2];
    left.querySelector('img').src = ImgOfListing[ImgOfListing.length-1];
    front.querySelector('img').src = ImgOfListing[CurrentImg-1];
    right.querySelector('img').src = ImgOfListing[CurrentImg];
    farRight.querySelector('img').src = ImgOfListing[CurrentImg+1];
  } else if(CurrentImg === 0){
    farLeft.querySelector('img').src = ImgOfListing[ImgOfListing.length-3];
    left.querySelector('img').src = ImgOfListing[ImgOfListing.length-2];
    front.querySelector('img').src = ImgOfListing[ImgOfListing.length-1];
    right.querySelector('img').src = ImgOfListing[CurrentImg];
    farRight.querySelector('img').src = ImgOfListing[CurrentImg+1];
  } else if(CurrentImg === ImgOfListing.length-1){
    farLeft.querySelector('img').src = ImgOfListing[CurrentImg-3];
    left.querySelector('img').src = ImgOfListing[CurrentImg-2];
    front.querySelector('img').src = ImgOfListing[CurrentImg-1];
    right.querySelector('img').src = ImgOfListing[CurrentImg];
    farRight.querySelector('img').src = ImgOfListing[0];
  } else {
    farLeft.querySelector('img').src = ImgOfListing[CurrentImg-3];
    left.querySelector('img').src = ImgOfListing[CurrentImg-2];
    front.querySelector('img').src = ImgOfListing[CurrentImg-1];
    right.querySelector('img').src = ImgOfListing[CurrentImg];
    farRight.querySelector('img').src = ImgOfListing[CurrentImg+1];
  }



  CurrentImg--;
  if(CurrentImg === -1){
    CurrentImg = 9;
  }
  
});

rightButton.addEventListener('click', function(){
  var farLeft = document.getElementById('farLeft');
  var left = document.getElementById('itemLeft');
  var front = document.getElementById('item_1');
  var right = document.getElementById('itemRight');
  var farRight = document.getElementById('farRight');
  // change images move each item to the right
  // current img beign displayed is 2
  // case current = 2
  if(CurrentImg === 9){
    farLeft.querySelector('img').src = ImgOfListing[CurrentImg-1];
    left.querySelector('img').src = ImgOfListing[CurrentImg];
    front.querySelector('img').src = ImgOfListing[0];
    right.querySelector('img').src = ImgOfListing[1];
    farRight.querySelector('img').src = ImgOfListing[2];
  } else if(CurrentImg === 8){
    farLeft.querySelector('img').src = ImgOfListing[CurrentImg-1];
    left.querySelector('img').src = ImgOfListing[CurrentImg];
    front.querySelector('img').src = ImgOfListing[CurrentImg+1];
    right.querySelector('img').src = ImgOfListing[0];
    farRight.querySelector('img').src = ImgOfListing[1];
  } else if(CurrentImg === 7){
    farLeft.querySelector('img').src = ImgOfListing[CurrentImg-1];
    left.querySelector('img').src = ImgOfListing[CurrentImg];
    front.querySelector('img').src = ImgOfListing[CurrentImg+1];
    right.querySelector('img').src = ImgOfListing[CurrentImg+2];
    farRight.querySelector('img').src = ImgOfListing[0];
  } else if(CurrentImg === 0){
    farLeft.querySelector('img').src = ImgOfListing[9];
    left.querySelector('img').src = ImgOfListing[CurrentImg];
    front.querySelector('img').src = ImgOfListing[CurrentImg+1];
    right.querySelector('img').src = ImgOfListing[CurrentImg+2];
    farRight.querySelector('img').src = ImgOfListing[CurrentImg+3];
  } else {
    farLeft.querySelector('img').src = ImgOfListing[CurrentImg-1];
    left.querySelector('img').src = ImgOfListing[CurrentImg];
    front.querySelector('img').src = ImgOfListing[CurrentImg+1];
    right.querySelector('img').src = ImgOfListing[CurrentImg+2];
    farRight.querySelector('img').src = ImgOfListing[CurrentImg+3];
  }
  CurrentImg++;
  if(CurrentImg === 10){
    CurrentImg = 0;
  }
});