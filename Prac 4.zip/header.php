<!-- <?php
if (session_status() == PHP_SESSION_NONE) {
  session_start();
}
?> -->

<header class="header">
    <img src="img/LogoMakr-4c0eRl.png" class="logo" alt="logos">
    <nav class="navbar">
      <a href="Agents.php">Agents</a>
      <a href="Calculator.php">Calculator</a>

      <?php
        if(isset($_SESSION["apikey"])){
          // Use is logged in
          echo "<a href='Listing.php'>Listings</a>";
          echo "<a href='Favourites.php'>Favourites</a>";
          
          echo "<a href='logout.php'>Logout</a>";
          echo "<a href='#'>".$_SESSION["name"]."</a>";
        } else {
          // User isnt logged in
          echo "<a href='login.php'>Login</a>";
          echo "<a href='signup.php'>Register</a>";          
        }
      ?>
    </nav>
</header>

