Default login details:
- L@scholt.com
- Pass@123

Use of my website:
- When opening the website you can view agents and use the calculator as an unregistered user
- If you want to gain access to the actual listings and other features you can log in if you have an account or register a new account by clicking on the corresponding header
- After logging in/ registering you can search,sort,filter listings and then favourite them
- Saved favourite listings can be viewed in the favourite tab
- Users that are logged in can change the theme, there is an option between light and dark
- After done using the website the user can log out and the session will end