<?php
//$_SERVER['user_id'] = 14; //the session should be started upon login, so this line is not needed
if (isset($_SERVER['user_id'])) { 
    $servername = "wheatley.cs.up.ac.za";
    $username = "u22512374";
    $password = "7FLH6BHZHIU6XP2AFFBZ5TN7GLCDAAUQ";
    $dbname = "u22512374_221prac";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        $response = array(
            'success' => false,
            'message' => 'Database connection failed: ' . $conn->connect_error
        );
        header('Content-Type: application/json');
        echo json_encode($response);
        return null;
    }
    
    return $conn;
} else {
    $response = array(
        'success' => false,
        'message' => 'User ID not set'
    );
    header('Content-Type: application/json');
    echo json_encode($response);
    return null;
}
?>
