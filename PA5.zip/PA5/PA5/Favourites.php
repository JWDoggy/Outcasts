<!-- u22512374 Herman Engelbrecht-->
<?php
include('header.php');
  $cssFile = 'css/Favourite.css';

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agents</title>
  <link rel="stylesheet" href="<?php echo $cssFile; ?>">
  <script src="Favourites.js" defer></script>
</head>
<body>

  <section class="Heading">
    <h1>Your Favourites:</h1>
  </section>

  <section id="Favourites">

  </section>
  
</body>
</html>
