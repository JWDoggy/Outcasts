<?php
$conn = include 'connect.php';
if ($conn === null) {
    die("Connection failed. Check the response message.");
}
$_SESSION['user_id'] = 14;
function createAccountFromPost($conn) {
    if (!isset($_POST['name'], $_POST['surname'], $_POST['email'], $_POST['password'],  $_SESSION['user_id'])) {
        echo "something is not set";
    }

    $name = $_POST['name'];
    echo $name;
    $surname = $_POST['surname'];
    echo $surname;
    $email = $_POST['email'];
    echo $email;
    $password = $_POST['password'];
    echo $password;
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $user_id = $_SESSION['user_id'];

    $user = "INSERT INTO users () VALUES ()"; // Since there's only one column, no need to specify it
    if ($conn->query($user) )
    {
        echo "we have inserted into users";
    }
    $lastUserId = $conn->insert_id;

    $login = "INSERT INTO loginInfo (user_id, email, password) VALUES (?, ?, ?)";
    $loginQuery = $conn->prepare($login);
    
    if ($loginQuery) {
        $loginQuery->bind_param("iss", $lastUserId, $email, $hashedPassword); //made a change here
        if ($loginQuery->execute()) {
            echo "New record created successfully";
        } else {
            echo "Execute failed: (" . $loginQuery->errno . ") " . $loginQuery->error;
        }
        $loginQuery->close();
    } else 
    {
        echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
    }
    echo " The user and login details for the user have been added";
    
    
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $fam = "UPDATE family SET num_members = num_members + 1 WHERE user_id = ?";
        $famQuery = $conn->prepare($fam);
        $famQuery->bind_param("i", $user_id);
        
        if (!$famQuery->execute()) { //if the user_id is not in family
            $fam = "insert into family(user_id,num_members) values (?,?)";
            $famQuery = $conn->prepare($fam);
            $famQuery->bind_param("ii", $user_id,2);
            $famResult = $famQuery->execute();
            if ($famQuery->execute())
            {
                echo " fam query successful ";
            }

            $sql = "SELECT name, surname FROM single_account WHERE login_id = ?";
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                $stmt->bind_param("i", $user_id);
                if ($stmt->execute()) {
                    $stmt->bind_result($name, $surname);
                    $stmt->fetch();
                    $stmt->close(); 
                    $famMemSql = "INSERT INTO family_members (family_id, name, surname) VALUES (?, ?, ?)";
                    $famMemStmt = $conn->prepare($famMemSql);
                    if ($famMemStmt) 
                    {
                        $famMemStmt->bind_param("iss", $user_id, $name, $surname);
                        if ($famMemStmt->execute()) 
                        {
                            echo " family member insertion succesful";
                            $famMemStmt->close();
                        } else {
                            echo "Execute failed: (" . $famMemStmt->errno . ") " . $famMemStmt->error;
                            $famMemStmt->close();
                            return false;
                        }
                    }
                     else 
                    {
                        echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
                        return false;
                    }
                }
                 else 
                {
                    echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                    $stmt->close();
                    return false;
                }
            } 
            else 
            {
                echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
                return false;
            }

            $famMem = "INSERT INTO family_members (family_id, name, surname) VALUES (?, ?, ?)";
            $famMemQuery = $conn->prepare($famMem);

            if ($famMemQuery) {
                $famMemQuery->bind_param("iss", $user_id, $name, $surname);
                if (!$famMemQuery->execute()) 
                {
                    echo "Execute failed: (" . $famMemQuery->errno . ") " . $famMemQuery->error;
                    $famMemQuery->close();
                    return false;
                }
                echo "family member insert successful";
                $famMemQuery->close();
            } 
            else 
            {
                echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
                return false;
            } 
        }
        $famQuery->close();
        $famMem = "INSERT INTO family_members (family_id, name, surname) VALUES (?, ?, ?)";
        $famMemQuery = $conn->prepare($famMem);
        $famMemQuery->bind_param("iss", $user_id, $name, $surname);
        $famMemResult = $famMemQuery->execute();
        $famMemQuery->close();
    }

    echo '<script>
            alert("Your addition to your family was successful. We are now going to redirect you to your account page.");
            setTimeout(function() {
                window.location.href = "accounts.php";
            }, 3000);
          </script>';
    exit; 
}
createAccountFromPost($conn);
?>
