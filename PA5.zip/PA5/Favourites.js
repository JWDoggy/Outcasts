// on load get the listings that was favourited and then populate the document



document.addEventListener('DOMContentLoaded', function(){
      // body : apikey, type, id
      // wat wil ek return, die listing ids van favourites

     var ID = localStorage.getItem('userID');
      var Obj = {
        'type': "getFavourites",
        'content':'movies',
        'user_id': ID
      }
      var stringObj = JSON.stringify(Obj);

      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(){
        if(xhr.readyState === XMLHttpRequest.DONE) {
          if(xhr.status === 200) {
            // console.log("success");
            var response = JSON.parse(xhr.responseText);
            var data = response;
            console.log(data);

            data.forEach(function(listing) {
              var FavouriteContainer = document.getElementById('Favourites');
              var maindiv = document.createElement('div');
                              maindiv.className = "List-Agents";
                              maindiv.style.backgroundImage = "url("+listing.poster+")";
            
                              var backg = document.createElement('div');
                              backg.className = "backg";
            
                              var heading = document.createElement('h2');
                              heading.className = "Agent1";
                              heading.textContent = listing.title; 
                              backg.appendChild(heading);
            
                              var unorderd = document.createElement('ul');
                              var pri = document.createElement('li');
                              pri.textContent = listing.description;
                              unorderd.appendChild(pri);
                              backg.appendChild(unorderd);
            
                              var btn = document.createElement('button');
                              btn.id = "favourite";
                              var icon = document.createElement('i');
                              icon.className = 'material-icons';
                              icon.textContent = 'Remove from favourites';
                              btn.appendChild(icon);
                              backg.appendChild(btn);
            
                              maindiv.appendChild(backg);
                              FavouriteContainer.appendChild(maindiv);
              
            });

          }
        }
      }
      xhr.open('POST', 'api.php', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.send(stringObj);
  
});


// when remove from favourites is clicked, remove the favourite 
// document.addEventListener("DOMContentLoaded", function(){
//   var grid = document.getElementById("Favourites");

//   grid.addEventListener('click', function(event){
//     var target = event.target;
//     console.log(target);
//     console.log("clicked");
//     if(target.matches('button')){
//       var parent = target.closest('.backg');

//       var title = parent.qeurySelect('h4');
//       console.log(title.textContent);

//     }
//   })
// })
document.addEventListener("DOMContentLoaded", function(){
  var grid = document.getElementById("Favourites");

  grid.addEventListener('click', function(event){
    var target = event.target.closest('button');

    if(target && target.matches('button')){
      var parent = target.closest('.backg');
      var title = parent.querySelector('h2').textContent;
      var price = parent.querySelector('ul li:first-child').textContent;
      var numericPrice = price.match(/\d+(\.\d+)?/)[0];
      console.log(numericPrice);

      // make request to API to remove from favourites and then reload the page
      // Wat ek gaan stuur: typpe "remove", title = title
      var Obj = {
        "type": "Remove",
        "title": title,
        "price": numericPrice
      }
      Obj.price = parseFloat(Obj.price);
      console.log(Obj);
      var stringObj = JSON.stringify(Obj);
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(){
        if(xhr.readyState === XMLHttpRequest.DONE) {
          if(xhr.status === 200) {
            console.log("success");
            window.location.reload();
          }
        }
      }
      xhr.open('POST', '../../api.php', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.send(stringObj);
      
      
    }
  });
});