When the website is opened you are shown the login page:
 - If you have an account sign in: Default login details: herrie@gmail.com pass@123
 - If you do not have an account choose the sign up link

If the sign up link is clicked then you will be presented with an option that suits your choice:
 - choose a single account for a single user and enter the fields, your account will be created
 - choose a family account for multiple users and enter the fields, your account will be created

After loggin in/signing up you will be directed to the movies page. Here you can search for movies,
look for someting that you are in the mood in for or filter the movies based on ratings or release date.

If you want to view series you can click on the link in the header. Other navigation to pages are also available.
Same as the movie page you can search for a title, filter the movies based on what you want to wact or by ratings and release dat

There will be a slide over on each movie/series on that you can add the movie to your favourites
Access your favourited content on the favourite page. On this page you can remove it if you want to.

There is also a recommendation page, here based on criteria you can view movies and recommended series

After using the website you can log out