-- phpMyAdmin SQL Dump
-- version 5.0.4deb2~bpo10+1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 30, 2024 at 12:23 AM
-- Server version: 10.3.39-MariaDB-0+deb10u2
-- PHP Version: 7.3.31-1~deb10u6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u22512374_221prac`
--

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `series_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `movie_id`, `series_id`) VALUES
(3, 2, NULL),
(4, 10, NULL),
(5, 18, NULL),
(6, 34, NULL),
(7, 42, NULL),
(8, 50, NULL),
(9, 58, NULL),
(10, 66, NULL),
(11, 74, NULL),
(12, 82, NULL),
(13, 90, NULL),
(14, 106, NULL),
(15, 114, NULL),
(16, 122, NULL),
(17, 130, NULL),
(18, 138, NULL),
(19, 146, NULL),
(20, 154, NULL),
(21, 162, NULL),
(22, 170, NULL),
(23, 178, NULL),
(24, 186, NULL),
(25, 194, NULL),
(26, 210, NULL),
(27, 218, NULL),
(28, 226, NULL),
(29, 234, NULL),
(30, 250, NULL),
(31, 258, NULL),
(32, 266, NULL),
(33, 274, NULL),
(34, 282, NULL),
(35, 290, NULL),
(36, 298, NULL),
(37, 306, NULL),
(38, 314, NULL),
(39, 322, NULL),
(40, 330, NULL),
(41, 338, NULL),
(42, 346, NULL),
(43, 354, NULL),
(44, 362, NULL),
(45, 370, NULL),
(46, 378, NULL),
(47, 386, NULL),
(48, 394, NULL),
(49, 402, NULL),
(50, 410, NULL),
(51, 418, NULL),
(52, 426, NULL),
(53, 434, NULL),
(54, 442, NULL),
(55, 450, NULL),
(56, 458, NULL),
(57, 466, NULL),
(58, 474, NULL),
(59, 482, NULL),
(60, 490, NULL),
(61, 498, NULL),
(62, 506, NULL),
(63, 514, NULL),
(64, 522, NULL),
(65, 530, NULL),
(66, 538, NULL),
(67, 546, NULL),
(68, 554, NULL),
(69, 562, NULL),
(70, 570, NULL),
(71, 578, NULL),
(72, 586, NULL),
(73, 594, NULL),
(74, 610, NULL),
(75, 618, NULL),
(76, 626, NULL),
(77, 634, NULL),
(78, 642, NULL),
(79, 650, NULL),
(80, 666, NULL),
(81, 674, NULL),
(82, 682, NULL),
(83, 690, NULL),
(84, 698, NULL),
(85, 706, NULL),
(86, 714, NULL),
(87, 722, NULL),
(88, 730, NULL),
(89, 738, NULL),
(90, 746, NULL),
(91, 754, NULL),
(92, 762, NULL),
(93, 778, NULL),
(94, 786, NULL),
(95, 794, NULL),
(96, 802, NULL),
(97, 810, NULL),
(98, 818, NULL),
(99, 826, NULL),
(100, 834, NULL),
(101, 842, NULL),
(102, 850, NULL),
(103, 858, NULL),
(104, 866, NULL),
(105, 882, NULL),
(106, 890, NULL),
(107, 898, NULL),
(108, 906, NULL),
(109, 914, NULL),
(110, 922, NULL),
(111, 930, NULL),
(112, 946, NULL),
(113, 954, NULL),
(114, 962, NULL),
(115, 970, NULL),
(116, 978, NULL),
(117, 986, NULL),
(118, 994, NULL),
(119, 1002, NULL),
(120, 1010, NULL),
(121, 1018, NULL),
(122, 1026, NULL),
(123, 1034, NULL),
(124, 1042, NULL),
(125, 1058, NULL),
(126, 1066, NULL),
(127, 1074, NULL),
(128, 1082, NULL),
(129, 1090, NULL),
(130, 1098, NULL),
(131, 1106, NULL),
(132, 1115, NULL),
(133, 1123, NULL),
(134, 1131, NULL),
(135, 1139, NULL),
(136, 1147, NULL),
(137, 1155, NULL),
(138, 1163, NULL),
(139, 1171, NULL),
(140, 1179, NULL),
(141, 1187, NULL),
(142, 1195, NULL),
(143, 1203, NULL),
(144, 1211, NULL),
(145, 1219, NULL),
(146, 1227, NULL),
(147, 1235, NULL),
(148, 1243, NULL),
(149, 1251, NULL),
(150, 1259, NULL),
(151, 1267, NULL),
(152, 1275, NULL),
(153, 1283, NULL),
(154, 1291, NULL),
(155, 1299, NULL),
(156, 1307, NULL),
(157, 1315, NULL),
(158, 1323, NULL),
(159, 1363, NULL),
(160, 1371, NULL),
(161, 1379, NULL),
(162, 1387, NULL),
(163, 1395, NULL),
(164, 1403, NULL),
(165, 1411, NULL),
(166, 1419, NULL),
(167, 1427, NULL),
(168, 1435, NULL),
(169, 1443, NULL),
(170, 1451, NULL),
(171, 1459, NULL),
(172, 1467, NULL),
(173, 1483, NULL),
(174, 1491, NULL),
(175, 1499, NULL),
(176, 1507, NULL),
(177, 1515, NULL),
(178, 1523, NULL),
(179, 1531, NULL),
(180, 1539, NULL),
(181, 1547, NULL),
(182, 1555, NULL),
(183, 1563, NULL),
(184, 1571, NULL),
(185, 1579, NULL),
(186, 1587, NULL),
(187, 1595, NULL),
(188, 1603, NULL),
(189, 1611, NULL),
(190, 1619, NULL),
(191, 1627, NULL),
(192, 1643, NULL),
(193, 1651, NULL),
(194, 1659, NULL),
(195, 1667, NULL),
(196, 1675, NULL),
(197, 1683, NULL),
(198, 1691, NULL),
(199, 1699, NULL),
(200, 1707, NULL),
(201, 1715, NULL),
(202, 1731, NULL),
(203, 1739, NULL),
(204, 1747, NULL),
(205, 1755, NULL),
(206, 1763, NULL),
(207, 1771, NULL),
(208, 1779, NULL),
(209, 1787, NULL),
(210, 1795, NULL),
(211, 1803, NULL),
(212, 1819, NULL),
(213, 1827, NULL),
(214, 1835, NULL),
(215, 1843, NULL),
(216, 1851, NULL),
(217, 1859, NULL),
(218, 1867, NULL),
(219, 1875, NULL),
(220, 1883, NULL),
(221, 1891, NULL),
(222, 1899, NULL),
(223, 1907, NULL),
(224, 1915, NULL),
(225, 1923, NULL),
(226, 1931, NULL),
(227, 1939, NULL),
(228, 1947, NULL),
(229, 1955, NULL),
(230, 1963, NULL),
(231, 1971, NULL),
(232, 1979, NULL),
(233, 1987, NULL),
(234, 2003, NULL),
(235, 2011, NULL),
(236, 2019, NULL),
(237, 2027, NULL),
(238, 2035, NULL),
(239, 2043, NULL),
(240, 2067, NULL),
(241, 2075, NULL),
(242, 2083, NULL),
(243, 2091, NULL),
(244, 2099, NULL),
(245, 2107, NULL),
(246, 2115, NULL),
(247, 2123, NULL),
(248, 2131, NULL),
(249, 2139, NULL),
(250, 2147, NULL),
(251, 2155, NULL),
(252, 2163, NULL),
(253, 2171, NULL),
(254, 2179, NULL),
(255, 2187, NULL),
(256, 2195, NULL),
(257, 2203, NULL),
(258, 2211, NULL),
(259, 2219, NULL),
(260, 2227, NULL),
(261, 2235, NULL),
(262, 2243, NULL),
(263, 2251, NULL),
(264, 2259, NULL),
(265, 2267, NULL),
(266, 2275, NULL),
(267, 2283, NULL),
(268, 2299, NULL),
(269, 2307, NULL),
(270, 2315, NULL),
(271, 2323, NULL),
(272, 2331, NULL),
(273, 2339, NULL),
(274, 2347, NULL),
(275, 2355, NULL),
(276, 2363, NULL),
(277, 2379, NULL),
(278, 2387, NULL),
(279, 2395, NULL),
(280, 2403, NULL),
(281, 2411, NULL),
(282, 2419, NULL),
(283, 2427, NULL),
(284, 2435, NULL),
(285, 2443, NULL),
(286, 2451, NULL),
(287, 2459, NULL),
(288, 2467, NULL),
(289, 2475, NULL),
(290, 2483, NULL),
(291, 2491, NULL),
(292, 2507, NULL),
(293, 2515, NULL),
(294, 2531, NULL),
(295, 2547, NULL),
(296, 2555, NULL),
(297, 2563, NULL),
(298, 2587, NULL),
(299, 2595, NULL),
(300, 2603, NULL),
(301, 2627, NULL),
(302, 2643, NULL),
(303, 2651, NULL),
(304, 2667, NULL),
(305, 2675, NULL),
(306, 2683, NULL),
(307, 2691, NULL),
(308, 2699, NULL),
(309, 2707, NULL),
(310, 2715, NULL),
(311, 2723, NULL),
(312, 2731, NULL),
(313, 2739, NULL),
(314, 2747, NULL),
(315, 2755, NULL),
(316, 2763, NULL),
(317, 2771, NULL),
(318, 2779, NULL),
(319, 2787, NULL),
(320, 2795, NULL),
(321, 2811, NULL),
(322, 2819, NULL),
(323, 2827, NULL),
(324, 2835, NULL),
(325, 2843, NULL),
(326, 2851, NULL),
(327, 2859, NULL),
(328, 2867, NULL),
(329, 2875, NULL),
(330, 2883, NULL),
(331, 2891, NULL),
(332, 2899, NULL),
(333, 2907, NULL),
(334, 2915, NULL),
(335, 2923, NULL),
(336, 2931, NULL),
(337, 2939, NULL),
(338, 2947, NULL),
(339, 2955, NULL),
(340, 2963, NULL),
(341, 2971, NULL),
(342, 2979, NULL),
(343, 2987, NULL),
(344, 2995, NULL),
(345, 3003, NULL),
(346, 3011, NULL),
(347, 3019, NULL),
(348, 3027, NULL),
(349, 3043, NULL),
(350, 3051, NULL),
(351, 3059, NULL),
(352, 3067, NULL),
(353, 3075, NULL),
(354, 3083, NULL),
(355, 3091, NULL),
(356, 3099, NULL),
(357, 3107, NULL),
(358, 3115, NULL),
(359, 3123, NULL),
(360, 3131, NULL),
(361, 3140, NULL),
(362, 3148, NULL),
(363, 3156, NULL),
(364, 3164, NULL),
(365, 3172, NULL),
(366, 3180, NULL),
(367, 3188, NULL),
(368, 3196, NULL),
(369, 3204, NULL),
(370, 3212, NULL),
(371, 3220, NULL),
(372, 3228, NULL),
(373, 3236, NULL),
(374, 3244, NULL),
(375, 3252, NULL),
(376, 3260, NULL),
(377, 3268, NULL),
(378, 3276, NULL),
(379, 3284, NULL),
(380, 3292, NULL),
(381, 3300, NULL),
(382, 3308, NULL),
(383, 3316, NULL),
(384, 3324, NULL),
(385, 3332, NULL),
(386, 3340, NULL),
(387, 3348, NULL),
(388, 3356, NULL),
(389, 3364, NULL),
(390, 3372, NULL),
(391, 3380, NULL),
(392, 3388, NULL),
(393, 3396, NULL),
(394, 3412, NULL),
(395, 3420, NULL),
(396, 3428, NULL),
(397, 3436, NULL),
(398, 3444, NULL),
(399, 3452, NULL),
(400, 3460, NULL),
(401, 3476, NULL),
(402, 3484, NULL),
(403, 3492, NULL),
(404, 3500, NULL),
(405, 3508, NULL),
(406, 3516, NULL),
(407, 3524, NULL),
(408, 3532, NULL),
(409, 3540, NULL),
(410, 3548, NULL),
(411, 3556, NULL),
(412, 3564, NULL),
(413, 3572, NULL),
(414, 3580, NULL),
(415, 3588, NULL),
(416, 3596, NULL),
(417, 3604, NULL),
(418, 3612, NULL),
(419, 3620, NULL),
(420, 3628, NULL),
(421, 3644, NULL),
(422, 3660, NULL),
(423, 3676, NULL),
(424, 3684, NULL),
(425, 3692, NULL),
(426, 3700, NULL),
(427, 3716, NULL),
(428, 3732, NULL),
(429, 3740, NULL),
(430, 3748, NULL),
(431, 3756, NULL),
(432, 3764, NULL),
(433, 3772, NULL),
(434, 3780, NULL),
(435, 3788, NULL),
(436, 3796, NULL),
(437, 3804, NULL),
(438, 3812, NULL),
(439, 3820, NULL),
(515, NULL, 38),
(516, NULL, 42),
(517, NULL, 46),
(518, NULL, 50),
(519, NULL, 54),
(520, NULL, 58),
(521, NULL, 62),
(522, NULL, 66),
(523, NULL, 70),
(524, NULL, 74),
(525, NULL, 78),
(526, NULL, 82),
(527, NULL, 86),
(528, NULL, 90),
(529, NULL, 94),
(530, NULL, 98),
(531, NULL, 102),
(532, NULL, 106),
(533, NULL, 110),
(534, NULL, 114),
(535, NULL, 118),
(536, NULL, 122),
(537, NULL, 126),
(538, NULL, 130),
(539, NULL, 134),
(540, NULL, 138),
(541, NULL, 142),
(542, NULL, 146),
(543, NULL, 150),
(544, NULL, 154),
(545, NULL, 158),
(546, NULL, 162),
(547, NULL, 166),
(548, NULL, 170),
(549, NULL, 174),
(550, NULL, 178),
(551, NULL, 182),
(552, NULL, 186),
(553, NULL, 190),
(554, NULL, 194),
(555, NULL, 198),
(556, NULL, 202),
(557, NULL, 206),
(558, NULL, 210),
(559, NULL, 214),
(560, NULL, 222),
(561, NULL, 226),
(562, NULL, 230),
(563, NULL, 234),
(564, NULL, 238),
(565, NULL, 242),
(566, NULL, 246),
(567, NULL, 250),
(568, NULL, 254),
(569, NULL, 258),
(570, NULL, 262),
(571, NULL, 266),
(572, NULL, 274),
(573, NULL, 278),
(574, NULL, 282),
(575, NULL, 286),
(576, NULL, 290),
(577, NULL, 294),
(578, NULL, 298),
(579, NULL, 302),
(580, NULL, 306),
(581, NULL, 310),
(582, NULL, 314),
(583, NULL, 318),
(584, NULL, 322),
(585, NULL, 326),
(586, NULL, 330),
(587, NULL, 334),
(588, NULL, 338),
(589, NULL, 342),
(590, NULL, 346),
(591, NULL, 350),
(592, NULL, 354),
(593, NULL, 358),
(594, NULL, 362),
(595, NULL, 366),
(596, NULL, 370),
(597, NULL, 374),
(598, NULL, 378),
(599, NULL, 382),
(600, NULL, 386),
(601, NULL, 390),
(602, NULL, 394),
(603, NULL, 398),
(604, NULL, 402),
(605, NULL, 406),
(606, NULL, 410),
(607, NULL, 414),
(608, NULL, 418),
(609, NULL, 422),
(610, NULL, 426),
(611, NULL, 430),
(612, NULL, 434),
(613, NULL, 438),
(614, NULL, 442),
(615, NULL, 446),
(616, NULL, 454),
(617, NULL, 458),
(618, NULL, 462),
(619, NULL, 466),
(620, NULL, 470),
(621, NULL, 474),
(622, NULL, 478),
(623, NULL, 486),
(624, NULL, 490),
(625, NULL, 494),
(626, NULL, 498),
(627, NULL, 502),
(628, NULL, 506),
(629, NULL, 510),
(630, NULL, 514),
(631, NULL, 518),
(632, NULL, 522),
(633, NULL, 526),
(634, NULL, 530),
(635, NULL, 538),
(636, NULL, 542),
(637, NULL, 546),
(638, NULL, 550),
(639, NULL, 554),
(640, NULL, 558),
(641, NULL, 562),
(642, NULL, 566),
(643, NULL, 570),
(644, NULL, 574),
(645, NULL, 578),
(646, NULL, 582),
(647, NULL, 586),
(648, NULL, 590),
(649, NULL, 594),
(650, NULL, 598),
(651, NULL, 602),
(652, NULL, 606),
(653, NULL, 610),
(654, NULL, 614),
(655, NULL, 618),
(656, NULL, 622),
(657, NULL, 626),
(658, NULL, 630),
(659, NULL, 634),
(660, NULL, 638),
(661, NULL, 642),
(662, NULL, 650),
(663, NULL, 654),
(664, NULL, 658),
(665, NULL, 662),
(666, NULL, 666),
(667, NULL, 670),
(668, NULL, 674),
(669, NULL, 678),
(670, NULL, 682),
(671, NULL, 686),
(672, NULL, 690),
(673, NULL, 694),
(674, NULL, 698),
(675, NULL, 702),
(676, NULL, 706),
(677, NULL, 710),
(678, NULL, 714),
(679, NULL, 718),
(680, NULL, 722),
(681, NULL, 726),
(682, NULL, 730),
(683, NULL, 734),
(684, NULL, 738),
(685, NULL, 742),
(686, NULL, 746),
(687, NULL, 750),
(688, NULL, 754),
(689, NULL, 758),
(690, NULL, 762),
(691, NULL, 766),
(692, NULL, 770),
(693, NULL, 774),
(694, NULL, 778);

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE `family` (
  `user_id` int(11) NOT NULL,
  `num_members` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`user_id`, `num_members`) VALUES
(2, 3),
(8, 2),
(9, 2),
(10, 2),
(11, 2),
(12, 2),
(13, 2),
(14, 4);

-- --------------------------------------------------------

--
-- Table structure for table `family_members`
--

CREATE TABLE `family_members` (
  `family_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family_members`
--

INSERT INTO `family_members` (`family_id`, `name`, `surname`) VALUES
(9, 'ArraymemberName1', 'ArraymemberName1'),
(9, 'ArraymemberName2', 'ArraymemberName2'),
(10, 'ArraymemberName1', 'ArraymemberName1'),
(10, 'ArraymemberName2', 'ArraymemberName2'),
(11, 'ArraymemberName1', 'ArraymemberName1'),
(11, 'ArraymemberName2', 'ArraymemberName2'),
(12, 'herrie', 'engel'),
(12, 'engel', 'linc'),
(12, 'engel', 'rob'),
(13, 'herrie', 'engel'),
(13, 'engel', 'linc'),
(13, 'engel', 'rob'),
(14, 'mother', 'burger'),
(14, 'burger', 'leai'),
(14, 'burger', 'danela'),
(14, 'John', 'Meyer'),
(14, 'Tom', 'Cruise');

-- --------------------------------------------------------

--
-- Table structure for table `favourites`
--

CREATE TABLE `favourites` (
  `id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favourites`
--

INSERT INTO `favourites` (`id`, `content_id`, `user_id`) VALUES
(6, 34, 1),
(7, 10, 14);

-- --------------------------------------------------------

--
-- Table structure for table `head`
--

CREATE TABLE `head` (
  `family_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL,
  `cellphone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loginInfo`
--

CREATE TABLE `loginInfo` (
  `email` varchar(40) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loginInfo`
--

INSERT INTO `loginInfo` (`email`, `password`, `user_id`) VALUES
('herrie@gmail.com', 'pass@123', 1),
('burger@mail.com', 'pass@123', 2),
('jekretschmer2003@gmail.com', '$2y$10$zTP2yER9GF7tlB4w/JwA3etj1/2KpFeal5SEJU2EsJlSdQIPhGnbq', 1),
('joshKretcsh@gmail.com', '$2y$10$pizMgZOXxKJA3tzq8nNtaOauahAk/GnsiAgC4Dwu87EwlB.KCW7s6', 1),
('joshKretcsh@gmail.com', '$2y$10$7mPqrcMJaoIb3sepnEvL6ek1De1KhlhmNeSOWSIDRGPUvKT3Hha3y', 1),
('joshKretcsh@gmail.com', '$2y$10$p1Y1YMlFfvHBNP8QKyedmO9zaNb4hNd5tul/6L11rGcrnMA1rRR36', 1),
('joshKretcsh@gmail.com', '$2y$10$dO9nhXCzADtMr.Nc0Y5AMOQRDQIdoACfyhKtocmCvCZXu92T1ObjO', 1),
('joshKretcsh@gmail.com', '$2y$10$cp9l1JpBQmYH16RcGBrd2uYPeYMrEP63SIBSqvLEjth.FFnAtd642', 1),
('joshKretcsh@gmail.com', '$2y$10$xkYYrMQiZ5rcrSxDXcJI6.qiOWg.JJ9biwTw5CqV9bzUEbrdtJVR.', 1),
('IamJim@gmail.com', '$2y$10$EuUaa/Q.GX1jf25kAALqJ.oa1ziR923vlfwwpG3XEJC.Nn7RnfMLK', 1),
('IamJim@gmail.com', '$2y$10$EVl0IKIMbgMY0CjtU6G1aeWpnHqf8XdK4bHom3aSm68NUZqEjZg8a', 1),
('ovan@gmail.com', '$2y$10$jqBvhxHUOh0ANPThS0bSIOBJWCYgkc1MaZ.h9kaXoiXmDnIxX1wm.', 1),
('john@hotmail.com', '$2y$10$YvrZ2VmjHNi6/lh7RyIqMuL/M9KB41Ro99Ye0V1Cy5zhyBYkOhMuS', 1),
('john@hotmail.com', '$2y$10$u9Aa4MNh7anQX43bhZ65o.Or9CgaDm20j4uR0ER5oT3dzs8ydFhLq', 1),
('john@hotmail.com', '$2y$10$5BOPQfPPXHJXFUc9fYQf.ergGlIjdhRq0N.4WTQ9jMSjdfuza2uGm', 1),
('iovnew@vn.com', '$2y$10$fKihrvCLtrdP.jTO21GF9OfYuot.uGJgSO3o5uJGxNqnEB.G0jdvO', 1),
('john@hotmail.com', '$2y$10$XH/jQLg4K4QaO5HlTn.6qOtEpAo90WiWPaoeHp231CKVV/hnRHwqC', 1),
('mail@.com', 'pass@123', 7),
('mail@ma', 'pass@', 8),
('here@ma', 'pass123', 9),
('here@ma', 'pass123', 10),
('mail@mal', 'pass@123', 11),
('her@mail', 'pass@', 12),
('her@mail', 'pass@1', 13),
('burger@mail', 'pass@123', 14),
('', '', 15),
('Queen@gmail.com', '$2y$10$Qaus9HUnfgebfc9uLNghn.WLQLdZhwPWKkNYpEz6q53SiVFYG.qnS', 16),
('guitarRocks@gmail.com', '$2y$10$3MsETgnP6vVVRvA087A6Xe5PlFe/E/Re5yuxnWHFPnsuqQT8kzxRC', 17),
('ImNotShort@gmail.com', '$2y$10$D4P9EEGqiJfHprBaR5P/su8GolC26umXPfn/ZSpAtT0iORnt36BjO', 18);

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int(11) NOT NULL,
  `Title` varchar(83) DEFAULT NULL,
  `Description` varchar(1731) DEFAULT NULL,
  `COL 5` varchar(17) DEFAULT NULL,
  `runtime` varchar(7) DEFAULT NULL,
  `genres` varchar(122) DEFAULT NULL,
  `imdb_id` varchar(10) DEFAULT NULL,
  `rating` varchar(10) DEFAULT NULL,
  `poster` text DEFAULT NULL,
  `release_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `Title`, `Description`, `COL 5`, `runtime`, `genres`, `imdb_id`, `rating`, `poster`, `release_date`) VALUES
(2, 'Rocky', 'When world heavyweight boxing champion, Apollo Creed wants to give an unknown fighter a shot at the title as a publicity stunt, his handlers choose palooka Rocky Balboa, an uneducated collector for a Philadelphia loan shark. Rocky teams up with trainer  Mickey Goldmill to make the most of this once in a lifetime break.', 'PG', '119', 'drama', 'tt0075148', '8.1', 'https://m.media-amazon.com/images/M/MV5BNTBkMjg2MjYtYTZjOS00ODQ0LTg0MDEtM2FiNmJmOGU1NGEwXkEyXkFqcGdeQXVyMjUzOTY1NTc@._V1_SX300.jpg', '1905-05-29'),
(10, 'Heroes', 'A Vietnam veteran suffering from post traumatic stress disorder breaks out of a VA hospital and goes on a road trip with a sympathetic traveler to find out what became of the other men in his unit.', 'PG', '112', 'drama', 'tt0076138', '6', 'https://m.media-amazon.com/images/M/MV5BNGE1NWMxMTgtNzFhMS00NzM2LWJhZTYtNGNjYWIzNzJiMmM5XkEyXkFqcGdeQXVyNzc5MjA3OA@@._V1_SX300.jpg', '1905-05-30'),
(18, 'Amrapali', 'After a failed conquest, Emperor Ajaatshatru pretends to be a soldier in the enemy\'s army to weaken them from the inside. However, he falls in love with Amrapali by faking his identity.', '', '120', 'fantasy', 'tt0060104', '6.7', 'https://m.media-amazon.com/images/M/MV5BMGZhNmI2NjEtYzYxOS00NTFjLWFjZTgtY2FhMzRlMGRlZTE2XkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_SX300.jpg', '1905-05-19'),
(34, 'Top Gun', 'For Lieutenant Pete \'Maverick\' Mitchell and his friend and co-pilot Nick \'Goose\' Bradshaw, being accepted into an elite training school for fighter pilots is a dream come true. But a tragedy, as well as personal demons, will threaten Pete\'s dreams of becoming an ace pilot.', 'PG', '110', 'drama', 'tt0092099', '6.9', 'https://m.media-amazon.com/images/M/MV5BZjQxYTA3ODItNzgxMy00N2Y2LWJlZGMtMTRlM2JkZjI1ZDhhXkEyXkFqcGdeQXVyNDk3NzU2MTQ@._V1_SX300.jpg', '1905-06-08'),
(42, 'Twins', 'Julius and Vincent Benedict are the results of an experiment that would allow for the perfect child. Julius was planned and grows to athletic proportions. Vincent is an accident and is somewhat smaller in stature. Vincent is placed in an orphanage while Julius is taken to a south seas island and raised by philosophers. Vincent becomes the ultimate low life and is about to be killed by loan sharks.', 'PG', '106', 'comedy', 'tt0096320', '6.1', 'https://m.media-amazon.com/images/M/MV5BMWUzN2VkY2ItYmQ4YS00MjFmLWJhZDQtYWY1NWQ2NTA5NDNlXkEyXkFqcGdeQXVyNDc2NjEyMw@@._V1_SX300.jpg', '1905-06-10'),
(50, 'Parrot Sketch Not Included: Twenty Years of Monty Python', 'Steve Martin presents selected sketches from \"Monty Python\'s Flying Circus (1969)\". It\'s the well known sketches, though the parrot sketch is not included. Steve Martin has some funny comments on the Pythons.', '', '72', 'comedy', 'tt0213984', '8.1', 'https://m.media-amazon.com/images/M/MV5BMTkzNDA5MTA5MV5BMl5BanBnXkFtZTgwMzMzOTk1MDE@._V1_SX300.jpg', '1905-06-11'),
(58, 'Waiting for the Hearse', 'Mama Cora, who is almost eighty years old, has three sons and a daughter. She lives with one of them, who has serious financial problems. The family meets one day to celebrate an anniversary meal, and that is when the problem arises: which of them will take care of her?', '', '87', 'comedy', 'tt0089108', '8', 'https://m.media-amazon.com/images/M/MV5BZjQxNWM3ODktZDQ2My00NDAyLWJkZDUtMWJiZWNjNTM2ZjU4XkEyXkFqcGdeQXVyMTk5MTE5MTg@._V1_SX300.jpg', '1905-06-07'),
(66, 'Pyar Ke Do Pal', 'In order to assist her close friend, Rajni Thakur, Geeta Choudhary, has an abortion in her name, so that Rajni can get married. When her secret gets leaked out, Geeta\'s husband, Ashok, blames her, accuses her of being unfaithful, and drives her out of his house. They have twins, Sunil and Anil, and each parent is allowed custody of one child. The children meet each other at Scout camp, and decide to re-unite their parents, without realizing that they are exposing not only them, but also each other, to danger and death.', '', '153', 'action', 'tt0358053', '6.2', 'https://m.media-amazon.com/images/M/MV5BYTMyMGM5YjgtMjMzMS00OGI3LWE0OGQtNjIyMTA5NTJkZjQyXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_SX300.jpg', '1905-06-08'),
(74, 'A Stoning in Fulham County', 'Religious beliefs clash with the law when an Amish infant is killed in a rural community.', '', '95', 'drama', 'tt0096179', '5.9', 'https://m.media-amazon.com/images/M/MV5BMTY3MDE0OTY5OV5BMl5BanBnXkFtZTgwMDEwODY0MjE@._V1_SX300.jpg', '1905-06-10'),
(82, 'Jerry Maguire', 'Jerry Maguire used to be a typical sports agent: willing to do just about anything he could to get the biggest possible contracts for his clients, plus a nice commission for himself. Then, one day, he suddenly has second thoughts about what he\'s really doing. When he voices these doubts, he ends up losing his job and all of his clients, save Rod Tidwell, an egomaniacal football player.', 'R', '138', 'drama', 'tt0116695', '7.3', 'https://m.media-amazon.com/images/M/MV5BYTM0ZWNmZTUtOTVkZS00MTZiLTg3M2QtZjA0Y2RmOWM1NWEyXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg', '1905-06-18'),
(90, 'The Mask of Zorro', 'It has been twenty years since Don Diego de la Vega fought Spanish oppression in Alta California as the legendary romantic hero, Zorro. Having escaped from prison he transforms troubled bandit Alejandro into his successor, in order to foil the plans of the tyrannical Don Rafael Montero who robbed him of his freedom, his wife and his precious daughter.', 'PG-13', '136', 'action', 'tt0120746', '6.8', 'https://m.media-amazon.com/images/M/MV5BMzg4ZjQ4OGUtZjkxMi00Y2I2LWEzNTAtODI2ZjkxMGVjNTQwXkEyXkFqcGdeQXVyNjgxNTAwNjQ@._V1_SX300.jpg', '1905-06-20'),
(106, 'Dil Se..', 'Journalist Amar falls for a mysterious woman on an assignment, but she does not reciprocate his feelings. However, when Amar is about to get married, the woman shows up at his doorstep asking for help.', 'PG-13', '163', 'drama', 'tt0164538', '7.5', 'https://m.media-amazon.com/images/M/MV5BNWFjNGIxYWUtZDFmNy00NzRkLThkYWItZjBiNTJlNGE3MTA0XkEyXkFqcGdeQXVyODE0NjUxNzY@._V1_SX300.jpg', '1905-06-20'),
(114, 'Nutty Professor II: The Klumps', 'The hilarity begins when professor Sherman Klump finds romance with fellow DNA specialist, Denise Gaines, and discovers a brilliant formula that reverses aging. But Sherman\'s thin and obnoxious alter ego, Buddy Love, wants out...and a big piece of the action. And when Buddy gets loose, things get seriously nutty.', 'PG-13', '106', 'romance', 'tt0144528', '4.4', 'https://m.media-amazon.com/images/M/MV5BNjcyOWM2NTUtYzRjYS00ZTQ4LWFlZGItNTE2MDg4MGIxNjAyXkEyXkFqcGdeQXVyNTUyMzE4Mzg@._V1_SX300.jpg', '1905-06-22'),
(122, 'Chronicle of a Disappearance', 'Chronicle of a Disappearance unfolds in a series of seemingly unconnected cinematic tableaux, each of them focused on incidents or characters which seldom reappear later in the film. Among the many unrelated scenes, there is a Palestinian actress struggling to find an apartment in West Jerusalem, the owner of the Holy Land souvenir shop preparing merchandise for incoming Japanese tourists, a group of old women gossiping about their relatives, and an Israeli police van which screeches to a halt so several heavily armed soldiers can get off the car and urinate.', '', '84', 'drama', 'tt0115895', '6.9', 'https://m.media-amazon.com/images/M/MV5BYWFlY2RiYjctYzlmZC00ZjFmLWE5NGQtMzJiOTk1ODA3ZWNkXkEyXkFqcGdeQXVyMjMyMzI4MzY@._V1_SX300.jpg', '1905-06-20'),
(130, 'Destiny', 'In the 12th century\'s Andalusia lives Ibn Rushd a prominent islamic philosopher with his wife Zeinab and daughter Salma. The principality is ruled by Khalifa ElMansour who has two sons, ElNasser, an intellectual that likes Ibn Rush and is in love with his daughter Salma. The younger son Abdallah is more into dancing and poetry, spending most of his times with the gypsy family and getting the daughter pregnant. The Khalifa is depending on the extremists to build his army granting them more power which they use to combat artists and philosophers. The extremists succeed in recruiting Abd Allah and train him to kill his father. Events go on where Marawan, the gypsy singer, is killed and Ibn Rushd\'s books are burnt. Adapted from the real life of Ibn Rushd AlMasir is Chahine\'s statement against extremism.', '', '136', 'drama', 'tt0119629', '7.2', 'https://m.media-amazon.com/images/M/MV5BZDQzNWE4NDQtNGE3YS00OTNkLTk3YjEtYTdkYTYyNDhkNDYwXkEyXkFqcGdeQXVyMjI4NzAzNjg@._V1_SX300.jpg', '1905-06-19'),
(138, 'Gumrah', 'Roshni Chadha makes her living, singing in various places and this makes her the breadwinner of her home. She soon gets to meet the handsome and wealthy Rahul Malhotra, who finds out that she can actually sing professionally and he helps her to attain this goal, which soon became a success and Roshni falls in love with Rahul and finds out that he has the same feelings for her. On a foreign trip, Roshni is arrested by the police for having in her possession cocaine, Rahul disappears leaving Roshni in hot-soup and now she must prepare to undergo her prison terms as there is no one to help her.', '', '149', 'crime', 'tt0107060', '6.1', 'https://m.media-amazon.com/images/M/MV5BYWE4MWNiYzYtYzI5MS00MjRiLThiNjItYzdiODRlZDY2ZGFiXkEyXkFqcGdeQXVyOTI1NzYyOTE@._V1_SX300.jpg', '1905-06-15'),
(146, 'Sinbad: Nothin\' but the Funk', 'Enjoy Comedic Superstar Sinbad as he gives us one of his most stellar stand up performances, shot on the beautiful island of Aruba at the Guillermo P. Trinidad Theatre. As always, Sinbad shows why he’s a veteran in comedy since the 80’s, with an entertaining show that the entire family can enjoy.', '', '55', 'comedy', 'tt0938332', '6.4', 'https://m.media-amazon.com/images/M/MV5BNGM0NjI1MWYtZTcyNC00YWVhLWIwNzAtZDk5ZTU4MDRjMmViXkEyXkFqcGdeQXVyMTgwOTE5NDk@._V1_SX300.jpg', '1905-06-19'),
(154, 'The Lord of the Rings: The Fellowship of the Ring', 'Young hobbit Frodo Baggins, after inheriting a mysterious ring from his uncle Bilbo, must leave his home in order to keep it from falling into the hands of its evil creator. Along the way, a fellowship is formed to protect the ringbearer and make sure that the ring arrives at its final destination: Mt. Doom, the only place where it can be destroyed.', 'PG-13', '178', 'fantasy', 'tt0120737', '8.8', 'https://m.media-amazon.com/images/M/MV5BN2EyZjM3NzUtNWUzMi00MTgxLWI0NTctMzY4M2VlOTdjZWRiXkEyXkFqcGdeQXVyNDUzOTQ5MjY@._V1_SX300.jpg', '1905-06-23'),
(162, 'The Mist', 'After a violent storm, a dense cloud of mist envelops a small Maine town, trapping artist David Drayton and his five-year-old son in a local grocery store with other people. They soon discover that the mist conceals deadly horrors that threaten their lives, and worse, their sanity.', 'R', '126', 'thriller', 'tt0884328', '7.1', 'https://m.media-amazon.com/images/M/MV5BMTU2NjQyNDY1Ml5BMl5BanBnXkFtZTcwMTk1MDU1MQ@@._V1_SX300.jpg', '1905-06-29'),
(170, 'The Longest Yard', 'Pro quarter-back, Paul Crewe and former college champion and coach, Nate Scarboro are doing time in the same prison. Asked to put together a team of inmates to take on the guards, Crewe enlists the help of Scarboro to coach the inmates to victory in a football game \'fixed\' to turn out quite another way.', 'PG-13', '109', 'comedy', 'tt0398165', '6.4', 'https://m.media-amazon.com/images/M/MV5BMTc1NTQyNDk2NV5BMl5BanBnXkFtZTcwOTE2OTQzMw@@._V1_SX300.jpg', '1905-06-27'),
(178, 'Along Came Polly', 'Reuben Feffer is a guy who\'s spent his entire life playing it safe. Polly Prince is irresistible as a free-spirit who lives for the thrill of the moment. When these two comically mismatched souls collide, Reuben\'s world is turned upside down, as he makes an uproarious attempt to change his life from middle-of-the-road to totally-out-there.', 'PG-13', '90', 'comedy', 'tt0343135', '6', 'https://m.media-amazon.com/images/M/MV5BMTcxMDMwODg3Nl5BMl5BanBnXkFtZTYwMTM4NTY3._V1_SX300.jpg', '1905-06-26'),
(186, '21', 'Ben Campbell is a young, highly intelligent, student at M.I.T. who strives to succeed. Wanting a scholarship to transfer to Harvard School of Medicine to become a doctor, Ben learns that he cannot afford the $300,000 tuition as he comes from a poor, working-class background. But one evening, Ben is introduced by his unorthodox math professor to  a small but secretive club.  Students Jill, Choi, Kianna, and Fisher, who are being trained by Professor Rosa in to count cards at blackjack.', 'PG-13', '123', 'drama', 'tt0478087', '6.8', 'https://m.media-amazon.com/images/M/MV5BMjAyNTU5OTcxOV5BMl5BanBnXkFtZTcwMDEyNjM2MQ@@._V1_SX300.jpg', '1905-06-30'),
(194, 'Gridiron Gang', 'Teenagers at a juvenile detention center, under the leadership of their counselor, gain self-esteem by playing football together.', 'PG-13', '125', 'drama', 'tt0421206', '7.1', 'https://m.media-amazon.com/images/M/MV5BNzk4NTAwNTAzN15BMl5BanBnXkFtZTcwNjczODYzMQ@@._V1_SX300.jpg', '1905-06-28'),
(210, 'Mike Birbiglia: What I Should Have Said Was Nothing', 'Mike says, \"A few years ago my therapist suggested I keep a journal of all the crazy things that were going on in my life, so that I could keep things in perspective. Around the same time audiences were demanding more material, and I realized that other people might enjoy these stories-so I started sending them out to my mailing list. Now, my Secret Public Journal has become a Comedy Central special and DVD for all the world to see. Not sure this is what my therapist had in mind.\"', '', '60', 'comedy', 'tt1188112', '7.6', 'https://m.media-amazon.com/images/M/MV5BMTk0NzY2NzM5Ml5BMl5BanBnXkFtZTcwNjE2Mjg2MQ@@._V1_SX300.jpg', '1905-06-30'),
(218, 'Monsters vs Aliens', 'When Susan Murphy is unwittingly clobbered by a meteor full of outer space gunk on her wedding day, she mysteriously grows to 49-feet-11-inches. The military jumps into action and captures Susan, secreting her away to a covert government compound. She is renamed Ginormica and placed in confinement with a ragtag group of Monsters...', 'PG', '94', 'action', 'tt0892782', '6.4', 'https://m.media-amazon.com/images/M/MV5BMTY0OTQ3MzE3MV5BMl5BanBnXkFtZTcwMDQyMzMzMg@@._V1_SX300.jpg', '1905-07-01'),
(226, 'Accident', 'A self-styled accident choreographer, the Brain is a professional hitman who kills his victims by trapping them in well crafted accidents that look like unfortunate mishaps. When the team\'s next assignment goes disastrously wrong, Brain begins to suspect that someone else has planned an ‘accident’ on them.', 'R', '89', 'drama', 'tt1202514', '6.6', 'https://m.media-amazon.com/images/M/MV5BZmIxNTE2NDMtOGRjNy00ZjRjLWJlZWItZjFjYjcyY2Q4ODAwXkEyXkFqcGdeQXVyMjQwMjk0NjI@._V1_SX300.jpg', '1905-07-01'),
(234, 'Billu', 'When a famous Bollywood actor visits a small village for a film\'s shoot, a lowly hairdressers claim that they were once childhood friends soon makes him the centre of attention.', 'PG', '137', 'drama', 'tt1230448', '6.3', 'https://m.media-amazon.com/images/M/MV5BYWI0MGZlNWYtMmZhMS00ZDIwLTg3N2ItNTgxNWIyOTY1YTNjXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_SX300.jpg', '1905-07-01'),
(250, 'Astro Boy', 'Set in the futuristic Metro City, Astro Boy (Atom) is a young robot with incredible powers created by a brilliant scientist in the image of the son he had lost. Unable to fulfill his creator\'s expectations, Astro embarks on a journey in search of acceptance, experiencing betrayal and a netherworld of robot gladiators, before returning to save Metro City and reconcile with the father who rejected him.', 'PG', '94', 'animation', 'tt0375568', '6.2', 'https://m.media-amazon.com/images/M/MV5BMTI5NTEwNTcxMl5BMl5BanBnXkFtZTcwMDEyMTE4Mg@@._V1_SX300.jpg', '1905-07-01'),
(258, 'Ishqiya', 'While on the run from goons, a man and his nephew fall for a kidnapper\'s seductive widow.', 'R', '115', 'comedy', 'tt1345777', '7.3', 'https://m.media-amazon.com/images/M/MV5BNTc1Y2EyOWUtNWExMi00OGNkLTkxOGQtNDY0YzYxNTA0OWUxXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_SX300.jpg', '1905-07-02'),
(266, 'Raajneeti', 'It is the story of a fiercely fought election campaign, where money power and corruption are the accepted norms, and where treachery and manipulation are routinely used weapons. As the personal drama of these conflict-ridden characters unfolds against this gritty backdrop, love and friendship become mere baits, and relationships get sacrificed at the altar of political alignments. The darkness that rises from their souls threatens to envelope all that they hold precious. Until eventually, in the crescendo of increasing violence, the line between good and evil blurs, making it impossible to distinguish heroes from villains. Raajneeti is the story of Indian democracy. And its ugly underside. It is about politics. And beyond.', 'PG', '167', 'thriller', 'tt1291465', '7.1', 'https://m.media-amazon.com/images/M/MV5BOGIzOTdjMDAtNjBkNy00ODdjLThjYzctOWU2NTU1MDc0MGE4XkEyXkFqcGdeQXVyMjY1MjkzMjE@._V1_SX300.jpg', '1905-07-02'),
(274, 'G.O.R.A.', 'Carpet dealer and UFO photo forger Arif is abducted by aliens and must outwit the evil commander-in-chief of G.O.R.A., the planet where he is being held.', 'PG-13', '127', 'scifi', 'tt0384116', '8', 'https://m.media-amazon.com/images/M/MV5BMjE0MTY2MDI3NV5BMl5BanBnXkFtZTcwNTc1MzEzMQ@@._V1_SX300.jpg', '1905-06-26'),
(282, 'Daddy Day Camp', 'Seeking to offer his son the satisfying summer camp experience that eluded him as a child, the operator of a neighborhood daycare center opens his own camp, only to face financial hardship and stiff competition from a rival camp.', 'PG', '85', 'comedy', 'tt0462244', '3.2', 'https://m.media-amazon.com/images/M/MV5BMTM1NTUyMTExMF5BMl5BanBnXkFtZTcwNzk0MDI1MQ@@._V1_SX300.jpg', '1905-06-29'),
(290, 'Beast Stalker', 'Sergeant Tong is wracked with guilt after he unwittingly kills a young girl whilst capuring a criminal named Cheung. When the girl\'s sister is later kidnapped in a ploy to get Cheung released, Sergeant Tong vows to find and rescue her before she comes to harm.', 'R', '109', 'thriller', 'tt1330525', '6.8', 'https://m.media-amazon.com/images/M/MV5BMzAzYTNjZmEtMTViYS00NDY5LTg4ZjQtOGIzZTQ5ZWYzZTEzXkEyXkFqcGdeQXVyMjg0MTI5NzQ@._V1_SX300.jpg', '1905-06-30'),
(298, 'Legend of the Fist: The Return of Chen Zhen', 'The Japanese forces occupy Shanghai and slowly start spreading terror in the city. Chen Zhen, who was presumed dead, returns to fight against the Japanese and put an end to their tyrannical rule.', 'R', '113', 'thriller', 'tt1456661', '6.3', 'https://m.media-amazon.com/images/M/MV5BZmQyYzg4M2QtMTIwZS00ZTBlLTk3YzAtMzkxYmM3OWMwZDJhXkEyXkFqcGdeQXVyMjUyNDk2ODc@._V1_SX300.jpg', '1905-07-02'),
(306, 'This Is the Life', 'In 1989, a collective of young hip hop artists gathered at a health food café in South Central Los Angeles. Their mandate? To reject gang culture and expand the musical boundaries of hip hop. DuVernay\'s documentary chronicles the historic legacy of the Good Life Cafe — the open mic nights that became an L.A. institution, the eclectic array of talented young MCs that emerged there, the alternative hip hop movement they developed, and their worldwide influence on the artform.', '', '97', 'music', 'tt1178658', '6.8', 'https://m.media-amazon.com/images/M/MV5BMTI2MTM4NTUzMV5BMl5BanBnXkFtZTcwNjAzOTEzMg@@._V1_SX300.jpg', '1905-06-30'),
(314, 'Karthik Calling Karthik', 'A much abused loner achieves success, and even wins the heart of his gorgeous co-worker, after getting early morning mysterious phone calls from someone.', 'PG', '135', 'thriller', 'tt1373156', '7.1', 'https://m.media-amazon.com/images/M/MV5BMTg4NzUyNDExMl5BMl5BanBnXkFtZTcwOTg3NTk5Mw@@._V1_SX300.jpg', '1905-07-02'),
(322, 'Twins Mission', 'When a precious Tibetan bead is stolen by rogue members of the mysterious Gemini Clan, the protectors of the bead enlist the help of some righteous former Gemini Clan members to retrieve the bead and bring the evil disciples to justice.', '', '99', 'action', 'tt0934949', '5.2', 'https://m.media-amazon.com/images/M/MV5BODY1ZmUxZGItNjY0YS00NTVjLWFmZDUtYWNkZmVjODljNTZjXkEyXkFqcGdeQXVyNzI1NzMxNzM@._V1_SX300.jpg', '1905-06-29'),
(330, 'A Love Story', 'Ian Montes is a picture of success. Despite being a son of a shipping tycoon, Ian refused to just ride in his father\'s empire. He built his own real estate company and earned his first million at a very young age. He never looked back since then. Driven by his ambition to become better, if not as good as his father, Ian managed to make it on his own. But behind all the glory is a man yearning for love and recognition.', '', '117', 'romance', 'tt0990433', '6.5', 'https://m.media-amazon.com/images/M/MV5BZWJhZGQ0ZmYtNmRmYi00YWNhLWJjNjQtMzVjNDc1MDFmMjFiXkEyXkFqcGdeQXVyNTI5NjIyMw@@._V1_SX300.jpg', '1905-06-29'),
(338, 'The Unjust', 'An honest cop has to compromise with his principles when he is told to find a scapegoat for a high-profile serial killer case in exchange for a big promotion.', '', '119', 'thriller', 'tt1843120', '6.6', 'https://m.media-amazon.com/images/M/MV5BMTY2MTI5ODIzMl5BMl5BanBnXkFtZTgwNzI3MDE0MjE@._V1_SX300.jpg', '1905-07-02'),
(346, 'Delhi-6', 'Roshan, an NRI, arrives in Old Delhi with his ailing grandmother and starts to rediscover himself before getting caught in a religious dispute that shakes the once peaceful neighborhood.', '', '141', 'drama', 'tt1043451', '6.1', 'https://m.media-amazon.com/images/M/MV5BMTMyMTE4MTMyOV5BMl5BanBnXkFtZTcwNTU5OTkyMg@@._V1_SX300.jpg', '1905-07-01'),
(354, 'Taxi No. 9 2 11', 'A cabbie and businessman both in need of big money partake in a two-hour adventure together.', '', '116', 'drama', 'tt0476884', '7.3', 'https://m.media-amazon.com/images/M/MV5BOTgxMTc0NTItODUyYy00ODY1LTg0NDEtZGI0MzQxZGY5NmFhXkEyXkFqcGdeQXVyNDUzOTQ5MjY@._V1_SX300.jpg', '1905-06-28'),
(362, 'A Lion in the House', 'Five families struggle with the ups and downs of cancer treatment over the course of six years.', '', '225', 'documentation', 'tt0492472', '8.7', 'https://m.media-amazon.com/images/M/MV5BMjEyNzY2MDQ5NV5BMl5BanBnXkFtZTgwMjc5OTkwMzE@._V1_SX300.jpg', '1905-06-28'),
(370, 'The Ghost', 'A young amnesiac accused of murder seeks to know the truth about himself while he is on the run from the police, searching for the real killer with the help of his friend.', '', '91', 'action', 'tt1584021', '6.5', 'https://m.media-amazon.com/images/M/MV5BZTY5MGVkMjgtNWI4Ni00NzVjLTk0ZTUtMjczZTIyOGE3MzI4XkEyXkFqcGdeQXVyMTA0MTM5NjI2._V1_SX300.jpg', '1905-06-29'),
(378, 'Te quiero', 'Jean and Sylvia left France with a stolen diamond to start a new life in South America. They land in Lima to live their passion. But the diamond is not easy to sell. They meet a French couple and hope to sell them the stolen diamond.', '', '85', 'drama', 'tt0217085', '5', 'https://m.media-amazon.com/images/M/MV5BMTc3NTY1MjkyNF5BMl5BanBnXkFtZTcwMDg5MjEyMQ@@._V1_SX300.jpg', '1905-06-23'),
(386, 'The Island', 'Mansour El-Hefny’s wealthy family rule an Upper Egyptian island. Some police officers facilite their arms dealing in exchange for information, and corrupt parliament members use their immunity to par-take in their drug trade.', '', '143', 'drama', 'tt1173901', '7.8', 'https://m.media-amazon.com/images/M/MV5BM2Q3ODA1NzItMDExOS00NmFiLWFmMGQtZmYyOWE0YjFmMmQyXkEyXkFqcGdeQXVyMTA3NjcyOTI2._V1_SX300.jpg', '1905-06-29'),
(394, 'Encrypted Letter', 'Fayez discovers a code sheet that his grandfather left to him before he was killed, of a treasure map in Jerusalem, drawn by the Jews fleeing to Egypt. He goes on an adventure with his friends, Ismail and Bedair, to search for the map hidden in an archaeological temple in Luxor.', '', '88', 'comedy', 'tt1972828', '5.9', 'https://m.media-amazon.com/images/M/MV5BNjY3ZmNhNzgtZWVkZS00MWY5LWI0ODgtYThlN2U2ODAwMmM1XkEyXkFqcGdeQXVyMzk0MzcwODg@._V1_SX300.jpg', '1905-06-30'),
(402, 'This Is 40', 'Pete and Debbie are both about to turn 40, their kids hate each other, both of their businesses are failing, they\'re on the verge of losing their house, and their relationship is threatening to fall apart.', 'R', '134', 'comedy', 'tt1758830', '6.2', 'https://m.media-amazon.com/images/M/MV5BNzQxMDQ1NjA4N15BMl5BanBnXkFtZTcwNTE5MjQ3OA@@._V1_SX300.jpg', '1905-07-04'),
(410, 'Eega', 'Nani is a flower decorator, madly in love with his neighbor Bindhu. He gets killed by the baddie, Sudeep, a powerful businessman. Nani comes back as a housefly to get his revenge.', '', '145', 'action', 'tt2258337', '7.8', 'https://m.media-amazon.com/images/M/MV5BZDk5N2EzOTYtMWE1NC00YWEyLWE2MDMtZGQ3NTAxYzg3YmU2XkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_SX300.jpg', '1905-07-04'),
(418, 'Sebastian Maniscalco: What\'s Wrong with People?', '\"What\'s Wrong with People?\" asks Sebastian Maniscalco, as he hilariously tries to bridge the Italian-American Old World he grew up in with the contemporary frenetic world we all live in today.', '', '75', 'comedy', 'tt2215489', '8', 'https://m.media-amazon.com/images/M/MV5BMzQ5MDE4MjYwNF5BMl5BanBnXkFtZTgwMzcyNTAxMzE@._V1_SX300.jpg', '1905-07-04'),
(426, 'Zindagi Na Milegi Dobara', 'Three friends who were inseparable in childhood decide to go on a three-week-long bachelor road trip to Spain, in order to re-establish their bond and explore thrilling adventures, before one of them gets married. What will they learn of themselves and each other during the adventure?', 'PG', '154', 'drama', 'tt1562872', '8.2', 'https://m.media-amazon.com/images/M/MV5BZGFmMjM5OWMtZTRiNC00ODhlLThlYTItYTcyZDMyYmMyYjFjXkEyXkFqcGdeQXVyNDUzOTQ5MjY@._V1_SX300.jpg', '1905-07-03'),
(434, 'The Great Magician', 'In the years after the Revolution, China broken up into fiefdoms held by warlords, who are busy fighting each other. One warlord has imprisoned a girl and wants her to be his seventh wife, but he\'s too honorable to force her. The local revolutionaries wants to kill him and bring back the republic. But when a stranger returns from abroad with mastery of magic to recover the girl he loved, who is tricking whom and who will win at the end?', '', '128', 'drama', 'tt1869721', '5.9', 'https://m.media-amazon.com/images/M/MV5BZmUyMDE4ZTgtNjI3Zi00YzRkLTg0NTktMGM0ZmI0ODQyMWZmXkEyXkFqcGdeQXVyNzI1NzMxNzM@._V1_SX300.jpg', '1905-07-03'),
(442, 'Naruto Shippuden the Movie: Blood Prison', 'After his capture for attempted assassination of the Raikage, leader of Kumogakure, as well as killing Jōnin from Kirigakure and Iwagakure, Naruto is imprisoned in Hōzukijou: A criminal containment facility known as the Blood Prison. Mui, the castle master, uses the ultimate imprisonment technique to steal power from the prisoners, which is when Naruto notices his life has been targeted. Thus begins the battle to uncover the truth behind the mysterious murders and prove Naruto\'s innocence.', 'PG-13', '108', 'thriller', 'tt1999167', '7.1', 'https://m.media-amazon.com/images/M/MV5BMDgyZmRkYjUtMWExNS00NDQyLTliZTMtOTkwY2M3ZWU0ZjNmXkEyXkFqcGdeQXVyMjc2Nzg5OTQ@._V1_SX300.jpg', '1905-07-03'),
(450, 'Pyaar Ka Punchnama', 'Nishant starts dating Charu while his roommates Rajat and Vikrant already have girlfriends in Neha and Rhea respectively. Trouble starts when the guys feel that their girlfriends are dominating them.', 'PG-13', '149', 'drama', 'tt1926313', '7.6', 'https://m.media-amazon.com/images/M/MV5BNDI4MmJkM2ItYjZjMC00MzYxLWIwZWEtYzE5YWZhYmExM2I5XkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_SX300.jpg', '1905-07-03'),
(458, 'Ferrari Ki Sawaari', 'A little boy thinks of nothing but cricket. His father, Rusy, thinks of nothing but his little boy. To fulfill his sons dream of playing at Lords cricket ground, the honest and upright Rusy takes a reckless step. He borrows a gleaming red Ferrari. Just for one hour. The only trouble-- he doesnt inform the cars legendary owner. A wild, breathless, bumpy ride begins. A naive Rusy must dodge bullets and bouncers for one unforgettable night, and play the role of a perfect father. Can he do it?  Ferrari Ki Sawaari is a fun-filled story of small guys and their big dreams and how these dreams turn into a mad comedy of errors.  Fasten your seatbelts. The joyride awaits', 'G', '140', 'comedy', 'tt2122340', '6.4', 'https://m.media-amazon.com/images/M/MV5BMTQ2NTAxNzMxMl5BMl5BanBnXkFtZTcwNjczNzc3Nw@@._V1_SX300.jpg', '1905-07-04'),
(466, 'The Mistress', 'A young woman is torn between the affections of her two lovers. One is a young bachelor who brings passion into her life. The other is a married man who has kept her as his mistress for years. Architect JD has a chip on his shoulder about his father Rico never really accepting him as his son. Seamstress Sari struggles to take care of her family. The two meet by chance, and JD aggressively pursues Saris affections. Though the two are clearly a good match, there is a problem standing in the way of their bliss: Sari is the mistress of JDs father. Against his better judgment, JD continues to court Sari even after finding out this difficult fact. He hides his true identity as Ricos son, and fights to win Saris heart.', 'PG-13', '125', 'romance', 'tt2389344', '6.4', 'https://m.media-amazon.com/images/M/MV5BMTE0MDEyODAxNjZeQTJeQWpwZ15BbWU4MDIzMzkxMzcx._V1_SX300.jpg', '1905-07-04'),
(474, 'Toll Booth', 'Quiet and introverted toll booth clerk Kenan\'s life, a humdrum routine between the Tavsancik toll booth plaza and his home, will change the day the new operations chief comes to inspect Tavsancik.', '', '97', 'drama', 'tt1753866', '6.4', 'https://m.media-amazon.com/images/M/MV5BNjE3NTM0MzE2OF5BMl5BanBnXkFtZTcwMDk0Mzc5Ng@@._V1_SX300.jpg', '1905-07-03'),
(482, 'Shirdi Sai', 'Based on the life of Indian guru Shirdi Sai Baba (Nagarjuna Akkineni), who taught love, forgiveness, charity and devotion.', '', '142', 'drama', 'tt2397561', '6.7', 'https://m.media-amazon.com/images/M/MV5BZGJkZmI3NjgtNjYyZi00YTcxLWE2MTgtNzkyMTliZWUwNjU4XkEyXkFqcGdeQXVyNDUzOTQ5MjY@._V1_SX300.jpg', '1905-07-04'),
(490, 'This Is Where I Leave You', 'When their father passes away, four grown, world-weary siblings return to their childhood home and are requested -- with an admonition -- to stay there together for a week, along with their free-speaking mother and a collection of spouses, exes and might-have-beens. As the brothers and sisters re-examine their shared history and the status of each tattered relationship among those who know and love them best, they reconnect in hysterically funny and emotionally significant ways.', 'R', '103', 'comedy', 'tt1371150', '6.6', 'https://m.media-amazon.com/images/M/MV5BMjkzNzQ2NDMyNl5BMl5BanBnXkFtZTgwMTY3MTcxMjE@._V1_SX300.jpg', '1905-07-06'),
(498, 'Paddington', 'A young Peruvian bear travels to London in search of a new home. Finding himself lost and alone at Paddington Station, he meets the kindly Brown family.', 'PG', '95', 'comedy', 'tt1109624', '7.3', 'https://m.media-amazon.com/images/M/MV5BMTAxOTMwOTkwNDZeQTJeQWpwZ15BbWU4MDEyMTI1NjMx._V1_SX300.jpg', '1905-07-06'),
(506, 'The Best of Me', 'A pair of former high school sweethearts reunite after many years when they return to visit their small hometown.', 'PG-13', '117', 'romance', 'tt1972779', '6.6', 'https://m.media-amazon.com/images/M/MV5BMzQ5Njg3Njk5N15BMl5BanBnXkFtZTgwODIwODIxMjE@._V1_SX300.jpg', '1905-07-06'),
(514, 'The Boxtrolls', 'An orphaned boy raised by underground creatures called Boxtrolls comes up from the sewers and out of his box to save his family and the town from the evil exterminator, Archibald Snatcher.', 'PG', '97', 'comedy', 'tt0787474', '6.8', 'https://m.media-amazon.com/images/M/MV5BMTQxODA5MDkyNV5BMl5BanBnXkFtZTgwMDMyNjkzMjE@._V1_SX300.jpg', '1905-07-06'),
(522, 'The Butler', 'A look at the life of Cecil Gaines who served eight presidents as the White House\'s head butler from 1952 to 1986, and had a unique front-row seat as political and racial history was made.', 'PG-13', '132', 'drama', 'tt1327773', '7.2', 'https://m.media-amazon.com/images/M/MV5BMjM2NDY3MjkyMF5BMl5BanBnXkFtZTcwMDM5Nzg5OQ@@._V1_SX300.jpg', '1905-07-05'),
(530, 'Tom Segura: Completely Normal', 'An original stand-up comedy special written and performed by comedian Tom Segura.', '', '74', 'comedy', 'tt3500822', '7.7', 'https://m.media-amazon.com/images/M/MV5BMTcyODE0Mzk1Nl5BMl5BanBnXkFtZTgwMDk4ODE0NDE@._V1_SX300.jpg', '1905-07-06'),
(538, 'City of God: 10 Years Later', 'City of God – 10 Years Later investigates what happened to the actors who took part in the award-winning film directed by Fernando Meirelles and Katia Lund. This documentary shows what City of God’s worldwide success meant to their lives. Were the actors prepared for the film’s success? Did the social background of some of them prove stronger than the opportunity that came their way?', 'PG', '69', 'documentation', 'tt4103686', '6.4', 'https://m.media-amazon.com/images/M/MV5BMTQ4MDk2OTE1NV5BMl5BanBnXkFtZTgwNDI0OTk5MjE@._V1_SX300.jpg', '1905-07-06'),
(546, 'Search Party', 'Two oafs must rescue their stranded pal in Mexico.', 'R', '93', 'comedy', 'tt2758904', '5.6', 'https://m.media-amazon.com/images/M/MV5BNDM3MjE4ODQzMV5BMl5BanBnXkFtZTgwMDY0NDgzODE@._V1_SX300.jpg', '1905-07-06'),
(554, 'Virunga', 'Virunga in the Democratic Republic of the Congo is Africa’s oldest national park, a UNESCO world heritage site, and a contested ground among insurgencies seeking to topple the government that see untold profits in the land. Among this ongoing power struggle, Virunga also happens to be the last natural habitat for the critically endangered mountain gorilla. The only thing standing in the way of the forces closing in around the gorillas: a handful of passionate park rangers and journalists fighting to secure the park’s borders and expose the corruption of its enemies. Filled with shocking footage, and anchored by the surprisingly deep and gentle characters of the gorillas themselves, Virunga is a galvanizing call to action around an ongoing political and environmental crisis in the Congo.', '', '90', 'documentation', 'tt3455224', '8.2', 'https://m.media-amazon.com/images/M/MV5BMzE1NTIyODM5N15BMl5BanBnXkFtZTgwOTExMzc2MjE@._V1_SX300.jpg', '1905-07-06'),
(562, 'Dedh Ishqiya', 'A team of con men fall for a Begum and her female confidante. Does their love fructify?', 'R', '152', 'drama', 'tt2675978', '7', 'https://m.media-amazon.com/images/M/MV5BMTkxMzU3MDMxMV5BMl5BanBnXkFtZTgwMzM5MDk3MDE@._V1_SX300.jpg', '1905-07-06'),
(570, 'Chennai Express', 'Rahul embarks on a journey to a small town in Tamil Nadu to fulfill the last wish of his grandfather: to have his ashes immersed in the Holy water of Rameshwaram. En route, he meets a woman hailing from a unique family down South. As they find love through this journey in the exuberant lands of South India, an unanticipated drive awaits them.', 'PG-13', '141', 'comedy', 'tt2112124', '6.1', 'https://m.media-amazon.com/images/M/MV5BOGYyNDQxOTEtOTIxYS00M2M3LWFmMzEtNWRmNmIyZTlhOWY1XkEyXkFqcGdeQXVyMTA4NjE0NjEy._V1_SX300.jpg', '1905-07-05'),
(578, 'Jinxed', 'Meet the Murphys, a family with never ending bad luck. \"Anything that can go wrong, will go wrong,\" it\'s Murphy\'s law! Over a century ago a witch put a magical curse on their great-great grandfather and the whole family has been jinxed for generations! After Meg Murphy (played by Big Time Rush\'s Ciara Bravo) and her family\'s house is destroyed in yet another freak accident, the family moves into their grandfather\'s house in Harvest Hills. In a not-so-strange case of bad luck, Meg\'s nemesis Ivy is also spending the summer in town. But things start to look up, kind of, when Meg meets a local boy named Brett and he casts another spell on her, a love spell that is! With help from her brother Charlie, Meg more determined than ever, must break the hex on her catastrophically cursed family! Watch this doomed teen try for a normal existence in a world full of hijinks!', 'G', '70', 'comedy', 'tt2934844', '6.3', 'https://m.media-amazon.com/images/M/MV5BNWNlNGM1ODEtMzdjZC00NWFmLTg0ZmUtMjhjZmUwNGQzNTk2XkEyXkFqcGdeQXVyMTUyNjc3NDQ4._V1_SX300.jpg', '1905-07-05'),
(586, 'Ghadi', 'Leba is a music instructor who lives in a small Lebanese town. Social pressure leads him to get married and have children. Lara, his beloved wife, births a girl, later other one and finally Ghadi, a boy with special needs related with Down Syndrome. Ghadi could have been a burden, but he is a cause of pride and joy for all of them —but a test too that proves the intolerance of other people.', 'PG-13', '100', 'comedy', 'tt2552296', '7.3', 'https://m.media-amazon.com/images/M/MV5BMjE3MjU4MzU2OF5BMl5BanBnXkFtZTgwNTEyNTY2MTE@._V1_SX300.jpg', '1905-07-05'),
(594, 'The Battered Bastards of Baseball', 'Hollywood veteran Bing Russell creates the only independent baseball team in the country—alarming the baseball establishment and sparking the meteoric rise of the 1970s Portland Mavericks.', 'R', '80', 'documentation', 'tt3445270', '8', 'https://m.media-amazon.com/images/M/MV5BMzU2MzM4NTQtYWI2MC00YzlkLTgxZTktMTQzZWQzNzEwOTM0XkEyXkFqcGdeQXVyNjc5NjEzNA@@._V1_SX300.jpg', '1905-07-06'),
(610, 'Deliha', 'A woman desperately seeking for a man to love. When he finally arrives, she overlooks him.', 'PG-13', '107', 'comedy', 'tt4003066', '4.5', 'https://m.media-amazon.com/images/M/MV5BMjI5MzQ1OTUxOV5BMl5BanBnXkFtZTgwMzAzNDEwMzE@._V1_SX300.jpg', '1905-07-06'),
(618, 'ABCD', 'When a capable dancer is provoked by the evil design of his employer, naturally he will be out to prove his mettle.', 'PG-13', '136', 'drama', 'tt2321163', '6.3', 'https://m.media-amazon.com/images/M/MV5BMTU3NTk0NjE5Nl5BMl5BanBnXkFtZTcwMTU2ODMwOQ@@._V1_SX300.jpg', '1905-07-05'),
(626, 'Ralphie May: Imperfectly Yours', 'Standup in Las Vegas.', '', '69', 'comedy', 'tt3216296', '5.5', 'https://m.media-amazon.com/images/M/MV5BNWQzMTJjNGEtYjcxOS00OTdkLWJmOWQtODMxZjM4MzU1NjUwXkEyXkFqcGdeQXVyNjE3MjQyNQ@@._V1_SX300.jpg', '1905-07-05'),
(634, 'Pagpag: Siyam na Buhay', 'The movie follows a group of teenagers that are terrorized by an evil spirit. The film revolves around the traditional Filipino belief that one should never go home directly after visiting a wake since it risks bringing evil spirits or the deceased to one\'s home.', '', '105', 'horror', 'tt2996950', '5.5', 'https://m.media-amazon.com/images/M/MV5BM2I4NGFlMDUtNTlhYy00NTIwLWI4ODQtZWZjYTRiNmIwNGRmXkEyXkFqcGdeQXVyMjQxMDgxMjg@._V1_SX300.jpg', '1905-07-05'),
(642, 'Chhota Bheem & Krishna vs Zimbara', 'Chhota Bheem Aur Krishna vs Zimbara is an Indian animated movie featuring Bheem, the star of the Chhota Bheem series. It is the 19th movie of the series. Running Time - 65 mins.', 'G', '64', 'animation', 'tt6417984', '7.2', 'https://m.media-amazon.com/images/M/MV5BOTU5NWE1ZDYtNGVjYy00ZDA5LWE5MWYtNWNhNjQ0YzdiNTAwXkEyXkFqcGdeQXVyODAzNzAwOTU@._V1_SX300.jpg', '1905-07-05'),
(650, 'Giraffada', 'Yacine is the veterinarian of the only zoo remaining in the Palestinian West Bank. He lives alone with his 10-year old son, Ziad. The kid has a special bond with the two giraffes in the zoo. He seems to be the only one to communicate with them. After an air raid in the region the male giraffe dies. His mate, Rita, won’t survive unless the veterinarian finds her a new companion. The only zoo that might provide this animal is located in Tel Aviv ...', '', '85', 'drama', 'tt3132086', '6.3', 'https://m.media-amazon.com/images/M/MV5BNDRiNjI5YjgtNTFkZi00Y2I4LThhYzktOTgxY2QxYmM3NjdiXkEyXkFqcGdeQXVyMzA3Njg4MzY@._V1_SX300.jpg', '1905-07-06'),
(666, 'The Age of Adaline', 'After 29-year-old Adaline recovers from a nearly lethal accident, she inexplicably stops growing older. As the years stretch on and on, Adaline keeps her secret to herself  until she meets a man who changes her life.', 'PG-13', '112', 'fantasy', 'tt1655441', '7.2', 'https://m.media-amazon.com/images/M/MV5BMTAzMTQzMTA2MjheQTJeQWpwZ15BbWU4MDk2MTg2MzUx._V1_SX300.jpg', '1905-07-07'),
(674, 'Goosebumps', 'After moving to a small town, Zach Cooper finds a silver lining when he meets next door neighbor Hannah, the daughter of bestselling Goosebumps series author R.L. Stine. When Zach unintentionally unleashes real monsters from their manuscripts and they begin to terrorize the town, it’s suddenly up to Stine, Zach and Hannah to get all of them back in the books where they belong.', 'PG', '103', 'comedy', 'tt1051904', '6.3', 'https://m.media-amazon.com/images/M/MV5BMjA1OTUzNTQ5Ml5BMl5BanBnXkFtZTgwODQ4NDkxNjE@._V1_SX300.jpg', '1905-07-07'),
(682, 'Hail, Caesar!', 'When a Hollywood star mysteriously disappears in the middle of filming, the studio sends their fixer to get him back.', 'PG-13', '106', 'comedy', 'tt0475290', '6.3', 'https://m.media-amazon.com/images/M/MV5BOTI1M2FlMzItY2VjYS00Y2VkLWI5OTQtMzA0MWMyNmQzZmQ0XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-08'),
(690, 'Little Boy', 'An eight-year-old boy is willing to do whatever it takes to end World War II so he can bring his father home. The story reveals the indescribable love a father has for his little boy and the love a son has for his father.', 'PG-13', '106', 'war', 'tt1810683', '7.3', 'https://m.media-amazon.com/images/M/MV5BMTU5MjMyODcxMF5BMl5BanBnXkFtZTgwMzIwMDM2NDE@._V1_SX300.jpg', '1905-07-07'),
(698, 'Storks', 'Storks is an original story that will look at the birds’ mythical role in bringing new babies into the world.', 'PG', '87', 'animation', 'tt4624424', '5.8', 'https://m.media-amazon.com/images/M/MV5BMTYxNjI3MzcwMF5BMl5BanBnXkFtZTgwOTIyNDY5OTE@._V1_SX300.jpg', '1905-07-08'),
(706, 'Kung Fu Panda 3', 'Continuing his \"legendary adventures of awesomeness\", Po must face two hugely epic, but different threats: one supernatural and the other a little closer to his home.', 'PG', '95', 'comedy', 'tt2267968', '7.1', 'https://m.media-amazon.com/images/M/MV5BMTUyNzgxNjg2M15BMl5BanBnXkFtZTgwMTY1NDI1NjE@._V1_SX300.jpg', '1905-07-08'),
(714, 'Derren Brown: Miracle', 'Illusionist Derren Brown reinvents the concept of \"faith healing\" through a series of stunts that debunk the confines of fear, pain and disbelief.', '', '73', 'documentation', 'tt8599562', '6.5', 'https://m.media-amazon.com/images/M/MV5BMjkxYjQ4ZTMtYWI0My00MmQ2LTk0ZjEtZWEyMTQzMmVkZGE3XkEyXkFqcGdeQXVyMTk3NDAwMzI@._V1_SX300.jpg', '1905-07-08'),
(722, 'Michael Che Matters', '\"SNL\" star Michael Che takes on hot-button topics like inequality, homophobia and gentrification in this stand-up set filmed live in Brooklyn.', '', '60', 'comedy', 'tt6209400', '7.2', 'https://m.media-amazon.com/images/M/MV5BYzMwZGRlN2EtMTc1OS00NWE0LWJjYjMtMDdkYzQ0YTVhMjcxL2ltYWdlL2ltYWdlXkEyXkFqcGdeQXVyNjQ1OTA0ODQ@._V1_SX300.jpg', '1905-07-08'),
(730, 'Gabbar Is Back', 'A vigilante network taking out corrupt officials draws the notice of the authorities.', 'PG-13', '130', 'drama', 'tt2424988', '7.1', 'https://m.media-amazon.com/images/M/MV5BMjFhNDQ5NjEtNDE1ZS00YjYwLTgzMjItN2Y2M2RlMjNhZGI4XkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_SX300.jpg', '1905-07-07'),
(738, 'Mike Birbiglia: My Girlfriend\'s Boyfriend', 'Mike Birbiglia shares a lifetime of romantic blunders and misunderstandings. On this painfully honest but hilarious journey, Birbiglia struggles to find reason in an area where it may be impossible to find: love.', '', '75', 'comedy', 'tt2937390', '8', 'https://m.media-amazon.com/images/M/MV5BYTk2NzdlNTktNmRlNy00NGUxLTg4N2YtOWVmOGYzZDFjYjMwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-07'),
(746, 'Time Out', 'The friendship, laughter and shared love between two brothers is tested when a 14-year-old boy is confronted with the complexities of a simple relationship.  Gaurav finds out that his elder brother Mihir is gay. He is unable to accept this as he looks up to Mihir, a high-school jock whom every girl fancies. Adding to his woes, the girl he fancies \'friend-zones\' him.  \'How to fix your gay kid\' is what their mother types into internet search when Mihir reveals his sexual orientation and wishes to come out of the closet.', '', '98', 'drama', 'tt4396648', '6.1', 'https://m.media-amazon.com/images/M/MV5BMTc4NTE3NTQxNV5BMl5BanBnXkFtZTgwODA1MTc2NjE@._V1_SX300.jpg', '1905-07-07'),
(754, '7 años', 'The drama is centered on four friends and business partners who in one evening are forced to find a way to save their company and themselves. The impossible decision they face is agreeing on who will be the one to sacrifice their freedom to save the others from personal and financial demise. It is a race against time that will put their friendship and sanity to the test. Who will take the fall?', 'R', '76', 'drama', 'tt5517438', '6.7', 'https://m.media-amazon.com/images/M/MV5BMzkwZTRmNzMtYTg3Ni00NzU4LTk4M2UtYzU0ZDQ2OWZiMTY3XkEyXkFqcGdeQXVyMTA0MjU0Ng@@._V1_SX300.jpg', '1905-07-08'),
(762, 'ARQ', 'Two old friends living in a dystopic future become trapped in a mysterious time loop — one that may have something to do with an ongoing battle between an omnipotent corporation and a ragtag band of rebels.', 'R', '88', 'thriller', 'tt5640450', '6.3', 'https://m.media-amazon.com/images/M/MV5BMjAxODQ2MzkyMV5BMl5BanBnXkFtZTgwNjU3MTE5OTE@._V1_SX300.jpg', '1905-07-08'),
(778, 'The Third Party', 'Faced with unfortunate complications beyond her control, go-getter events manager Andi Medina has no other person to turn to. She is then forced to reconnect with her ex-boyfriend, cosmetic surgeon Max Labarador. Much to Andi’s shock, Max is already in a three-year live-in relationship with pediatric oncologist Christian Pilar. With nowhere else to go and left with no other options, she agrees to live with the couple – both parties agreeing into a deal that will change the course of their lives and hearts.', '', '118', 'romance', 'tt6580552', '6.1', 'https://m.media-amazon.com/images/M/MV5BM2NhZDljNzktMDRiYy00YTQwLTkwNGItNzQzNzUwYzBlNmNmXkEyXkFqcGdeQXVyMjU1NDk3NTg@._V1_SX300.jpg', '1905-07-08'),
(786, 'The Next Skin', 'A teenager who went missing and was presumed dead returns home after eight years to find a family deeply affected by his disappearance. Gradually, doubts arise about whether he really is the missing boy or an impostor.', '', '100', 'drama', 'tt4034208', '6.2', 'https://m.media-amazon.com/images/M/MV5BZWFjMTc3NDctNWI5Mi00NmY2LWJhYjItZDJkY2IwZjcxNDUzXkEyXkFqcGdeQXVyNjgyMDc4MDU@._V1_SX300.jpg', '1905-07-08'),
(794, 'The CEO', 'Five top-level staff of a company are selected for a retreat where the new CEO of a global company will be chosen. What starts off as cordial soon goes sour as they attempt to outdo one another to be named \"The CEO.\"', 'PG-13', '105', 'thriller', 'tt5036924', '5.8', 'https://m.media-amazon.com/images/M/MV5BMTk3MTY4NTU4Ml5BMl5BanBnXkFtZTgwOTY0MTc4NjE@._V1_SX300.jpg', '1905-07-08'),
(802, 'Jonah', 'During Carnival in São Paulo, a young man and young woman who knew each other as children meet again after many years and the social barriers that have kept them apart. Bad decisions lead the boy to hide with the girl inside a whale float.', 'PG', '97', 'drama', 'tt7799740', '5.4', 'https://m.media-amazon.com/images/M/MV5BMjE5ZGQ3YzEtODkzYi00ZWQzLWIzMWQtOGIwMzJiZGU4Y2E4XkEyXkFqcGdeQXVyNTM3MDMyMDQ@._V1_SX300.jpg', '1905-07-08'),
(810, 'Budhia Singh: Born to Run', 'Budhia Singh – Born To Run is an Indian biographical sports film directed by Soumendra Padhi. It is based on Budhia Singh, who ran 48 marathons — one of which was from Bhubaneshwar to Puri, when he was a five-year-old.', '', '112', 'drama', 'tt5805252', '7.6', 'https://m.media-amazon.com/images/M/MV5BODdmYjQ4ODItZGE2OC00OTgyLWI4YjItN2E1ZTcwNGQ1OGNjXkEyXkFqcGdeQXVyNjQ2MjQ5NzM@._V1_SX300.jpg', '1905-07-08'),
(818, 'Sky Ladder: The Art of Cai Guo-Qiang', 'Known for his spectacular pyrotechnic displays, Chinese artist Cai Guo-Qiang creates his most ambitious project yet: Sky Ladder, a visionary, explosive event that he pulls off in his hometown in China after 20 years of failed attempts.', '', '80', 'documentation', 'tt5278930', '7.3', 'https://m.media-amazon.com/images/M/MV5BMTUwNjY1NzQzMF5BMl5BanBnXkFtZTgwMDE1ODIyMDI@._V1_SX300.jpg', '1905-07-08'),
(826, 'Liar, Liar, Vampire', 'When ordinary boy Davis suddenly becomes famous at school as people start to believe he\'s actually a vampire, vampire expert Cameron helps him act like a real vampire.', 'G', '69', 'comedy', 'tt4448304', '5.7', 'https://m.media-amazon.com/images/M/MV5BNDU5OTA1ODE1OF5BMl5BanBnXkFtZTgwMzg5NjMwNzE@._V1_SX300.jpg', '1905-07-07'),
(834, 'Audrie & Daisy', 'A documentary film about three cases of rape, that includes the stories of two American high school students, Audrie Pott and Daisy Coleman. At the time of the sexual assaults, Pott was 15 and Coleman was 14 years old. After the assaults, the victims and their families were subjected to abuse and cyberbullying.', '', '98', 'documentation', 'tt5278460', '7.2', 'https://m.media-amazon.com/images/M/MV5BNzM3NDkyMjU1NV5BMl5BanBnXkFtZTgwNjQwNDc4OTE@._V1_SX300.jpg', '1905-07-08'),
(842, 'Always Be My Maybe', 'After being dumped by their respective lovers, Jake and Tintin cross paths at a resort and discover they have much in common.', '', '112', 'romance', 'tt5341036', '6.6', 'https://m.media-amazon.com/images/M/MV5BZThmMGVhZGQtOGZlZS00OGQ3LWJiYmItMjg5Mjc0NGEyZjFiXkEyXkFqcGdeQXVyNTI5NjIyMw@@._V1_SX300.jpg', '1905-07-08'),
(850, 'John Mulaney: The Comeback Kid', 'Armed with boyish charm and a sharp wit, the former \"SNL\" writer offers sly takes on marriage, his beef with babies and the time he met Bill Clinton.', 'PG', '62', 'comedy', 'tt5069564', '7.9', 'https://m.media-amazon.com/images/M/MV5BMDQ3NjU0NmQtYjgyZS00MzIzLWJjNDEtMWY5YjczYjc0MTMyXkEyXkFqcGdeQXVyMjI0MjUyNTc@._V1_SX300.jpg', '1905-07-07'),
(858, 'Aerials', 'Earth is invaded by Aliens from outer space. An intermarried couple living in the city of Dubai are confined to their home due to the uncertainty of the situation. Disconnected from the world outside due to the loss of communication, they explore around their cultural differences in Science in order to understand the reason behind Aliens coming to our planet; only to find themselves caught between a series of extraterrestrial encounters at their very home.', '', '90', 'drama', 'tt5314138', '1.5', 'https://m.media-amazon.com/images/M/MV5BMTYxNDQ4ODQ4OV5BMl5BanBnXkFtZTgwMzU1MTg2NzE@._V1_SX300.jpg', '1905-07-08');
INSERT INTO `movies` (`id`, `Title`, `Description`, `COL 5`, `runtime`, `genres`, `imdb_id`, `rating`, `poster`, `release_date`) VALUES
(866, 'Dil Dhadakne Do', 'On a cruise to celebrate their parents\' 30th wedding anniversary, a brother and sister deal with the impact of family considerations on their romantic lives.', 'PG-13', '170', 'drama', 'tt4110568', '7', 'https://m.media-amazon.com/images/M/MV5BZWMzODAxMDAtMTk1Yi00NjBjLTgyOWYtNjYyNjYxZDg1NGU4L2ltYWdlL2ltYWdlXkEyXkFqcGdeQXVyNTM3NDI3MzQ@._V1_SX300.jpg', '1905-07-07'),
(882, 'Pandora', 'When an earthquake hits a Korean village housing a run-down nuclear power plant, a man risks his life to save the country from imminent disaster.', 'R', '136', 'action', 'tt6302160', '6.6', 'https://m.media-amazon.com/images/M/MV5BNmExNmZiZTYtYmY2My00YmRhLThjZWYtOGM4ODIwNDZhNDZhL2ltYWdlXkEyXkFqcGdeQXVyNzE5MDMyMzk@._V1_SX300.jpg', '1905-07-08'),
(890, 'Everyday I Love You', 'Two people bound together in the same road and fall for each other in an unexpected way.', '', '122', 'drama', 'tt4944460', '7', 'https://m.media-amazon.com/images/M/MV5BYTI5YjJhNGMtYTIzNi00ZmYyLTg0ZGEtNjM2MDU1MTk0YjFhXkEyXkFqcGdeQXVyNTI5NjIyMw@@._V1_SX300.jpg', '1905-07-07'),
(898, 'Wedding Association 2: Circumcision', 'Ismail and his old screwball crew land themselves in hot water when his grandson\'s circumcision evolves into a buzz-making citywide event.', 'PG-13', '107', 'comedy', 'tt5114588', '6.3', 'https://m.media-amazon.com/images/M/MV5BMTc0MjMzMzIwMl5BMl5BanBnXkFtZTgwNTg0NDQxNzE@._V1_SX300.jpg', '1905-07-07'),
(906, 'The Breakup Playlist', 'A story about an aspiring professional singer and a rock singer who collaborates in a song. As they work on their song, they start to develop feelings for each other.', '', '117', 'romance', 'tt4628812', '6.5', 'https://m.media-amazon.com/images/M/MV5BMGM2YzZmZTYtYzc3Ny00ZjNiLWJiYmYtNjljMjUyNWIwM2M3XkEyXkFqcGdeQXVyNDkwMzY5NjQ@._V1_SX300.jpg', '1905-07-07'),
(914, 'Aziz Ansari: Live at Madison Square Garden', 'Ansari headlines the iconic Madison Square Garden and delivers his most hilarious and insightful stand-up yet. Filmed in front of a sold-out audience, Ansari\'s latest special is an uproarious document of the comic in top form -- covering topics ranging from the struggle of American immigrants to the food industry to relationships to gender inequality.', '', '58', 'comedy', 'tt4530184', '6.6', 'https://m.media-amazon.com/images/M/MV5BZDI2OGFlZmYtZDVjYy00ODU3LTg2MWMtOTNmYWYyNTljOTE4XkEyXkFqcGdeQXVyNDg1NjA2OA@@._V1_SX300.jpg', '1905-07-07'),
(922, 'Patton Oswalt: Talking for Clapping', 'Patton Oswalt delivers a fresh hour plus of stand-up, covering everything from misery to defeat to hopelessness. It\'s his most upbeat special to date.', '', '65', 'comedy', 'tt5457520', '6.8', 'https://m.media-amazon.com/images/M/MV5BZmMyYzAzMzktOWM4MS00YmI2LThmM2MtNjBkODZkOWQxODNmXkEyXkFqcGdeQXVyNjYzMDA4MTI@._V1_SX300.jpg', '1905-07-08'),
(930, 'Carlos Ballarta: el amor es de putos', 'Carlos Ballarta mocks daily life in Mexico, including public transit, the education system and the corn seller who betrays your confidence', '', '67', 'comedy', 'tt6268852', '7.1', 'https://m.media-amazon.com/images/M/MV5BMGFmODM3NzktYWZlYy00ZjY0LTgwMzQtMTM3MzI3ZjQ5MzA4L2ltYWdlL2ltYWdlXkEyXkFqcGdeQXVyNjU0NjM4NTI@._V1_SX300.jpg', '1905-07-08'),
(946, 'Do Paise Ki Dhoop, Chaar Aane Ki Baarish', 'When a sex worker hires a gay songwriter to care for her disabled son, the ensuing bonds that form offer a complex portrayal of love and family.', '', '121', 'drama', 'tt1935782', '6.6', 'https://m.media-amazon.com/images/M/MV5BZWI1YTY4ZmEtN2QyZC00YTFiLWI4MzUtM2VhOWMwNjNlZjIyXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-08'),
(954, 'The Flower of Aleppo', 'Salma is a 37 years old paramedic nurse working in private and public hospitals in Tunisia. When her only son, Murad, go to Syria to join the terrorist movement Al-Nusra Front, Salma infiltrate the jihadists with the aim to bring her son back to Tunisia.', '', '100', 'drama', 'tt5448246', '5.4', 'https://m.media-amazon.com/images/M/MV5BMjliZjRmNjEtMzIxNC00YzA0LWEwMGYtMjFiZjI3MWEzNDk0XkEyXkFqcGdeQXVyMTg3MDEwNA@@._V1_SX300.jpg', '1905-07-08'),
(962, 'Motu Patlu Aur Khazaane Ki Race', 'Motu and Patlu rescue a dog from a group of evil men. They find out that the men were sent by Mr Chamko to steal a locket the dog is wearing, which is the key to a hidden treasure.', '', '75', 'animation', 'tt20765946', '', 'https://m.media-amazon.com/images/M/MV5BZDdkZjk1YTAtYjk1YS00NGY2LThjYzgtZDMxNGFjOTM5MzFlXkEyXkFqcGdeQXVyNjkyODEzOTM@._V1_SX300.jpg', '1905-07-07'),
(970, 'Raw', 'In Justine’s family everyone is a vet and a vegetarian. At 16, she’s a gifted teen ready to take on her first year in vet school, where her older sister also studies. There, she gets no time to settle: hazing starts right away. Justine is forced to eat raw meat for the first time in her life. Unexpected consequences emerge as her true self begins to form.', 'R', '99', 'horror', 'tt4954522', '7', 'https://m.media-amazon.com/images/M/MV5BMTU3MDUxMDI0MV5BMl5BanBnXkFtZTgwMzk3OTg3MDI@._V1_SX300.jpg', '1905-07-09'),
(978, 'The Ritual', 'A group of college friends reunite for a trip to the forest, but encounter a menacing presence in the woods that\'s stalking them.', 'R', '104', 'thriller', 'tt5638642', '6.3', 'https://m.media-amazon.com/images/M/MV5BMjAzMzAyMDI4Ml5BMl5BanBnXkFtZTgwODMwOTY2NDM@._V1_SX300.jpg', '1905-07-09'),
(986, 'Peppermint', 'A grieving mother transforms herself into a vigilante following the murders of her husband and daughter, eluding the authorities to deliver her own personal brand of justice.', 'R', '100', 'thriller', 'tt6850820', '6.5', 'https://m.media-amazon.com/images/M/MV5BNWVlMjQ3MjItOWE3YS00YTYwLWE0ZDMtZWMyZWY1NzkxNWIwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-10'),
(994, 'Rip Tide', 'There comes a point in everyone’s life when you have to make a decision about the direction you’re going to take. For newly-18 American fashion model Cora, that time is now. She’s moved to an Australian coastal town to be with her favourite aunt, after a \'fashion faux pas’ back home.', '', '85', 'drama', 'tt6262764', '5.5', 'https://m.media-amazon.com/images/M/MV5BNzA5OWFiZDEtYTliOS00YWNmLTljMjYtYWFjODYxNDY4MDVhXkEyXkFqcGdeQXVyNDY1NTI0OA@@._V1_SX300.jpg', '1905-07-09'),
(1002, 'The Ballad of Buster Scruggs', 'Vignettes weaving together the stories of six individuals in the old West at the end of the Civil War. Following the tales of a sharp-shooting songster, a wannabe bank robber, two weary traveling performers, a lone gold prospector, a woman traveling the West to an uncertain future, and a motley crew of strangers undertaking a carriage ride.', 'R', '132', 'western', 'tt6412452', '7.3', 'https://m.media-amazon.com/images/M/MV5BYjRkYTI3M2EtZWQ4Ny00OTA2LWFmMTMtY2E4MTEyZmNjOTMxXkEyXkFqcGdeQXVyNDg4NjY5OTQ@._V1_SX300.jpg', '1905-07-10'),
(1010, 'Reversing Roe', 'Documentary that delves deep into the history of abortion law, revealing the contradictory ways in which women\'s bodies have been used to further political and ideological agendas.', '', '99', 'documentation', 'tt8948614', '7.5', 'https://m.media-amazon.com/images/M/MV5BOTg1NzE4NDcxMl5BMl5BanBnXkFtZTgwNzE2MzEzNjM@._V1_SX300.jpg', '1905-07-10'),
(1018, 'Oh, Hello on Broadway', 'Two delusional geriatrics reveal curious pasts, share a love of tuna and welcome a surprise guest in this filming of the popular Broadway comedy show.', '', '102', 'comedy', 'tt6987652', '7.7', 'https://m.media-amazon.com/images/M/MV5BZmQ3YmM0NGMtYmRmNi00ZWY4LTk5MGYtYzUyODA4ODBlODE3XkEyXkFqcGdeQXVyMjQzNzk2ODk@._V1_SX300.jpg', '1905-07-09'),
(1026, 'The Chase', 'After people in his town start turning up dead, a grumpy landlord is visited by a man who recounts an unsolved serial murder case from 30 years ago that may hold the clue to what is happening now.', '', '110', 'thriller', 'tt8088944', '6.6', 'https://m.media-amazon.com/images/M/MV5BYWZkNzYwZmQtNDZlNS00NTE4LWE0NjMtZjUwYjgwMWU0OGQwXkEyXkFqcGdeQXVyMjc2Nzg5OTQ@._V1_SX300.jpg', '1905-07-09'),
(1034, 'Time Share', 'While staying at a tropical resort, a man becomes convinced the American timeshare company running it has an evil plan to take away his loved ones.', '', '96', 'drama', 'tt11481668', '5.9', 'https://m.media-amazon.com/images/M/MV5BNDNiN2YzMzAtM2QxMS00ZjA1LWI5OTgtOTk0ODYzZDM0MTBmXkEyXkFqcGdeQXVyMTExNDMwNzE5._V1_SX300.jpg', '1905-07-10'),
(1042, 'Mom', 'After her stepdaughter is sexually assaulted at a party, a furious mother sets out to destroy the lives of the four perpetrators who walked free.', '', '147', 'crime', 'tt5690142', '7.2', 'https://m.media-amazon.com/images/M/MV5BOTc0YTJhZDktMGViYi00NjIwLThiMDEtY2E4NWFkYWQxNjQ5XkEyXkFqcGdeQXVyNjQ2MjQ5NzM@._V1_SX300.jpg', '1905-07-09'),
(1058, 'Fred Armisen: Standup for Drummers', 'For an audience of drummers, comedian Fred Armisen shares and demonstrates his thoughts on musical genres, drummer quirks, regional accents and more.', '', '65', 'music', 'tt7924798', '5.8', 'https://m.media-amazon.com/images/M/MV5BZjgwZjQ5OTgtMWY0MC00YTQ5LWE2MzEtMWEyYTc5ODhlMTQyXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-10'),
(1066, 'Jim Gaffigan: Cinco', 'America\'s king of clean comedy delivers wickedly funny jokes in his fifth hour-long special.', '', '73', 'comedy', 'tt6090102', '7.1', 'https://m.media-amazon.com/images/M/MV5BYzM5N2YyODQtZTkyMC00ZGVhLWJmZmYtZTI3ZGM2ODAzMzA1L2ltYWdlXkEyXkFqcGdeQXVyMzcwMjcwNQ@@._V1_SX300.jpg', '1905-07-09'),
(1074, 'The Photographer of Mauthausen', 'Spanish photographer Francesc Boix, imprisoned in the Mauthausen-Gusen concentration camp, works in the SS Photographic Service. Between 1943 and 1945, he hides, with the help of other prisoners, thousands of negatives, with the purpose of showing the freed world the atrocities committed by the Nazis, exhaustively documented. He will be a key witness during the Nuremberg Trials.', 'R', '111', 'thriller', 'tt6704776', '6.7', 'https://m.media-amazon.com/images/M/MV5BYzQzMGEzZGMtYzVjZi00OGYwLWJmYWMtNGE2OTUwNzc2MGEwXkEyXkFqcGdeQXVyMTYzMDM0NTU@._V1_SX300.jpg', '1905-07-10'),
(1082, 'Can\'t Stop, Won\'t Stop: A Bad Boy Story', 'A behind-the-scenes look at the prolific label\'s legacy and offer an in-depth look at the two-night anniversary extravaganza that took place last May at Brooklyn\'s Barclays Center in honor of the late rap great, The Notorious B.I.G.', 'R', '80', 'music', 'tt6628790', '5.4', 'https://m.media-amazon.com/images/M/MV5BMjQ3OTE4MTYyOV5BMl5BanBnXkFtZTgwMjg3MzcxMjI@._V1_SX300.jpg', '1905-07-09'),
(1090, 'Happy Anniversary', 'A quirky couple spends their three-year dating anniversary looking back at their relationship and contemplating whether they should break up.', '', '78', 'romance', 'tt6423886', '5.7', 'https://m.media-amazon.com/images/M/MV5BMzdmNjljMGMtZDBlZC00N2NjLTgyMTctMzU5M2VhYTkzYjRlXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-10'),
(1098, 'Our Souls at Night', 'Addie Moore and Louis Waters, a widow and widower, have lived next to each other for years. The pair have almost no relationship, but that all changes when Addie tries to make a connection with her neighbour.', '', '101', 'romance', 'tt5034266', '6.9', 'https://m.media-amazon.com/images/M/MV5BMzU4ODQ5MDc5OV5BMl5BanBnXkFtZTgwMjk4MDM1MzI@._V1_SX300.jpg', '1905-07-09'),
(1106, 'A-X-L', 'The life of a teenage boy is forever altered by a chance encounter with cutting edge military technology.', 'PG-13', '98', 'scifi', 'tt5709188', '5.3', 'https://m.media-amazon.com/images/M/MV5BMzhmMWY5YzYtNGU0OS00OWExLWE4MTEtZjdmZTczNGEwNjhmXkEyXkFqcGdeQXVyMjM4NTM5NDY@._V1_SX300.jpg', '1905-07-10'),
(1115, 'The Seven Deadly Sins: Prisoners of the Sky', 'Traveling in search of the rare ingredient, “sky fish”  Meliodas and Hawk arrive at a palace that floats above the clouds. The people there are busy preparing a ceremony, meant to protect their home from a ferocious beast that awakens once every 3,000 years. But before the ritual is complete, the Six Knights of Black—a Demon Clan army—removes the seal on the beast, threatening the lives of everyone in the Sky Palace.', 'PG-13', '99', 'action', 'tt9089294', '7.1', 'https://m.media-amazon.com/images/M/MV5BODIwNzk5YTAtNDNjZS00YzdmLWI3YzMtZTIwNTljZjcxOGY5XkEyXkFqcGdeQXVyOTYzOTg3MTY@._V1_SX300.jpg', '1905-07-10'),
(1123, 'Love per Square Foot', 'Individually, bank employees Sanjay and Karina don\'t earn enough to be able to buy a home, so they decide to enter into a marriage of convenience.', '', '133', 'romance', 'tt7853242', '7.2', 'https://m.media-amazon.com/images/M/MV5BMzM4NGVhYjQtMTM5OS00ZmQ5LTg3NzktZDY5NzMwNmI4YzRmXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-10'),
(1131, 'On My Skin', 'The incredible true story behind the most controversial Italian court cases in recent years. Stefano Cucchi was arrested for a minor crime and mysteriously found dead during his detention. In one week\'s time, a family is changed forever.', '', '100', 'drama', 'tt7121252', '7.3', 'https://m.media-amazon.com/images/M/MV5BYWQ5Mzg4NGUtZGVlMi00YWM1LTg2NWItZWNkNGVmZmJlZWQyXkEyXkFqcGdeQXVyMzIwNDY4NDI@._V1_SX300.jpg', '1905-07-10'),
(1139, 'Nothing to Hide', 'To spice up a dinner party, old friends agree to share every private message that pops up on their phones -- with disastrous results.', '', '93', 'drama', 'tt7489816', '6.8', 'https://m.media-amazon.com/images/M/MV5BZDBkYWJlNmYtMWM2Yy00NzJkLWIyZWItNWJhZTZhNDBkZDc5XkEyXkFqcGdeQXVyNTc5OTMwOTQ@._V1_SX300.jpg', '1905-07-10'),
(1147, 'Burn Out', 'Tony, a promising young motorcycle racer, is forced to do perilous drug runs to save the mother of his child from a dangerous mobster.', '', '107', 'thriller', 'tt6340604', '6.2', 'https://m.media-amazon.com/images/M/MV5BYzFmOGFjMjEtNDI4Mi00YTNiLThiNzQtMDU2MWMyOGUxZGY5XkEyXkFqcGdeQXVyMzU5OTE2NTI@._V1_SX300.jpg', '1905-07-10'),
(1155, 'Gerald\'s Game', 'When her husband\'s sex game goes wrong, Jessie (who is handcuffed to a bed in a remote lake house) faces warped visions, dark secrets and a dire choice.', '', '104', 'horror', 'tt3748172', '6.5', 'https://m.media-amazon.com/images/M/MV5BMzg0NGE0N2MtYTg1My00NTBkLWI5NjEtZTgyMDA0MTU4MmIyXkEyXkFqcGdeQXVyMTU2NTcyMg@@._V1_SX300.jpg', '1905-07-09'),
(1163, 'I Am Jonas', 'When Jonas was 14 he met the charismatic but mysterious Nathan. In addition to guiding him in his sexuality, Jonas soon confronts something dark and even dangerous about his new friend. Now an attractive, sexually assured adult, memories still haunt him. Trying frantically to put the missing pieces together, Jonas becomes determined to break the shackles of the past and finally set himself free.', '', '82', 'drama', 'tt8168186', '7', 'https://m.media-amazon.com/images/M/MV5BNDNkYmM1YzItMGNjMC00MWYwLTliYmMtZDU2ZDU0M2Y4NmQ2XkEyXkFqcGdeQXVyMjE4NzY3Mw@@._V1_SX300.jpg', '1905-07-10'),
(1171, 'Maria Bamford: Old Baby', 'She\'s savagely upbeat. Lovably awkward. And full of surprises. A wildly funny trip through a one-of-a-kind comic mind.', '', '64', 'comedy', 'tt6264596', '6.1', 'https://m.media-amazon.com/images/M/MV5BNDZjYzVjNTAtOThkYS00ODhjLWI0ODYtNDIxODVhY2MxZjJmXkEyXkFqcGdeQXVyMzcwMjcwNQ@@._V1_SX300.jpg', '1905-07-09'),
(1179, 'To All the Boys I\'ve Loved Before', 'Lara Jean\'s love life goes from imaginary to out of control when her secret letters to every boy she\'s ever fallen for are mysteriously mailed out.', 'PG-13', '100', 'romance', 'tt3846674', '7.1', 'https://m.media-amazon.com/images/M/MV5BMjQ3NjM5MTAzN15BMl5BanBnXkFtZTgwODQzMDAwNjM@._V1_SX300.jpg', '1905-07-10'),
(1187, 'Escape from Mr. Lemoncello\'s Library', 'Can twelve 12-year-olds escape from the most ridiculously brilliant library ever created? Escape from Mr. Lemoncello\'s Library plunks a dozen sixth-graders into the middle of a futuristic library for a night of nonstop fun and adventure.', 'G', '79', 'fantasy', 'tt5878476', '5.3', 'https://m.media-amazon.com/images/M/MV5BZGEyYTM4NGQtYzM2Ni00Mjc2LTg3ZWMtYWQ1MWE1MmVmN2M3XkEyXkFqcGdeQXVyOTY2MzE5Mg@@._V1_SX300.jpg', '1905-07-09'),
(1195, 'Jack Whitehall: At Large', 'Comedian Jack Whitehall takes the stage to tell stories about drinking, drugs, a Google Maps van and his ongoing rivalry with Robert Pattinson.', '', '67', 'comedy', 'tt7539884', '6.9', 'https://m.media-amazon.com/images/M/MV5BNTRhOTBhYzMtZDI2MC00MDBmLThmNjEtOGU4MTc1ODVjOTFmXkEyXkFqcGdeQXVyODE2MTgyODY@._V1_SX300.jpg', '1905-07-09'),
(1203, 'Okja', 'A young girl named Mija risks everything to prevent a powerful, multi-national company from kidnapping her best friend - a massive animal named Okja.', 'PG-13', '120', 'fantasy', 'tt3967856', '7.3', 'https://m.media-amazon.com/images/M/MV5BMjQxMTcxNDgxN15BMl5BanBnXkFtZTgwOTczNTIzMjI@._V1_SX300.jpg', '1905-07-09'),
(1211, 'The Cloverfield Paradox', 'Orbiting above a planet on the brink of war, scientists test a device to solve an energy crisis and end up face-to-face with a dark alternate reality.', 'PG-13', '102', 'action', 'tt2548396', '5.5', 'https://m.media-amazon.com/images/M/MV5BMTAwOTIxMDA0MjZeQTJeQWpwZ15BbWU4MDg1MjgzNzQz._V1_SX300.jpg', '1905-07-10'),
(1219, 'Jefe', 'Cesar is \'the boss\', the one everyone hates, the one some flatter and the one nobody tells the truth; the great successful businessman is on the edge of the precipice. One night his actions crumble down, his partners betray him and his wife kicks him out of the house. Entrenched in his office, he tries relentlessly to recover his company and his life. But he will not do it alone, César will find a very special ally, Ariana, the cleaner of the night shift.', '', '89', 'comedy', 'tt7527538', '5.5', 'https://m.media-amazon.com/images/M/MV5BYTEzMTg2Y2ItOWQ3YS00NWQwLWIxMDItNjA2MmM4MzZlMWFhXkEyXkFqcGdeQXVyMTM5NTA5NjM@._V1_SX300.jpg', '1905-07-10'),
(1227, 'The Guernsey Literary & Potato Peel Pie Society', 'Free-spirited writer Juliet Ashton forms a life-changing bond with the delightful and eccentric Guernsey Literary and Potato Peel Pie Society, when she decides to write about the book club they formed during the occupation of Guernsey in WWII.', '', '124', 'history', 'tt1289403', '7.3', 'https://m.media-amazon.com/images/M/MV5BNjIyNzhhMmQtMjNlZS00MGRkLWE0ODgtY2E4MGMzMjk2M2IzXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-10'),
(1235, 'The Set Up', 'A young woman gets more than she bargains for and is drawn into a web of deceit when she is hired by a socialite to assist with his scheme to marry a wealthy heiress.', '', '105', 'drama', 'tt10397734', '6.8', 'https://m.media-amazon.com/images/M/MV5BYzQwZDhkYjQtZjNiNy00YTYzLTk1YTktNTQ4YTI4YTU2YTQ5XkEyXkFqcGdeQXVyNTMzODgyMDQ@._V1_SX300.jpg', '1905-07-09'),
(1243, 'Apostle', 'In 1905, a man travels to a remote island in search of his missing sister who has been kidnapped by a mysterious religious cult.', 'R', '130', 'horror', 'tt6217306', '6.3', 'https://m.media-amazon.com/images/M/MV5BMTY1NDk0NjI4MV5BMl5BanBnXkFtZTgwNjUyNzMwNjM@._V1_SX300.jpg', '1905-07-10'),
(1251, 'War Machine', 'A rock star general bent on winning the “impossible” war in Afghanistan takes us inside the complex machinery of modern war. Inspired by the true story of General Stanley McChrystal.', 'R', '122', 'drama', 'tt4758646', '6', 'https://m.media-amazon.com/images/M/MV5BMTcyMzgwNDE1M15BMl5BanBnXkFtZTgwMDAzMDM0MjI@._V1_SX300.jpg', '1905-07-09'),
(1259, 'Bleach', 'High school student Ichigo Kurosaki lives an ordinary life, besides being able to see ghosts and the blurry memories of his mother\'s death under strange circumstances when he was a kid. His peaceful world suddenly breaks as he meets Rukia Kuchiki, a God of Death.', 'PG-13', '108', 'action', 'tt5979872', '6.4', 'https://m.media-amazon.com/images/M/MV5BMjM1MmU1MmItOWY5MS00NmRjLThkMGMtMDQwOTliMWIxZTdlXkEyXkFqcGdeQXVyNzI1NzMxNzM@._V1_SX300.jpg', '1905-07-10'),
(1267, 'Mudbound', 'In the post–World War II South, two families are pitted against a barbaric social hierarchy and an unrelenting landscape as they simultaneously fight the battle at home and the battle abroad.', 'R', '135', 'drama', 'tt2396589', '7.4', 'https://m.media-amazon.com/images/M/MV5BZTg3YTEzNjYtZTY2NS00YjNmLTlhNjUtZTI2M2E5NDI4M2NjXkEyXkFqcGdeQXVyMzI3MDEzMzM@._V1_SX300.jpg', '1905-07-09'),
(1275, 'D.L. Hughley: Contrarian', 'Comedian D.L. Hughley riffs on politics, \"Black Panther,\" his upbringing and more in a rapid-fire stand-up show at Philadelphia\'s Merriam Theater.', '', '58', 'comedy', 'tt8426270', '6.6', 'https://m.media-amazon.com/images/M/MV5BZmRjYjFmNGEtM2E3Zi00YzY0LWEwZjUtZjE1YTkxZTJkZGFkXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '1905-07-10'),
(1283, 'Win It All', 'A gambling addict faces a conflict when entrusted with keeping a bunch of money that isn\'t his.', '', '88', 'comedy', 'tt3155328', '6.2', 'https://m.media-amazon.com/images/M/MV5BNTEzOTYzOTctMDBjNi00NzMyLTkzNjgtYTIyNDAxOWNiMDIxXkEyXkFqcGdeQXVyMzI3MDEzMzM@._V1_SX300.jpg', '1905-07-09'),
(1291, 'The Zookeeper\'s Wife', 'The account of keepers of the Warsaw Zoo, Jan and Antonina Zabinski, who helped save hundreds of people and animals during the Nazi invasion.', 'PG-13', '124', 'history', 'tt1730768', '7', 'https://m.media-amazon.com/images/M/MV5BNTY3YmZmYmMtZjc3Zi00N2VjLWE5ZGMtN2M0ODkzOGQ5M2UyL2ltYWdlL2ltYWdlXkEyXkFqcGdeQXVyNTk1MTQ3NDI@._V1_SX300.jpg', '1905-07-09'),
(1299, 'Garbage', 'Taxi driver Phanishwar is living with a mysterious girl, Nanaam, who he keeps in chains. When a medical student, Rami, a victim of revenge porn leaked online by an ex-boyfriend, seeks refuge in Goa, she stumbles into the strange but placid lives of Phanishwar and Nanaam.', '', '105', 'thriller', 'tt7981260', '3.8', 'https://m.media-amazon.com/images/M/MV5BNDk0MjUzZWMtYzFhMi00NDMxLWE0YmItYTk5OTEzNzkxMDI1XkEyXkFqcGdeQXVyODUzNjQyMzY@._V1_SX300.jpg', '1905-07-10'),
(1307, 'Day of the Dead: Bloodline', 'In a world overrun by zombies, military personnel and survivalists live in an underground bunker while they seek a cure.', 'R', '90', 'action', 'tt3053228', '3.4', 'https://m.media-amazon.com/images/M/MV5BMjE2MTg1NDQ2MF5BMl5BanBnXkFtZTgwMDkxMzMzNDM@._V1_SX300.jpg', '1905-07-09'),
(1315, 'Up North', 'Jules has just moved back home. She has no idea what she\'s doing or where she\'s going next.', '', '10', 'drama', 'tt8631800', '5.4', 'https://m.media-amazon.com/images/M/MV5BMzRmZjhmZDctZjA2My00ZGE4LWE2YjEtOGI4NDE1OGIzYjdjXkEyXkFqcGdeQXVyODk1MTM1NjI@._V1_SX300.jpg', '1905-07-10'),
(1323, 'Munafik 2', 'Ustaz Adam has to help a friend whose village is corrupted by a group of misguided religionists lead by a sinister sorcerer. To make matter worse, Adam himself is also being mysteriously haunted by evil apparitions that keeps disturbing him from time to time.', '', '104', 'thriller', 'tt7059506', '5.6', 'https://m.media-amazon.com/images/M/MV5BN2RlYWNjOGUtZTllMi00NjA5LWFmZmItZWI2N2VmOWRjYjc3XkEyXkFqcGdeQXVyNTg2MDI2Njc@._V1_SX300.jpg', '1905-07-10'),
(1363, 'Yoo Byung Jae: Too Much Information', '\"Saturday Night Live Korea\" writer-turned-comedian Yoo Byung-jae lays bare his childhood memories and philosophy on sex in his first stand-up venture.', '', '63', 'comedy', 'tt8140738', '5.5', '', '1905-07-10'),
(1371, 'Bad Genius', 'Lynn, a brilliant student, after helping her friends to get the grades they need, develops the idea of starting a much bigger exam-cheating business.', 'PG-13', '130', 'thriller', 'tt6788942', '7.6', '', '1905-07-09'),
(1379, 'Payday', 'After an expensive night out, two flatmates get tangled in an overnight misadventure to recover their rent money to pay their dead landlord\'s daughter.', '', '110', 'comedy', 'tt8960334', '5.5', '', '1905-07-10'),
(1387, 'DreamWorks Home: For the Holidays', 'Oh takes it upon himself to introduce Christmas joy to his fellow Boovs. Unfortunately, his well-meaning mission nearly destroys the city.', 'PG-13', '45', 'scifi', 'tt7713204', '4.9', '', '1905-07-09'),
(1395, 'Jen Kirkman: Just Keep Livin\'?', 'Incisive comic Jen Kirkman gets real about women\'s bodies, the value of alone time and an Italian private tour guide who may have been a ghost.', '', '69', 'comedy', 'tt6386352', '6.8', '', '1905-07-09'),
(1403, 'Indian Horse', 'Follows the life of Native Canadian Saul Indian Horse as he survives residential school and life amongst the racism of the 1970s. A talented hockey player, Saul must find his own path as he battles stereotypes and alcoholism.', 'PG-13', '96', 'drama', 'tt5672286', '7.3', '', '1905-07-10'),
(1411, 'Security', 'An ex-special services veteran, down on his luck and desperate for work, takes a job as a security guard at a run-down mall in a rough area of town. On his first night on the job, he opens the door to a distraught and desperate young girl who has fled the hijacking of a Police motorcade that was transporting her to testify as a witness in a trial. Hot on her heels is the psychopathic hijacker and his team of henchmen, who will stop at nothing to extract and eliminate the witness.', 'R', '91', 'thriller', 'tt3501112', '5.7', '', '1905-07-09'),
(1419, 'Hold the Dark', 'In the grim Alaskan winter, a naturalist hunts for wolves blamed for killing a local boy, but he soon finds himself swept into a chilling mystery.', '', '126', 'thriller', 'tt5057140', '5.6', '', '1905-07-10'),
(1427, 'Maz Jobrani: Immigrant', 'Iranian American comic Maz Jobrani lights up the Kennedy Center with riffs on immigrant life in the Trump era, modern parenting pitfalls and more.', '', '67', 'comedy', 'tt7164714', '6.7', '', '1905-07-09'),
(1435, 'The Last Runaway', 'Former Colonel Fernandez is appointed Minister of the National Anti-Drug Agency (SENAD) and purges the special forces to fight the first of many battles against drug trafficking on the border of Paraguay and Argentina.', '', '107', 'action', 'tt7606620', '5.9', '', '1905-07-10'),
(1443, 'On Body and Soul', 'Two introverted people find out by pure chance that they share the same dream every night. They are puzzled, incredulous, a bit frightened. As they hesitantly accept this strange coincidence, they try to recreate in broad daylight what happens in their dream.', '', '116', 'romance', 'tt5607714', '7.5', '', '1905-07-09'),
(1451, 'Mirage', 'During a mysterious thunderstorm, Vera, a young mother, manages to save a life in danger, but her good deed causes a disturbing chain of unexpected consequences.', 'R', '129', 'drama', 'tt6908274', '7.4', '', '1905-07-10'),
(1459, 'Fishtronaut: The Movie', 'Fishtronaut, Marina and Zeek travel to the big city in search of Grandpa, only to find that everyone else has mysteriously vanished too.', 'G', '88', 'animation', 'tt7804254', '7.6', '', '1905-07-10'),
(1467, 'The World Is Yours', 'To escape his life of crime, a Paris drug dealer takes on one last job involving Spain, unhinged gangsters, his longtime crush and his scheming mother.', 'R', '94', 'comedy', 'tt6892462', '6.3', '', '1905-07-10'),
(1483, 'I Am Not an Easy Man', 'The chauvinist Damien wakes up in a world where women and men have their roles reversed in society, and everything is dominated by women.', '', '98', 'fantasy', 'tt6857988', '6.3', '', '1905-07-10'),
(1491, 'Kavin Jay : Everybody Calm Down!', 'On a mission to defy stereotypes, Malaysian stand-up comedian Kavin Jay shares stories about growing up in the VHS era with his Singapore audience.', '', '53', 'comedy', 'tt7924764', '6', '', '1905-07-10'),
(1499, 'The Resistance Banker', 'In the occupied Netherlands during World War II, banker Walraven van Hall is asked to use his financial contacts to help the Dutch resistance. With his brother Gijs, he comes up with a risky plan to take out huge loans and use the money to finance the Resistance.', 'R', '124', 'drama', 'tt4610378', '6.9', '', '1905-07-10'),
(1507, 'Joan Didion: The Center Will Not Hold', 'Griffin Dunne’s years-in-the-making documentary portrait of his aunt Joan Didion moves with the spirit of her uncannily lucid writing: the film simultaneously expands and zeroes in, covering a vast stretch of turbulent cultural history with elegance and candor.', '', '92', 'documentation', 'tt7253506', '7.5', '', '1905-07-09'),
(1515, 'Can\'t Help Falling in Love', 'Gab de la Cuesta is a high-strung career woman who got recently engaged to her longtime boyfriend. Her well-planned life suddenly becomes complicated when she discovers that she is actually married to a total stranger.', '', '119', 'romance', 'tt6725484', '6.9', '', '1905-07-09'),
(1523, 'Creep 2', 'After finding an ad online for “video work,” Sara, a video artist whose primary focus is creating intimacy with lonely men, thinks she may have found the subject of her dreams. She drives to a remote house in the forest and meets a man claiming to be a serial killer. Unable to resist the chance to create a truly shocking piece of art, she agrees to spend the day with him. However, as the day goes on, she discovers she may have dug herself into a hole from which she can’t escape.', 'R', '80', 'horror', 'tt3654796', '6.4', '', '1905-07-09'),
(1531, 'The Polka King', 'Local Pennsylvania polka legend Jan Lewan develops a plan to get rich that shocks his fans and lands him in jail.', '', '95', 'comedy', 'tt5539052', '6', '', '1905-07-10'),
(1539, 'The Invisible Guardian', 'When the naked body of a teenage girl is found on the banks of the River Baztán, it is quickly linked to a similar murder one month before. Soon, rumours are flying in the nearby village of Elizondo. Is this the work of a ritualistic killer or is it the basajaun, the ‘invisible guardian’ of Basque mythology?  Inspector Amaia Salazar leads the investigation, taking her back to the heart of the Basque country where she was born, and where she hoped never to return. Shrouded in mist and surrounded by impenetrable forests, it is a place of unresolved conflicts and a terrible secret from Amaia’s childhood that will come back to haunt her.  Faced with the superstitions of the village, Amaia must fight the demons of her past to confront the reality of a serial killer on the loose. But as she is drawn deeper into the investigation, she feels the presence of something darker lurking in the shadows…', '', '129', 'thriller', 'tt4924942', '6.4', '', '1905-07-09'),
(1547, 'Todo lo que sería Lucas Lauriente', 'In his stand-up set, Argentine comic Lucas Lauriente animatedly rattles off reflections on different generations and begs kids to stop saying \"goals.\"', '', '78', 'comedy', 'tt7607452', '7', '', '1905-07-10'),
(1555, 'Pope Francis: A Man of His Word', 'Pope Francis responds to questions from around the world, discussing topics including ecology, immigration, consumerism and social justice.', 'PG', '96', 'documentation', 'tt6915100', '6.5', '', '1905-07-10'),
(1563, 'The Most Assassinated Woman in the World', 'Set against the backdrop of the infamous Theatre Grand Guignol the story revolves around iconic actress Paula Maxa - the most famous of the Grand Guignol\'s leading ladies and the titular Most Assassinated Woman, who was graphically slain on stage multiple times a day.', '', '102', 'thriller', 'tt6186696', '5.3', '', '1905-07-10'),
(1571, 'Message from the King', 'On a relentless quest to avenge his sister\'s murder, a man from Cape Town infiltrates a sprawling network of lowlifes and elites in Los Angeles.', 'R', '102', 'thriller', 'tt1712192', '6.4', '', '1905-07-09'),
(1579, 'A Second Chance', 'Popoy and Basha have had a wonderful wedding, but their subsequent married life turns out to be extremely difficult.', '', '130', 'drama', 'tt5226380', '8.6', '', '1905-07-10'),
(1587, 'Lowriders', 'A young street artist in East Los Angeles is caught between his father\'s obsession with lowrider car culture, his ex-felon brother and his need for self-expression.', 'PG-13', '100', 'crime', 'tt1366338', '5.7', '', '1905-07-09'),
(1595, 'The Mansion', 'A band of students comes to celebrate the New Year in an old manor house isolated from everything. But soon after their arrival, strange events disrupt the atmosphere, before the party turns squarely to the nightmare ...', 'PG-13', '100', 'comedy', 'tt7029854', '4.6', '', '1905-07-09'),
(1603, 'Michael', 'After accidentally shooting a 12-year-old boy, a dedicated cop is removed from his position. Forced to take work at a local cinema and beginning to lose his eyesight, he struggles to provide for his son.', 'PG-13', '97', 'drama', 'tt1754202', '5.2', '', '1905-07-09'),
(1611, 'The Warning', 'After his friend is shot, Jon finds a numerical pattern behind deaths that occurred at the same location and sets out to warn the next young victim.', '', '92', 'drama', 'tt3711510', '5.9', '', '1905-07-10'),
(1619, 'Skins', 'In a strange world where people share numerous deformities, the same problem we all face challenges each of them: to find someone who accepts you as you are. Sometimes, that means finding yourself first.', '', '78', 'drama', 'tt5808778', '6.1', '', '1905-07-09'),
(1627, 'Blessed Benefit', 'Imprisoned on an unfair charge of fraud, a mild-mannered Jordanian contractor discovers that prison has its own rhythms, rules, and economies — and he soon begins to carve out a position for himself in this place where fraud isn’t a crime so much as a way of life.', '', '83', 'drama', 'tt5161784', '6.6', '', '1905-07-09'),
(1643, 'El Potro: lo mejor del amor', 'A young man with charisma and magnetism enters the atmosphere of tropical music as a romantic singer and undertakes a vertiginous ascent to fame.', '', '122', 'drama', 'tt9062342', '5.2', '', '1905-07-10'),
(1651, 'Elf Pets: A Fox Cub\'s Christmas Tale', 'Set against the backdrop of the mystical Northern Lights, Scout Elf Newsey investigates how Santa travels the world at night.', '', '28', 'comedy', 'tt10485928', '5', '', '1905-07-10'),
(1659, 'Santo cachón', 'Antonio tries to show his friend Carlos that his wife cheats on him. As he tries to make his friends see the truth, a number of different people and funny situations come up.', '', '87', 'comedy', 'tt9189572', '4.6', '', '1905-07-10'),
(1667, 'Taramani', 'An orthodox youngster and a free-spirited lady fall in love, only to understand that they are different in all aspects of life. How do they realise their complex requirements and mistakes?', '', '150', 'drama', 'tt4328934', '7.4', '', '1905-07-09'),
(1675, 'Aruna & Her Palate', 'An epidemiologist turns her nationwide bird flu investigation into a chance to sample local delicacies en route, with three friends along for the ride.', '', '106', 'drama', 'tt8894180', '7.1', '', '1905-07-10'),
(1683, 'Babamın Ceketi', 'Ferhat and Aslihan, who have been together for some time, want to crown their relationship with marriage. But Ferhat\'s being unemployed is a major obstacle to their marriage. In the meantime, Aslihan father\'s suffers heart attack makes the situation more complicated. Aslihan\'s father started to pressure his daughter to marry after the health problem.', '', '100', 'family', 'tt8857590', '4.9', '', '1905-07-10'),
(1691, 'Dear Son', 'Extremism slices through a Tunisian family with the realization that their teenage son has become an ISIS fighter.', '', '100', 'drama', 'tt7537960', '6.5', '', '1905-07-10'),
(1699, 'Lara and the Beat', 'Lara and the Beat is a coming of age movie about the young and beautiful Giwa sisters caught in the center of a financial scandal with their late parents\' Media Empire. The sisters are forced out of their privileged bubble, and must learn to build their own future - through music and enterprise - to salvage their family\'s Legacy.', '', '137', 'romance', 'tt7819668', '5.7', '', '1905-07-10'),
(1707, 'Alakada Reloaded', 'The film depicts a young girl who, having come from a less-privileged family, makes a habit of lying to people about her financial status.', '', '103', 'drama', 'tt13275228', '', '', '1905-07-09'),
(1715, 'What Did I Mess', 'The romp revolves around a dinner party hosted by the young and vicacious Nayla to introduce Fares, the love of her life, to Silvio, her new fiancé.', 'PG-13', '100', 'comedy', 'tt9163340', '7.1', '', '1905-07-10'),
(1731, 'Arctic', 'A man stranded in the Arctic is finally about to receive his long awaited rescue. However, after a tragic accident, his opportunity is lost and he must then decide whether to remain in the relative safety of his camp or embark on a deadly trek through the unknown for potential salvation.', 'PG-13', '97', 'drama', 'tt6820256', '6.8', '', '1905-07-11'),
(1739, '47 Meters Down: Uncaged', 'Four teenage girls go on a diving adventure to explore a submerged Mayan city. Once inside, their rush of excitement turns into a jolt of terror as they discover the sunken ruins are a hunting ground for deadly great white sharks. With their air supply steadily dwindling, the friends must navigate the underwater labyrinth of claustrophobic caves and eerie tunnels in search of a way out of their watery hell.', 'PG-13', '90', 'drama', 'tt7329656', '5', '', '1905-07-11'),
(1747, 'Triple Frontier', 'Struggling to make ends meet, former special ops soldiers reunite for a high-stakes heist: stealing $75 million from a South American drug lord.', 'R', '125', 'action', 'tt1488606', '6.4', '', '1905-07-11'),
(1755, 'Jerry Seinfeld: 23 Hours to Kill', 'Jerry Seinfeld takes the stage in New York and tackles talking vs. texting, bad buffets vs. so-called \"great\" restaurants and the magic of Pop Tarts.', '', '60', 'comedy', 'tt12117854', '6.7', '', '1905-07-12'),
(1763, 'The Babysitter: Killer Queen', 'Two years after defeating a satanic cult led by his babysitter Bee, Cole\'s trying to forget his past and focus on surviving high school. But when old enemies unexpectedly return, Cole will once again have to outsmart the forces of evil.', 'R', '101', 'horror', 'tt11024272', '5.8', '', '1905-07-12'),
(1771, 'My Octopus Teacher', 'After years of swimming every day in the freezing ocean at the tip of Africa, Craig Foster meets an unlikely teacher: a young octopus who displays remarkable curiosity. Visiting her den and tracking her movements for months on end he eventually wins the animal’s trust and they develop a never-before-seen bond between human and wild animal.', '', '85', 'documentation', 'tt12888462', '8.1', '', '1905-07-12'),
(1779, 'The Woman in the Window', 'An agoraphobic woman living alone in New York begins spying on her new neighbors only to witness a disturbing act of violence.', 'R', '102', 'drama', 'tt6111574', '5.7', '', '1905-07-12'),
(1787, 'Fractured', 'Driving cross-country, Ray and his wife and daughter stop at a highway rest area where his daughter falls and breaks her arm. After a frantic rush to the hospital and a clash with the check-in nurse, Ray is finally able to get her to a doctor. While the wife and daughter go downstairs for an MRI, Ray, exhausted, passes out in a chair in the lobby. Upon waking up, they have no record or knowledge of Ray\'s family ever being checked in.', 'R', '100', 'thriller', 'tt4332232', '6.4', '', '1905-07-11'),
(1795, 'Rattlesnake', 'After a mysterious woman saves her daughter from a deadly snakebite, a single mother must repay the debt by killing a stranger before sundown.', '', '85', 'drama', 'tt9257484', '4.6', '', '1905-07-11'),
(1803, '365 Days', 'Massimo is a member of the Sicilian Mafia family and Laura is a sales director. She does not expect that on a trip to Sicily trying to save her relationship, Massimo will kidnap her and give her 365 days to fall in love with him.', '', '114', 'drama', 'tt10886166', '3.3', '', '1905-07-12'),
(1819, 'Travis Scott: Look Mom I Can Fly', 'While crafting his Grammy-nominated album \"Astroworld,\" Travis Scott juggles controversy, fatherhood and career highs in this intimate documentary.', '', '85', 'music', 'tt10856726', '6.3', '', '1905-07-11'),
(1827, 'Guest House', 'A newly engaged couple finds the home of their dreams and it quickly becomes a nightmare when the previous owner\'s friend continues squatting in their guest house. It leads to a turf war that ultimately ruins their house, their marriage and their lives.', 'R', '84', 'comedy', 'tt10054316', '4.4', '', '1905-07-12'),
(1835, 'Invader ZIM: Enter the Florpus', 'ZIM discovers his almighty leaders never had any intention of coming to Earth and he loses confidence in himself for the first time in his life, which is the big break his human nemesis, Dib has been waiting for.', '', '71', 'animation', 'tt6739094', '7.4', '', '1905-07-11'),
(1843, 'Dance of the Forty One', 'Mexico City, November 1901. The police raid a private home where a secret party is being held. Among those attending is the son-in-law of President Porfirio Díaz.', '', '99', 'drama', 'tt11525022', '6.8', '', '1905-07-12'),
(1851, 'A Fall from Grace', 'When a law-abiding woman gets indicted for murdering her husband, her lawyer soon realizes that a larger conspiracy may be at work.', '', '120', 'drama', 'tt11390036', '5.9', '', '1905-07-12'),
(1859, 'A Whisker Away', 'Miyo \"Muge\" Sasaki is a peculiar second-year junior high student who has fallen in love with her classmate Kento Hinode. Muge resolutely pursues Kento every day, but he takes no notice of her. Nevertheless, while carrying a secret she can tell no one, Muge continues to pursue Kento. Muge discovers a magic mask that allows her to transform into a cat named Tarō. The magic lets Muge get close to Kento, but eventually it may also make her unable to transform back to a human.', '', '104', 'drama', 'tt11958346', '6.7', '', '1905-07-12'),
(1867, 'Dolemite Is My Name', 'The story of Rudy Ray Moore, who created the iconic big screen pimp character Dolemite in the 1970s.', 'R', '118', 'drama', 'tt8526872', '7.2', '', '1905-07-11'),
(1875, 'The Midnight Sky', 'This post-apocalyptic tale follows Augustine, a lonely scientist in the Arctic, as he races to stop Sully and her fellow astronauts from returning home to a mysterious global catastrophe.', 'PG-13', '118', 'drama', 'tt10539608', '5.6', '', '1905-07-12'),
(1883, 'The Trial of the Chicago 7', 'What was supposed to be a peaceful protest turned into a violent clash with the police. What followed was one of the most notorious trials in history.', 'R', '130', 'drama', 'tt1070874', '7.7', '', '1905-07-12'),
(1891, 'Coffee & Kareem', 'Twelve-year-old Kareem Manning hires a criminal to scare his mom\'s new boyfriend -police officer James Coffee - but it backfires, forcing Coffee and Kareem to team up in order to save themselves from Detroit\'s most ruthless drug kingpin.', '', '88', 'action', 'tt9898858', '5.1', '', '1905-07-12'),
(1899, 'Fantastic Fungi', 'Fantastic Fungi is a descriptive time-lapse journey about the magical, mysterious and medicinal world of fungi and their power to heal, sustain and contribute to the regeneration of life on Earth that began 3.5 billion years ago.', '', '81', 'documentation', 'tt8258074', '7.4', '', '1905-07-11'),
(1907, 'Eric Andre: Legalize Everything', 'Comedian Eric Andre presents his very first Netflix original stand-up special. Taking the stage in New Orleans, Andre breaks the boundaries of comedy as he critiques the war on drugs, the war on sex, and the war on fart jokes!', 'R', '52', 'comedy', 'tt12327104', '6.2', '', '1905-07-12'),
(1915, 'Da 5 Bloods', 'Four African-American Vietnam veterans return to Vietnam. They are in search of the remains of their fallen squad leader and the promise of buried treasure. These heroes battle forces of humanity and nature while confronted by the lasting ravages of the immorality of the Vietnam War.', 'R', '156', 'drama', 'tt9777644', '6.5', '', '1905-07-12'),
(1923, 'Circus of Books', 'For decades, a nice Jewish couple ran Circus of Books, a porn shop and epicenter for gay LA. Their director daughter documents their life and times.', '', '92', 'documentation', 'tt8727582', '7.1', '', '1905-07-12'),
(1931, 'Paris Is Us', 'Dreams and reality collide as a young woman navigates a tumultuous relationship amid rising social tensions, protests and tragedies in Paris.', '', '84', 'drama', 'tt7920024', '4.6', '', '1905-07-11'),
(1939, 'The Informer', 'In New York, former convict Pete Koslow, related to the Polish mafia, must deal with both Klimek the General, his ruthless boss, and the twisted ambitions of two federal agents, as he tries to survive and protect the lives of his loved ones.', 'R', '109', 'thriller', 'tt1833116', '6.6', '', '1905-07-11'),
(1947, 'ReMastered: Devil at the Crossroads', 'Robert Johnson was one of the most influential blues guitarists ever. Even before his early death, fans wondered if he\'d made a pact with the Devil.', '', '48', 'music', 'tt9046574', '7', '', '1905-07-11'),
(1955, 'Mucho Mucho Amor: The Legend of Walter Mercado', 'Once the world\'s most famous astrologer, Walter Mercado seeks to resurrect a forgotten legacy. Raised in the sugar cane fields of Puerto Rico, Walter grew up to become a gender non-conforming, cape-wearing psychic whose televised horoscopes reached 120 million viewers a day for decades before he mysteriously disappeared.', '', '96', 'documentation', 'tt11378264', '7.3', '', '1905-07-12'),
(1963, 'Becoming', 'Join former first lady Michelle Obama in an intimate documentary looking at her life, hopes and connection with others.', 'PG', '89', 'documentation', 'tt12221748', '7', '', '1905-07-12'),
(1971, 'Anthony Jeselnik: Fire in the Maternity Ward', 'Forging his own comedic boundaries, Anthony Jeselnik revels in getting away with saying things others can\'t in this stand-up special shot in New York.', '', '64', 'comedy', 'tt10050780', '7.2', '', '1905-07-11'),
(1979, 'David Attenborough: A Life on Our Planet', 'The story of life on our planet by the man who has seen more of the natural world than any other. In more than 90 years, Attenborough has visited every continent on the globe, exploring the wild places of our planet and documenting the living world in all its variety and wonder. Addressing the biggest challenges facing life on our planet, the film offers a powerful message of hope for future generations.', 'PG', '83', 'documentation', 'tt11989890', '8.9', '', '1905-07-12'),
(1987, 'Rakkhosh', 'The movie explores the horrors and fantasies of a patient trapped in a mental asylum.', '', '113', 'horror', 'tt6018556', '4.8', '', '1905-07-11'),
(2003, 'Oh, Ramona!', 'Oh, Ramona! seeks the transformation of Andrew from a teenager into an adult who lives candidly and selflessly his first love story, innocent and uninvolved, alternating with the second, intense and insane story, incapable of making a choice. Oh, Ramona! is the cinematic rewriting of Andrei Ciobanu\'s book \"Suge-o, Ramona!\".', 'R', '109', 'romance', 'tt7200946', '4.8', '', '1905-07-11'),
(2011, 'The Old Guard', 'Four undying warriors who\'ve secretly protected humanity for centuries become targeted for their mysterious powers just as they discover a new immortal.', 'R', '125', 'action', 'tt7556122', '6.6', '', '1905-07-12'),
(2019, 'Spelling the Dream', 'Since 1999, 18 of the last 22 winners of the Scripps National Spelling Bee have been Indian-American, making the incredible trend one of the longest in sports history. “Breaking the Bee” is a feature-length documentary that explores and celebrates this new dynasty while following four students, ages 7 to 14, as they vie for the title of spelling bee champion.', '', '82', 'documentation', 'tt6193522', '6.9', '', '1905-07-12'),
(2027, 'Jeff Garlin: Our Man in Chicago', 'Comedian Jeff Garlin (unintentionally) celebrates his 37th year of stand-up and shares his learnings on love, loss, success and food addiction.', '', '58', 'comedy', 'tt11108064', '5.9', '', '1905-07-11'),
(2035, 'Sebastian Maniscalco: Stay Hungry', 'Sebastian Maniscalco brings an acerbically unique approach to peacocks on planes, life hacks, rich in-laws and life\'s annoyances in this comedy special.', '', '65', 'comedy', 'tt9482786', '7.1', '', '1905-07-11'),
(2043, 'The Poison Rose', 'A down-on-his-luck PI is hired by his old flame to investigate a murder. But while the case at first appears routine, it slowly reveals itself to be a complex interwoven web of crimes, suspects and dead bodies.', 'R', '108', 'thriller', 'tt5862166', '4.7', '', '1905-07-11'),
(2067, 'Blood Will Tell', 'Thriller about a family whose ties are put to the test when the patriarch’s wife dies.', '', '113', 'thriller', 'tt5687236', '6.1', '', '1905-07-11'),
(2075, 'Go!', 'Jack is a charismatic larrikin who has just discovered the one thing he\'s really good at — go-kart racing. With the support of his mentor, Patrick, an old race car driver with a secret past, and his best mates Colin and Mandy, Jack must learn to control his recklessness if he is to defeat the best drivers in Australia, including the ruthless champion Dean, and win the National title.', '', '110', 'family', 'tt8116640', '5.9', '', '1905-07-12'),
(2083, 'Shawn Mendes: In Wonder', 'A portrait of singer-songwriter Shawn Mendes\' life, chronicling the past few years of his rise and journey.', '', '83', 'music', 'tt13276386', '6.5', '', '1905-07-12'),
(2091, 'The Lockdown Plan', '', '', '49', '', 'tt13079112', '6.5', '', '1905-07-12'),
(2099, 'Christmas Crossfire', 'A man foils an attempted murder, then flees the crew of would-be killers along with their intended target as a woman he\'s just met tries to find him.', 'R', '106', 'thriller', 'tt13448126', '4.8', '', '1905-07-12'),
(2107, 'Abducted in Plain Sight', 'In 1974, 12-year-old Jan Broberg is abducted from a small church-going community in Idaho by a trusted neighbour and close family friend.', '', '91', 'documentation', 'tt3444312', '6.8', '', '1905-07-11'),
(2115, 'Just Another Christmas', 'After taking a very nasty fall on Christmas Eve, grinchy Jorge blacks out and wakes up one year later, with no memory of the year that has passed. He soon realizes that he’s doomed to keep waking up on Christmas Eve after Christmas Eve, having to deal with the aftermath of what his other self has done the other 364 days of the year.', '', '101', 'drama', 'tt13354204', '6.7', '', '1905-07-12');
INSERT INTO `movies` (`id`, `Title`, `Description`, `COL 5`, `runtime`, `genres`, `imdb_id`, `rating`, `poster`, `release_date`) VALUES
(2123, 'Coming from Insanity', 'In the mid-nineties, a 12 year-old boy (KOSSI) with genius-level intelligence, is one of many children trafficked through the Nigerian borders from Togo. He ends up with the MARTINS, an upper-middle class family of 4 in Lagos. At their home, he will work overtime for his meals and shelter as a houseboy. Fast forward to present day, Kossi is still a houseboy with the Martins. He dreams of a better life, but with barely any education, he knows his future is compromised. He relies on his natural abilities and talent to carve out a way for himself, soon discovering the art of counterfeit money printing and floating the most flawless counterfeit dollars this side of the world. Now out on his own, he employs the services of a few friends and grows the operation substantially, landing him on the radar of a young determined agent at the EFCC who will stop at nothing to bring him to justice.', '', '100', 'drama', 'tt8470448', '5.1', '', '1905-07-11'),
(2131, 'Tiffany Haddish: Black Mitzvah', 'On her 40th birthday, Tiffany Haddish drops a bombastic special studded with singing, dancing and raunchy reflections on her long road to womanhood.', '', '55', 'comedy', 'tt8882390', '6.3', '', '1905-07-11'),
(2139, 'Menendez: The Day of the Lord', 'A retired priest hunted by his sins is pulled back into darkness when a friend begs him to help his possessed daughter.', '', '93', 'horror', 'tt5603212', '5', '', '1905-07-12'),
(2147, 'Single Slipper Size - 7', 'An emotionally unstable murder suspect explains the modus operandi behind the crimes he had committed to a few cops which helps in unfolding some intriguing revelation.', '', '120', 'drama', 'tt10370116', '8.4', '', '1905-07-11'),
(2155, 'Chris D\'Elia: No Pain', 'Chris D\'Elia takes the stage in Minneapolis to offer his thoughts on everything from self-censorship to problematic dolphins to lame mutant powers.', '', '55', 'comedy', 'tt11987296', '5.9', '', '1905-07-12'),
(2163, 'Kardec', 'The story of Allan Kardec, from his days as an educator to his contribution to the spiritist codification.', '', '110', 'history', 'tt9213932', '6.1', '', '1905-07-11'),
(2171, 'The Fable', 'The Fable is a legendary yakuza hitman equal to none—but his boss orders him and his sultry associate to lay low and learn how to live a \"normal life\" in Osaka.', '', '123', 'comedy', 'tt8676426', '6.5', '', '1905-07-11'),
(2179, 'So My Grandma\'s a Lesbian!', 'A promising young lawyer sees her plans to wed into an important and ultraconservative family in danger when her grandma decides to marry her girl friend.', '', '94', 'comedy', 'tt9695258', '4.3', '', '1905-07-12'),
(2187, 'Panipat', 'During 18th century India, the Marathas emerged as the most powerful empire in the nation until the Afghan King Ahmad Shah Abdali plans to take over India. Sadashiv Rao Bhau is brought in to save the empire from the king which then leads to the third battle of Panipat.', '', '171', 'romance', 'tt8176040', '5.2', '', '1905-07-11'),
(2195, 'The Highwaymen', 'In 1934, Frank Hamer and Manny Gault, two former Texas Rangers, are commissioned to put an end to the wave of vicious crimes perpetrated by Bonnie Parker and Clyde Barrow, a notorious duo of infamous robbers and cold-blooded killers who nevertheless are worshiped by the public.', 'R', '133', 'crime', 'tt1860242', '6.9', '', '1905-07-11'),
(2203, 'Bert Kreischer: Hey Big Boy', 'Still the ultimate comedy party animal, Bert Kreischer tells more stories about parenthood and family life in a stand-up special from Cleveland.', '', '62', 'comedy', 'tt11810424', '7', '', '1905-07-12'),
(2211, 'The Wolf\'s Call', 'With nuclear war looming, a military expert in underwater acoustics strives to prove things aren\'t as they seem—or sound—using only his ears.', '', '115', 'thriller', 'tt7458762', '6.9', '', '1905-07-11'),
(2219, 'Jimmy Carr: The Best of Ultimate Gold Greatest Hits', 'Nothing is off limits as Jimmy Carr serves up the most outrageous jokes from his stand-up career in a special that\'s not for the faint of heart.', '', '58', 'comedy', 'tt9817258', '7.3', '', '1905-07-11'),
(2227, 'Funan', 'Cambodia, once the ancient kingdom of Funan, April 17th, 1975. The entire country falls under the tyranny of Angkar, the communist party of the Khmer Rouge. The cities are abandoned, the population is thrown to the roads and forced to walk towards an uncertain future…', '', '84', 'animation', 'tt6342440', '6.9', '', '1905-07-11'),
(2235, 'Anima', 'In a short musical film directed by Paul Thomas Anderson, Thom Yorke of Radiohead stars in a mind-bending visual piece. Best played loud.', '', '15', 'music', 'tt10516984', '', '', '1905-07-11'),
(2243, 'Dave Chappelle: Sticks & Stones', 'Dave Chappelle takes on gun culture, the opioid crisis and the tidal wave of celebrity scandals in this defiant stand-up special.', 'R', '65', 'comedy', 'tt10810424', '8.3', '', '1905-07-11'),
(2251, 'Carmen Sandiego: To Steal or Not to Steal', 'You drive the action in this interactive adventure, helping Carmen save Ivy and Zack when V.I.L.E. captures them during a heist in Shanghai.', '', '31', 'animation', 'tt11767524', '', '', '1905-07-12'),
(2259, 'The Larva Island Movie', 'Back at home, Chuck relates the island shenanigans of his larva pals Red and Yellow to a skeptical reporter in this movie sequel to the hit cartoon.', '', '89', 'animation', 'tt12588448', '5.1', '', '1905-07-12'),
(2267, 'We Are One', 'Activists around the world fight injustice and drive social change in this documentary that follows their participation in the music video \"Solidarité.\"', '', '86', 'documentation', 'tt12588398', '5.1', '', '1905-07-12'),
(2275, '122', 'During a bloody night, a young man and his lover are struggling, not to get to the hospital, but to escape and survive.', 'R', '95', 'horror', 'tt7867670', '5.8', '', '1905-07-11'),
(2283, 'DNA', 'DNA revolves around a woman with close ties to a beloved Algerian grandfather who protected her from a toxic home life as a child. When he dies, it triggers a deep identity crisis as tensions between her extended family members escalate revealing new depths of resentment and bitterness.', '', '90', 'drama', 'tt7600716', '6', '', '1905-07-12'),
(2299, 'The Silence of Others', 'The story of the tortuous struggle against the silence of the victims of the dictatorship imposed by General Franco after the victory of the rebel side in the Spanish Civil War (1936-1975). In a democratic country, but still ideologically divided, the survivors seek justice as they organize the so-called “Argentinian lawsuit” and denounce the legally sanctioned pact of oblivion that intends to hide the crimes they were subjects of.', '', '95', 'documentation', 'tt8099236', '8', '', '1905-07-11'),
(2307, 'Dragon Rider', 'A young silver dragon teams up with a mountain spirit and an orphaned boy on a journey through the Himalayas in search for the Rim of Heaven.', '', '91', 'fantasy', 'tt7080422', '5.7', '', '1905-07-12'),
(2315, 'RattleSnake: The Ahanna Story', 'Ahanna, a young gentleman who decides to rob the life he always wanted and dreamt of. He assembles a group of men called \"The Armadas\" with several different skills, carrying out a series of spectacular heists. But things takes a swift u-turn and the gang suddenly find themselves with better enemies on both sides.', '', '135', 'drama', 'tt13890834', '4.9', '', '1905-07-12'),
(2323, 'Luka Chuppi', 'The story of a television reporter in Mathura who falls in love with a headstrong woman.', '', '126', 'romance', 'tt8908002', '6.3', '', '1905-07-11'),
(2331, 'El Pepe: A Supreme Life', 'A documentary on the life of Uruguayan politician and former guerrilla fighter José Mujica.', '', '74', 'documentation', 'tt8900434', '7.1', '', '1905-07-11'),
(2339, 'Furie', 'Paul Diallo, a history teacher, lives a quiet life with his wife and kid. During summertime, he lends his house to his son’s babysitter and her boyfriend. When they return, the Diallo family finds a closed door – locks have been changed and the new occupants maintain they are in « their home ». With no one to turn to, Paul gets closer to Mickey, a shady local man with a penchant for all things extreme and illegal. Soon the once anti-violent teacher is approaching the point of no return…', '', '98', 'thriller', 'tt8246392', '5.6', '', '1905-07-11'),
(2347, 'Asphalt Goddess', 'Max returns to her slum turned into the vocalist of a rock band. There, the memories await, the latest news and the truths that were silent for years: Sonia is a voice that speaks from the death.', '', '126', 'drama', 'tt12025688', '5.1', '', '1905-07-12'),
(2355, '27 Steps of May', 'Eight years ago, 14 year old May was raped by a group of men. May’s father is devastated, blaming himself for not being able to keep his daughter safe. Traumatized significantly by this incident, May withdraws completely from life.', '', '112', 'drama', 'tt9695156', '8', '', '1905-07-11'),
(2363, 'Alone/Together', 'Christine an Art Studies major student at University of the Philippines Diliman a smart and very ambitious who is in a relationship with a Biology student at University of Santo Tomas, Raf a very total opposite character of Christine.', '', '120', 'drama', 'tt9526822', '6.6', '', '1905-07-11'),
(2379, 'Torbaaz', 'At an Afghanistan refugee camp, an ex-army doctor seeks to bring children joy through cricket and soon realizes that the stakes go beyond the sport.', '', '132', 'drama', 'tt7805960', '5.1', '', '1905-07-12'),
(2387, 'Jo Koy: In His Elements', 'Jo Koy returns to the Philippines to show off the local culture and headline a special featuring Filipino American comedians, DJs and hip-hop dancers.', '', '55', 'comedy', 'tt12358852', '5.4', '', '1905-07-12'),
(2395, 'Isa Pa with Feelings', 'A frustrated architect finds solace with a deaf-mute neighbor. But their relationship is faced with challenges as miscommunications kicked in.', '', '102', 'comedy', 'tt10555482', '7.8', '', '1905-07-11'),
(2403, 'World Famous Lover', 'An amalgamation of four different love stories: Seenayya and Suvarna, a middle-class couple in a small town; Gautham, an uber-cool youngster romancing in the streets of Paris with his girlfriend Iza, Union Leader Srinu head over heels in love with his boss lady, and and the first college romance.', '', '156', 'drama', 'tt10991188', '5', '', '1905-07-12'),
(2411, 'The Girl and the Gun', 'A department store saleslady has had enough of being an underdog. One night, she discovers a peculiar-looking gun right on her doorstep. Her life drastically changes as she discovers how much power owning a gun can give her.', '', '80', 'thriller', 'tt11156674', '5.9', '', '1905-07-11'),
(2419, '90 ML', 'Thamara, Paru, Kajal and Suganya are four friends who are rather tired of their uneventful routine. However, things take a turn for the better with the arrival of the spirited and outgoing Rita, a young woman who encourages them to live their lives to the fullest.', '', '125', 'drama', 'tt8268916', '3.2', '', '1905-07-11'),
(2427, 'Berlin, Berlin', 'Lolle\'s love life in Berlin is as complicated as ever. After the story with Sven, her second cousin, was over, she got together with her best friend Hart and the two are about to get married. That is, if Sven doesn\'t ruin things.', '', '80', 'comedy', 'tt10556130', '3.8', '', '1905-07-12'),
(2435, 'Kandasamys: The Wedding', 'Set in Chatsworth, Keeping up with the Kandasamys opens a window into the lifestyle and subculture of modern-day Indian South Africans; their aspirations, dreams and challenges.  Shanti Naidoo and Jennifer Kandasamy are matriarchal rivals of neighbouring families, whose young adult children become romantically involved. And the last thing these two Chatsworth mothers need is to be related to one another!  Well as much as they tried to keep their families apart it turned out we’re invited to the wedding!', '', '98', 'comedy', 'tt10217780', '6', '', '1905-07-11'),
(2443, 'Lady Driver', 'When a rebellious teen embarks on a solo summer journey to connect with her roots, she finds herself in a new world, geared up for the ride of her life, and discovers she had the drive in her all along.', 'PG', '104', 'drama', 'tt7562334', '5.8', '', '1905-07-12'),
(2451, 'Saaho', 'A battle for power ensues as warring gangters thrive to gain possession of a \"black box\" that can make them richer than they already are, and an undercover cop intervenes with the help of his sharp intellect and an instinct to kill.', '', '171', 'thriller', 'tt6836936', '5', '', '1905-07-11'),
(2459, 'Girls with Balls', 'All girls volley ball team The Falcons end up stranded in the middle of nowhere after their mini-van breaks down. Little do they know they landed in degenerate hunters\' territory and the hunt is on. Thus begins a very long night where they must run for their lives and test their team spirit. But the girls are more resourceful than it appears. In the heart of the forest, the tables are about to turn between hunter and hunted...', '', '77', 'horror', 'tt4725842', '3.9', '', '1905-07-11'),
(2467, 'Hot Gimmick: Girl Meets Boy', 'A quiet teen\'s life is shaken up when she\'s forced to be her arrogant neighbor\'s slave. He loves her, but they both have a lot to learn about trust.', '', '119', 'drama', 'tt10061256', '4.4', '', '1905-07-11'),
(2475, 'Kenny Sebastian: The Most Interesting Person in the Room', 'Fusing his musical and stand-up chops, Kenny Sebastian gets analytical about frumpy footwear, flightless birds and his fear of not being funny enough.', '', '67', 'comedy', 'tt12241424', '6', '', '1905-07-12'),
(2483, 'Sarvam Thaala Mayam', 'Peter who tries to find his place in the world of classical Indian music embarks on a journey that helps him evolve personally, spiritually and musically.', 'PG', '133', 'drama', 'tt7719976', '7.6', '', '1905-07-11'),
(2491, 'The F**k-It List', 'After a prank blows up a studious high school senior\'s life, he shares a list of certain things he wishes he\'d done differently — and maybe still can.', 'R', '103', 'comedy', 'tt8145202', '5.1', '', '1905-07-12'),
(2507, 'High & Low: The Worst', 'Demon High School is divide into a part-time system and a full-time system, Yoshiki Murayama is the head of the Demon high school and Kaede Hanaoka has an ambition to take on the full-time world in order to challenge Murayama one day.', 'R', '125', 'action', 'tt11135936', '6.6', '', '1905-07-11'),
(2515, 'A Remarkable Tale', 'A town at the edge of the missing take desperate measures to avoid it.', 'PG', '93', 'comedy', 'tt8296660', '5.3', '', '1905-07-11'),
(2531, 'Alelí', 'The death of their father causes three dysfunctional siblings to fight over their beloved childhood home.', '', '88', 'comedy', 'tt10984818', '6.3', '', '1905-07-12'),
(2547, 'Wheels of Fortune', 'To claim a big inheritance, a down-on-his-luck mechanic must win a series of competitions as outlined in his birth father\'s will.', 'R', '107', 'comedy', 'tt9735976', '5.4', '', '1905-07-12'),
(2555, 'Larry the Cable Guy: Remain Seated', 'Larry the Cable Guy is back to Git R Done. Remain Seated, his latest solo special, will show you why this Grammy nominated, multi-platinum recording artist, and Billboard award winner is at the top of his game. Coming to you straight from the Rialto Square Theatre in Joliet, IL to your seat at home!', 'R', '67', 'comedy', 'tt11464488', '6.7', '', '1905-07-12'),
(2563, 'Edoardo Ferrario: Temi Caldi', 'Italian comedian Edoardo Ferrario riffs on life at 30 and unpacks the peculiarities of global travel, social media and people who like craft beer.', '', '65', 'comedy', 'tt9861498', '6.4', '', '1905-07-11'),
(2587, 'Alex Fernández: The Best Comedian in the World', 'Comic Alex Fernández performs his familiar autobiographical stories but goes a little deeper this time with a tender tale about one of his six siblings.', '', '51', 'comedy', 'tt11497900', '6.3', '', '1905-07-12'),
(2595, 'Super Monsters: Santa\'s Super Monster Helpers', 'When Santa needs serious help prepping all of his presents, the Super Monsters lend a hand - and some monster magic - to get every gift out on time.', '', '24', 'animation', 'tt13439998', '4.5', '', '1905-07-12'),
(2603, 'Wira', 'After a long stint in the army, an ex-lieutenant returns home and enters an underground MMA match to take on a local mobster and protect his family.', '', '108', 'action', 'tt11194492', '6.3', '', '1905-07-11'),
(2627, 'Habaddi', 'When the news of his village\'s school Kabaddi team travelling to Mumbai breaks out, a 10-year-old boy with a speech defect sees the opportunity to meet the girl he adores. But how will he chant \'Kabaddi, Kabaddi\' without stammering?', '', '110', 'drama', 'tt9302854', '7.3', '', '1905-07-12'),
(2643, 'True: Friendship Day', 'When a giant Grippity-Grab snags Grizelda\'s friendship bracelet and turns her into a mermaid, True heads under the sea with magic wishes to save the day.', '', '23', 'animation', 'tt12855976', '6.9', '', '1905-07-12'),
(2651, 'Ali & Alia', 'Ali and Alia are childhood neighbors that fell in love with each other, but bigger events occur in their lives which gets them separated. Ali seeks to maintain Alia\'s heart even if it is through substance abuse.', 'PG-13', '105', 'romance', 'tt9859758', '5.1', '', '1905-07-12'),
(2667, 'Stunt School', 'An aspiring actress is admitted to a prestigious conservatory but must pay her tuition by working as a performer for an unusual company.', '', '95', 'comedy', 'tt9056824', '4.4', '', '1905-07-11'),
(2675, 'Kaagar', 'In a small Maharashtrian town, a woman\'s rise in the political hierarchy creates ripples across the social-political spectrum. Directed by Makarand Mane, KaaGaR stars Rinku Rajguru in the lead role.', '', '129', 'crime', 'tt8907844', '6.1', '', '1905-07-11'),
(2683, 'Three Thieves', 'Due to a case of mistaken identity, three dissatisfied friends are contracted to commit a seemingly simple theft. Even worse, the man originally contracted for the job is on the hunt for them.', '', '108', 'comedy', 'tt11133472', '7.3', '', '1905-07-11'),
(2691, 'Si Doel the Movie 3', 'The return of Sarah with his son, Dul, to Jakarta, welcomed happily by the Doel\'s family. But it also makes Zaenab, Sarah, and Doel confronted with decisive choice.', '', '93', 'drama', 'tt11469660', '6.6', '', '1905-07-12'),
(2699, 'The Woman King', 'The story of the Agojie, the all-female unit of warriors who protected the African Kingdom of Dahomey in the 1800s with skills and a fierceness unlike anything the world has ever seen, and General Nanisca as she trains the next generation of recruits and readies them for battle against an enemy determined to destroy their way of life.', 'PG-13', '135', 'drama', 'tt8093700', '6.8', '', '1905-07-14'),
(2707, 'The Pale Blue Eye', 'A world-weary detective is hired to investigate the murder of a West Point cadet. Stymied by the cadets\' code of silence, he enlists one of their own to help unravel the case - a young man the world would come to know as Edgar Allan Poe.', 'R', '128', 'crime', 'tt14138650', '6.6', '', '1905-07-14'),
(2715, 'The Sea Beast', 'When a young girl stows away on the ship of a legendary sea monster hunter, they launch an epic journey into uncharted waters - and make history to boot.', 'PG', '115', 'scifi', 'tt9288046', '7', '', '1905-07-14'),
(2723, 'Hustle', 'A basketball scout discovers a phenomenal street ball player while in Spain and sees the prospect as his opportunity to get back into the NBA.', 'R', '117', 'drama', 'tt8009428', '7.3', '', '1905-07-14'),
(2731, 'Athena', 'Hours after the tragic death of their youngest brother in unexplained circumstances, three siblings have their lives thrown into chaos.', 'R', '97', 'drama', 'tt15445056', '6.8', '', '1905-07-14'),
(2739, 'A Trip to Infinity', 'Does infinity exist? Can we experience the Infinite? In an animated film (created by artists from 10 countries) the world\'s most cutting-edge scientists and mathematicians go in search of the infinite and its mind-bending implications for the universe.  Eminent mathematicians, particle physicists and cosmologists dive into infinity and its mind-bending implications for the universe.', 'PG', '79', 'documentation', 'tt21929356', '6.9', '', '1905-07-14'),
(2747, 'The Curse of Bridge Hollow', 'A Halloween-hating dad reluctantly teams up with his teenage daughter when an evil spirit wreaks havoc by making their town\'s decorations come to life.', 'PG-13', '89', 'horror', 'tt15289240', '5.5', '', '1905-07-14'),
(2755, 'Facing Nolan', 'In the world of Major League Baseball no one has created a mythology like Nolan Ryan. Told from the point of view of the hitters who faced him and the teammates who revered him, Facing Nolan is the definitive documentary of a Texas legend.', '', '105', 'documentation', 'tt17511190', '7.9', '', '1905-07-14'),
(2763, 'Day Shift', 'An LA vampire hunter has a week to come up with the cash to pay for his kid\'s tuition and braces. Trying to make a living these days just might kill him.', 'R', '113', 'comedy', 'tt13314558', '6.1', '', '1905-07-14'),
(2771, 'God\'s Crooked Lines', 'Alice Gould, a private investigator, pretends to be mentally ill in order to enter a psychiatric hospital and gather evidence for the case she is working on: the death of a patient in unclear circumstances.', '', '155', 'drama', 'tt13229894', '7', '', '1905-07-14'),
(2779, 'Last Seen Alive', 'After Will Spann\'s wife suddenly vanishes at a gas station, his desperate search to find her leads him down a dark path that forces him to run from authorities and take the law into his own hands.', 'R', '95', 'thriller', 'tt15004136', '5.6', '', '1905-07-14'),
(2787, 'Choose or Die', 'In pursuit of an unclaimed $125,000 prize, a broke college dropout decides to play an obscure, 1980s survival computer game. But the game curses her, and she’s faced with dangerous choices and reality-warping challenges. After a series of unexpectedly terrifying moments, she realizes she’s no longer playing for the money but for her life.', '', '84', 'thriller', 'tt11514780', '4.8', '', '1905-07-14'),
(2795, 'Jackass 4.5', 'Through outrageous, never-before-seen footage, witness the making of the Jackass crew\'s last go at wild stunts.', '', '90', 'action', 'tt18258584', '', '', '1905-07-14'),
(2811, 'Our Father', 'After a woman\'s at-home DNA test reveals multiple half-siblings, she discovers a shocking scheme involving donor sperm and a popular fertility doctor.', '', '97', 'documentation', 'tt19704638', '6.6', '', '1905-07-14'),
(2819, 'Untold: Malice at the Palace', 'Key figures from an infamous November 19th 2004 incident between players and fans at an NBA game in Michigan discuss the fight, its fallout and its lasting legacy.', 'R', '69', 'documentation', 'tt15085802', '7.5', '', '1905-07-13'),
(2827, 'The Volcano: Rescue from Whakaari', 'A close examination of the Whakaari / White Island volcanic eruption of 2019 in which 22 lives were lost, the film viscerally recounts a day when ordinary people were called upon to do extraordinary things, placing this tragic event within the larger context of nature, resilience, and the power of our shared humanity.', 'PG-13', '97', 'documentation', 'tt21439528', '7.3', '', '1905-07-14'),
(2835, 'Death to 2021', 'This comedic retrospective mixes archival footage and scripted sketches as it revisits all the dread — and occasional delight — that 2021 had to offer.', '', '60', 'comedy', 'tt16301388', '6.3', '', '1905-07-13'),
(2843, 'The Womb', 'Grappling with an unplanned pregnancy, a woman turns in desperation to a mysterious older couple who promise to take care of her baby.', 'R', '116', 'horror', 'tt14954636', '6.1', '', '1905-07-14'),
(2851, 'The Metamorphosis of Birds', 'Beatriz married Henrique on the day of her 21st birthday. Henrique, a naval officer, would spend long periods at sea. Ashore, Beatriz, who learned everything from the verticality of plants, took great care of the roots of their six children. The oldest son, Jacinto (Hyacinth), my father, dreamed he could be a bird. One day, suddenly, Beatriz died.  My mom didn’t die suddenly, but she too died when I was 17 years-old. On that day, me and my father met in the loss of our mothers and our relationship was no longer just that of father and daughter.', '', '101', 'drama', 'tt11625100', '7.4', '', '1905-07-13'),
(2859, 'My Father\'s Dragon', 'Struggling to cope after a move to the city with his mother, Elmer runs away in search of Wild Island and a young dragon who waits to be rescued. Elmer’s adventures introduce him to ferocious beasts, a mysterious island and the friendship of a lifetime.', 'PG', '104', 'action', 'tt9288748', '6.5', '', '1905-07-14'),
(2867, 'Love Today', 'A young couple is made to exchange their phones for a day. What follows is a hilarious and emotional sequence of events that puts their lives in misery.', '', '154', 'romance', 'tt22488728', '8.1', '', '1905-07-14'),
(2875, 'Afterlife of the Party', 'A social butterfly who dies during her birthday week is given a second chance to right her wrongs on Earth.', '', '109', 'fantasy', 'tt11742798', '5.8', '', '1905-07-13'),
(2883, 'A Castle for Christmas', 'To escape a scandal, a bestselling author journeys to Scotland, where she falls in love with a castle - and faces off with the grumpy duke who owns it.', '', '98', 'drama', 'tt13070602', '5.5', '', '1905-07-13'),
(2891, 'Ghislaine Maxwell: Filthy Rich', 'Stories from survivors frame this documentary detailing the sex-trafficking trial of Ghislaine Maxwell, a socialite and accomplice of Jeffrey Epstein.', 'R', '101', 'documentation', 'tt22892896', '6', '', '1905-07-14'),
(2899, 'Persuasion', 'Living with her snobby family on the brink of bankruptcy, Anne Elliot is an unconforming woman with modern sensibilities. When Frederick Wentworth - the dashing one she once sent away - crashes back into her life, Anne must choose between putting the past behind her or listening to her heart when it comes to second chances.', 'PG', '108', 'romance', 'tt13456318', '5.8', '', '1905-07-14'),
(2907, 'Trevor Noah: I Wish You Would', 'Emmy-winning comedian Trevor Noah talks learning German, speaking ill of the dead, judging people in horror movies and ordering Indian food in Scotland.', 'PG-13', '69', 'comedy', 'tt22890438', '6.6', '', '1905-07-14'),
(2915, 'Thai Massage', 'A typical middle-class 70-year-old widower, Atmaram Dubey, who has been celibate for decades, realises he will probably never have sex. This awakening catapults him into an outrageous journey of self-discovery defying societal norms.', '', '120', 'drama', 'tt20838498', '6.3', '', '1905-07-14'),
(2923, 'The Last Mercenary', 'A legendary secret service agent comes out of hiding and returns to France to help the son he\'s never met get out of trouble.', '', '110', 'comedy', 'tt12808182', '5.3', '', '1905-07-13'),
(2931, 'Rescued by Ruby', 'Chasing his dream to join an elite K-9 unit, a state trooper partners with a fellow underdog: clever but naughty shelter pup Ruby. Based on a true story.', '', '93', 'drama', 'tt11278476', '7.1', '', '1905-07-14'),
(2939, 'The Perfumier', 'To regain her sense of smell and get back her lover, a detective joins forces with a perfume maker who uses deadly methods to create the perfect scent.', 'R', '96', 'drama', 'tt21916206', '3.6', '', '1905-07-14'),
(2947, 'Nightbooks', 'Alex, a boy obsessed with scary stories, is imprisoned by an evil young witch in her contemporary New York City apartment.', '', '103', 'family', 'tt13382268', '5.8', '', '1905-07-13'),
(2955, 'Hasan Minhaj: The King\'s Jester', 'Filmed at the historic Brooklyn Academy of Music, Hasan Minhaj returns to Netflix with his second stand-up comedy special Hasan Minhaj: The King\'s Jester. In this hilarious performance, Hasan shares his thoughts on fertility, fatherhood, and freedom of speech.', '', '60', 'comedy', 'tt21994438', '7.7', '', '1905-07-14'),
(2963, 'The Shadow in My Eye', 'On March 21st, 1945, the British Royal Air Force set out on a mission to bomb Gestapo\'s headquarters in Copenhagen. The raid had fatal consequences as some of the bombers accidentally targeted a school and more than 120 people were killed, 86 of whom were children.', '', '107', 'drama', 'tt9170516', '7.3', '', '1905-07-13'),
(2971, 'Don\'t Leave', 'Semih\'s girlfriend suddenly breaks up with him. In search of answers about their relationship, he must soon confront what he had long ignored.', 'R', '107', 'drama', 'tt18450548', '5.2', '', '1905-07-14'),
(2979, 'The Witcher: Nightmare of the Wolf', 'Escaping from poverty to become a witcher, Vesemir slays monsters for coin and glory, but when a new menace rises, he must face the demons of his past.', '', '83', 'scifi', 'tt11657662', '7.2', '', '1905-07-13'),
(2987, 'Minions & More 1', 'This collection of Minions shorts from the \"Despicable Me\" franchise includes mini-movies like \"Training Wheels,\" \"Puppy\" and \"Yellow Is the New Black.\"', 'PG', '48', 'action', 'tt22184976', '6.5', '', '1905-07-14'),
(2995, 'Gabriel Iglesias: Stadium Fluffy', 'Gabriel “Fluffy” Iglesias makes history as the first comedian to perform at Dodger Stadium in his new special Stadium Fluffy: Live From Los Angeles. Filmed at Netflix Is a Joke: The Festival, Gabriel hilariously shares details about being a Los Angeles native, a recent attempt at extortion towards him, and where he holds the record for receiving the highest fine on stage.', '', '115', 'comedy', 'tt21639094', '7.1', '', '1905-07-14'),
(3003, 'The Post-Truth World', 'A has-been newscaster Liu Li-min is taken hostage by an escaped inmate Zhang Zheng-yi, who pleads his innocence. To Liu\'s astonishment, Zhang claims that he was smeared by Liu\'s departed wife. Thus, Liu teams up with Zhang and reinvestigates Zhang\'s murder case to help his beloved be cleared of blame. However, the more they get to the bottom of the case, the further the truth is beyond their reach.', '', '120', 'thriller', 'tt22463402', '6.4', '', '1905-07-14'),
(3011, 'The Father Who Moves Mountains', 'Mircea, former Intelligence officer, finds out that his son from has gone missing in the mountains. He travels there to find him. After days of searches, Mircea put his own rescue team together, leading to conflict with the local squad.', '', '108', 'thriller', 'tt8886670', '5.5', '', '1905-07-13'),
(3019, 'Robin Robin', 'A bird raised by mice begins to question where she belongs and sets off on a daring journey of self-discovery.', 'G', '30', 'animation', 'tt11332850', '7.2', '', '1905-07-13'),
(3027, 'Who\'s a Good Boy?', 'Chema has a mission: to date Claudia, the attractive new girl at his school, and lose his virginity. Can he fulfill his dream before graduating?', 'R', '95', 'comedy', 'tt18082726', '4.6', '', '1905-07-14'),
(3043, 'The Pirates: The Last Royal Treasure', 'A gutsy crew of Joseon pirates and bandits battle stormy waters, puzzling clues and militant rivals in search of royal gold lost at sea.', '', '126', 'action', 'tt17491040', '6.1', '', '1905-07-14'),
(3051, 'Hold Your Breath: The Ice Dive', 'Follow free diver Johanna Nordblad in this documentary as she attempts to break the world record for distance traveled under ice with one breath.', '', '40', 'documentation', 'tt19373274', '', '', '1905-07-14'),
(3059, 'Audible', 'Football player Amaree McKenstry-Hall and his Maryland School for the Deaf teammates attempt to defend their winning streak while coming to terms with the tragic loss of a close friend.', '', '39', 'documentation', 'tt12771540', '5.3', '', '1905-07-13'),
(3067, 'Prime Time', 'On the last day of 1999, 20-year-old Sebastian locks himself in a TV studio. He has two hostages, a gun, and an important message for the world. The story of the attack explores a rebel’s extreme measures and last resort.', 'R', '93', 'drama', 'tt11460976', '5.2', '', '1905-07-13'),
(3075, 'Biking Borders - eine etwas andere Reise', 'Best friends Max and Nono bike from Berlin to Beijing, collecting donations to build a school for a unique fundraising adventure in this documentary.', '', '89', 'documentation', 'tt11188850', '7.7', '', '1905-07-13'),
(3083, 'Passing', 'In 1920s New York City, a Black woman finds her world upended when her life becomes intertwined with a former childhood friend who\'s passing as white.', 'PG-13', '98', 'drama', 'tt8893974', '6.7', '', '1905-07-13'),
(3091, 'The Figo Affair: The Transfer That Changed Football', 'This documentary spotlights one of the most contentious deals in football history and the extraordinary player at the center of the storm: Luís Figo.', '', '105', 'documentation', 'tt21836538', '7.1', '', '1905-07-14'),
(3099, 'The Dreamlife of Georgie Stone', 'Sharing her journey from child to teen activist, Georgie Stone looks back at her life and historic fight for transgender rights in this documentary.', 'PG', '30', 'documentation', 'tt16426596', '', '', '1905-07-14'),
(3107, 'I Am All Girls', 'A special crimes investigator forms an unlikely bond with a serial killer to bring down a global child sex trafficking syndicate.', '', '107', 'crime', 'tt9013182', '5.9', '', '1905-07-13'),
(3115, 'Togo', 'Togo just wants to watch his neighbors\' homes, wash their cars and clean up their sidewalks. But the drug traffickers want more from him.', '', '95', 'drama', 'tt15686024', '5.3', '', '1905-07-14'),
(3123, 'The Vault', 'When an engineer (Freddie Highmore) learns of a mysterious, impenetrable fortress hidden under The Bank of Spain, he joins a crew of master thieves who plan to steal the legendary lost treasure locked inside while the whole country is distracted by Spain\'s World Cup Final. With thousands of soccer fans cheering in the streets, and security forces closing in, the crew have just minutes to pull off the score of a lifetime.', 'R', '118', 'action', 'tt9742794', '6.4', '', '1905-07-13'),
(3131, 'Definition Please', 'The story of Monica Chowdry, a National Spelling Bee champ…from 15 years ago. Life hasn’t quite panned out as expected for Monica since her big win. When her estranged older brother returns home to help care for their sick mother, the siblings must find a way to reconcile.', '', '91', 'drama', 'tt10395748', '5.5', '', '1905-07-14'),
(3140, 'Ek Villain Returns', 'When a singer goes missing amid a serial killing spree, a cabbie and a businessman\'s son cross paths in a twisted tale where good and evil is blurred.', '', '127', 'thriller', 'tt11947158', '4.4', '', '1905-07-14'),
(3148, 'Rita Moreno: Just a Girl Who Decided to Go for It', 'Rita Moreno defied both her humble upbringing and relentless racism to become one of a select group who have won an Emmy, Grammy, Oscar and Tony Award. Over a seventy year career, she has paved the way for Hispanic-American performers by refusing to be pigeonholed into one-dimensional stereotypes.', 'PG-13', '90', 'documentation', 'tt10741846', '7.7', '', '1905-07-13'),
(3156, 'My Heroes Were Cowboys', 'Robin Wiltshire\'s painful childhood was rescued by Westerns. Now he lives on the frontier of his dreams, training the horses he loves for the big screen.', '', '23', 'documentation', 'tt15084326', '', '', '1905-07-13'),
(3164, 'Lords of Scam', 'This documentary traces the rise and crash of scammers who conned the EU carbon quota system and pocketed millions before turning on one another.', 'R', '105', 'documentation', 'tt15711402', '6.3', '', '1905-07-13'),
(3172, 'Worth', 'Kenneth Feinberg, a powerful D.C. lawyer appointed Special Master of the 9/11 Fund, fights off the cynicism, bureaucracy, and politics associated with administering government funds and, in doing so, discovers what life is worth.', 'PG-13', '118', 'drama', 'tt8009744', '6.8', '', '1905-07-13'),
(3180, '99 Songs', 'Challenged to compose 100 songs before he can marry the girl he loves, a tortured but passionate singer-songwriter embarks on a poignant musical journey.', '', '128', 'romance', 'tt7559180', '6.5', '', '1905-07-13'),
(3188, 'Biggie: I Got a Story to Tell', 'Christopher Wallace, AKA The Notorious B.I.G., remains one of Hip-Hop’s icons, renowned for his distinctive flow and autobiographical lyrics. This documentary celebrates his life via rare behind-the-scenes footage and the testimonies of his closest friends and family.', 'R', '97', 'music', 'tt14058484', '6.8', '', '1905-07-13'),
(3196, 'Beckett', 'An American tourist in Greece finds himself on the run after a tragic accident plunges him into a political conspiracy that makes him a target for assassination.', 'R', '109', 'thriller', 'tt10230994', '5.7', '', '1905-07-13'),
(3204, 'That\'s Amor', 'After her job and relationship implode on the same day, Sofia starts from scratch — and meets a dashing Spanish chef who might be her missing ingredient.', 'PG-13', '96', 'romance', 'tt21388556', '5.3', '', '1905-07-14'),
(3212, 'Furioza', 'An event from the past separates the fate of three friends. Unexpectedly, in the life of David (Mateusz Banasiuk) she appears again. Dzika (Weronika Ksiazkiewicz) - once the love of his life, now an experienced policewoman, makes him an offer that cannot be rejected. Either he becomes a police informant, or his brother (Wojciech Zielinski) will go to prison with a long-term sentence. Pressed against the wall, David finally succumbs, and his main goal becomes to infiltrate in an organized criminal group. Hitting the middle of a war for influence and money, he will have to face constant suspicion from Golden\'s old friend (Mateusz Damiecki). He will soon discover that the world from which he tried to free himself draws him in with redoubled strength.', '', '139', 'drama', 'tt10515864', '6.3', '', '1905-07-13'),
(3220, 'Christmas on Mistletoe Farm', 'After inheriting a farm at Christmas time, a widowed father makes a bumpy adjustment to village life — while his kids hatch a plan to stay there forever.', 'G', '104', 'family', 'tt20561114', '4.4', '', '1905-07-14'),
(3228, 'Dear Mother', 'One day, Jean-Louis discovers that his heart has stopped. He is not dead, can walk and talk, but his heart is no longer beating. With the help of his wife and a friend, he tries to understand the origin of this mystery.', '', '98', 'comedy', 'tt10551904', '5.8', '', '1905-07-13'),
(3236, 'The Reason I Jump', 'Based on the book by Naoki Higashida, filmmaker Jerry Rothwell examines the lives of five non-speaking, autistic youngsters.', '', '82', 'documentation', 'tt9098928', '7.4', '', '1905-07-13'),
(3244, 'The Minimalists: Less Is Now', 'They\'ve built a movement out of minimalism. Longtime friends Joshua Fields Millburn and Ryan Nicodemus share how our lives can be better with less.', '', '53', 'documentation', 'tt13583144', '5.9', '', '1905-07-13'),
(3252, 'Heartsong', 'While serenading a wedding that quickly implodes, a nomadic musician falls for the bride, who runs afoul of her family. Now he has to save her life.', '', '95', 'comedy', 'tt21339860', '5.8', '', '1905-07-14'),
(3260, 'Forever Rich', 'A rising rap superstar spirals out when a humiliating video goes viral and pushes him into a battle for redemption — over the course of one long night.', 'R', '89', 'comedy', 'tt12748300', '5.5', '', '1905-07-13'),
(3268, 'Shyam Singha Roy', 'A young filmmaker is in a soup right when he’s about to find his footing in the film industry. When he sets out to find an answer, turns out it’s in the past.', '', '157', 'drama', 'tt13349716', '7.7', '', '1905-07-13'),
(3276, 'Fast & Feel Love', 'When a world champion of sport stacking is dumped by his long-time girlfriend, he has to learn basic adulting skills in order to live alone and take care of himself.', '', '132', 'action', 'tt18357588', '6.9', '', '1905-07-14'),
(3284, 'Learn to Swim', 'Two contemporary jazz musicians develop a stormy and tragic romance.', '', '93', 'music', 'tt15138374', '6.2', '', '1905-07-14'),
(3292, 'Badhaai Do', 'A gay cop and a lesbian teacher enter a sham marriage to pacify their families but find that relationships — both real and fake — aren\'t all that easy.', '', '147', 'drama', 'tt11934846', '7', '', '1905-07-14'),
(3300, 'Don', 'A youngster who is still figuring out what his passion is gets into an engineering college where he clashes with a disciplinarian faculty.', '', '164', 'romance', 'tt10709484', '6.8', '', '1905-07-14'),
(3308, 'Noise', 'Julia is a mother, or rather, one of many mothers, sisters, daughters, colleagues, who have had their lives torn apart by the widespread violence in a country waging a war against its women. Julia is searching for Ger, her daughter. And in her search, she will weave through the stories and struggles of the different women she will meet.', '', '104', 'drama', 'tt11306932', '6.5', '', '1905-07-14'),
(3316, 'Cat Burglar', 'In this edgy, over-the-top, interactive trivia toon, answer correctly to help Rowdy the Cat evade Peanut the Security Pup to steal some prized paintings.', 'PG-13', '12', 'comedy', 'tt17321170', '6.9', '', '1905-07-14'),
(3324, '40 Years Young', 'After turning 40, César is invited to a culinary contest in Cancún, but a bitter discovery threatens to destroy his family as well as his chances to win the competition.', '', '81', 'comedy', 'tt16969906', '4.4', '', '1905-07-14'),
(3332, 'Franco Escamilla: Eavesdropping', 'The comic takes the stage in California to make observations about gossiping, the pandemic and airport experiences.', 'R', '122', 'comedy', 'tt22301428', '6.7', '', '1905-07-14'),
(3340, 'One Lagos Night', 'A desperate man attempts to burglarize the home of a wealthy woman, but finds himself face-to-face with a crew of armed robbers who have the same idea.', '', '103', 'crime', 'tt14211236', '6.7', '', '1905-07-13'),
(3348, 'In Good Hands', 'Diagnosed with a terminal illness, a single mother encounters a suave bachelor as she grapples with the future of her headstrong six-year-old.', '', '104', 'drama', 'tt14898794', '5.7', '', '1905-07-14'),
(3356, 'Just Say Yes', 'Incurable romantic Lotte\'s life is upended when her plans for a picture-perfect wedding unravel--just as her self-absorbed sister gets engaged.', '', '97', 'comedy', 'tt12154638', '4.5', '', '1905-07-13'),
(3364, 'The Getaway King', 'An action crime comedy set in the last days of communism in Poland, a story of folk-hero thief, who escaped 29 times from cops. Naymro was living on his own terms against the system. But love and collapsing Berlin Wall changed everything.', '', '100', 'action', 'tt10516196', '6.5', '', '1905-07-13'),
(3372, 'Jane Fonda & Lily Tomlin: Ladies Night Live', 'Jane Fonda and Lily Tomlin host an iconic celebration of women in comedy with stand-up sets from Cristela Alonzo, Margaret Cho, Michelle Buteau and more.', 'PG-13', '60', 'comedy', 'tt20723738', '5.6', '', '1905-07-14'),
(3380, 'Angèle', 'Belgian pop star Angèle reflects on her life and hopes as she finds balance amid the tears, joys and loneliness of fame. Told through her own words.', 'R', '84', 'music', 'tt15820298', '7', '', '1905-07-13'),
(3388, 'Outlaws', 'Introverted Girona student Nacho meets two delinquents from the city\'s Chinatown and gets caught up in a summer onslaught of burglaries and hold ups that will change his life.', 'R', '125', 'crime', 'tt11892272', '6.9', '', '1905-07-13'),
(3396, 'Thar', 'A mysterious stranger arrives in a village situated in the Thar desert and crosses paths with a veteran cop investigating a case of brutal killings.', '', '108', 'action', 'tt14479746', '6.1', '', '1905-07-14'),
(3412, 'A World Without', 'Founded by the power couple, Ali and Sofia Khan, The Light is a training center that claims to be a self-betterment organization, focused on helping youths take charge of their life for a brighter future. But when three best friends join this organization, they soon realize that dark shadows lurk behind The Light and must find a way to escape.', '', '106', 'thriller', 'tt15484488', '4', '', '1905-07-13'),
(3420, 'Here and There', 'As the community quarantine puts the nation on hold, a political science major and a student working part time as a delivery driver butt heads online – but soon find themselves falling for each other. Will their love survive once it’s taken offline?', '', '98', 'romance', 'tt14766058', '6.7', '', '1905-07-13'),
(3428, 'The Tambour of Retribution', 'The son of the swordsman falls in love with the daughter of Tagaga in a social paradox based on selling joy (wedding) and buying death', '', '92', 'drama', 'tt13657102', '6.8', '', '1905-07-13'),
(3436, 'Lulli', 'After getting electrocuted by an MRI machine, an ambitious young medical student begins to hear the thoughts of others.', '', '90', 'comedy', 'tt16282866', '4.8', '', '1905-07-13'),
(3444, 'The Soul', 'Wang Shicong, chairman of the famous group, died tragically at home. The prosecutor Liang Wenchao and his wife, Abang, learned during the investigation that the deceased’s long-term partner, Dr. Wan, and his ex-wife’s Son Wang Tianyou, young newlywed wife Li Yan, and even the dead ex-wife, each suspect has an intricate connection. As more clues gradually surfaced, they gradually discovered the rich. The amazing secret hidden behind the murder...', '', '130', 'scifi', 'tt13598976', '6.6', '', '1905-07-13'),
(3452, 'Meeting Point', 'A man in his fifties, a woman in her twenties, as different as you can possibly imagine. They meet by chance. They will spend a few extremely important hours together…', '', '90', 'drama', 'tt15484242', '4.2', '', '1905-07-13'),
(3460, 'Security', 'After the assault of a young woman in their seaside town, a security expert and his family get caught in a powerful riptide of secrets and lies.', '', '118', 'thriller', 'tt11892916', '5', '', '1905-07-13'),
(3476, 'Nicole Byer: BBW (Big Beautiful Weirdo)', 'Nicole takes the stage at the Gramercy Theatre for a HOT new set, discussing everything from how she basically is a vegan (she\'s just doing her part), what she\'s looking for in a man, and just how crazy this past year-and-a-half has been.', '', '65', 'comedy', 'tt15938722', '5.9', '', '1905-07-13'),
(3484, 'All Hail', 'After failing to predict a destructive hailstorm, a famous meteorologist flees to his hometown and soon finds himself on a journey of self-discovery.', '', '118', 'comedy', 'tt16427718', '5.6', '', '1905-07-14'),
(3492, 'Heroes: Silence and Rock & Roll', 'An exploration of the rise of Héroes del Silencio, the seminal 1980s Spanish rock band anchored by Enrique Bunbury.', '', '95', 'music', 'tt14354838', '7.5', '', '1905-07-13'),
(3500, 'Happy Birthday', 'A motley crew congregates at an upscale hotel for various reasons right after a bill is passed, allowing citizens to carry firearms. A madcap journey reveals everyone’s hidden motives.', '', '154', 'thriller', 'tt21149558', '5.6', '', '1905-07-14'),
(3508, 'Really Love', 'A rising black painter tries to break into a competitive art world while balancing an unexpected romance with an ambitious law student.', '', '95', 'drama', 'tt8722624', '6.1', '', '1905-07-13'),
(3516, 'Alter Ego', 'Bent on bringing sexual predators to justice, a strong-willed attorney and activist struggles with her own demons while trying to satisfy her desires.', '', '122', 'drama', 'tt7125822', '5.9', '', '1905-07-13'),
(3524, 'Dasvi', 'Jailed under a tough cop, an uneducated politician decides to spend his time studying for high school, while his scheming wife has plans of her own.', '', '125', 'comedy', 'tt14107554', '7.3', '', '1905-07-14'),
(3532, 'Battle: Freestyle', 'Amalie and Mikael lead their street dance team to the finals in France but tough competition and personal distractions threaten to ruin their dreams.', '', '88', 'drama', 'tt13350858', '4.5', '', '1905-07-14'),
(3540, 'Swallow', 'Set in the 1980s, Tolani Ajao is a bank secretary in Lagos, who finds herself persuaded by her friend Rose Adamson to enter the world of drug trafficking.', '', '128', 'drama', 'tt14391622', '3.9', '', '1905-07-13'),
(3548, 'Tuesdays And Fridays', 'Two millennials get into a relationship where they are allowed to meet only on \'Tuesdays & Fridays\'.', '', '106', 'romance', 'tt9176102', '4.5', '', '1905-07-13'),
(3556, 'Cobalt Blue', 'When an aspiring author and his free-spirited sister both fall for the enigmatic paying guest at their home, ensuing events rock their traditional family.', '', '112', 'drama', 'tt15314640', '6.5', '', '1905-07-14'),
(3564, 'The Four of Us', 'After their partner swap experiment takes a turn, four friends arrive at a remote beach hut to face the fallout and purge themselves of deeper truths.', '', '88', 'comedy', 'tt15360916', '5.3', '', '1905-07-13'),
(3572, 'Luccas Neto em: Uma Babá Muito Esquisita', 'Luccas and Gi forgot about Mother\'s Day and now they need to find a special present. Get together with the brothers and their freaky babysitter in this new adventure!', '', '75', 'comedy', 'tt14706806', '3.3', '', '1905-07-13'),
(3580, 'Tersanjung: The Movie', 'After growing up in a tumultuous household, Yura finds herself in a love triangle with two close friends as she faces a personal and financial crisis.', '', '114', 'drama', 'tt11668994', '6', '', '1905-07-13'),
(3588, 'L.O.L. Surprise! Winter Fashion Show', 'The collection with which Neonlicious was to make her debut mysteriously disappears. Now you have to use all your creativity and improvise new designs for the big parade!', '', '60', 'animation', 'tt23623604', '7.2', '', '1905-07-14'),
(3596, 'Barbie & Chelsea: The Lost Birthday', 'Enjoy high-sea thrills as Barbie, Chelsea and the rest of the Roberts family set sail on an adventure cruise.  \"Barbie & Chelsea The Lost Birthday\" tells the story of Chelsea, Barbie’s precocious youngest sister, and the rest of the Roberts family as they set sail on an adventure cruise for her seventh birthday. When they cross the International Date Line, Chelsea discovers her actual birthday has been lost and she embarks on a fantastical journey through an enchanted jungle island in order to save it.', '', '60', 'animation', 'tt14317062', '', '', '1905-07-13');
INSERT INTO `movies` (`id`, `Title`, `Description`, `COL 5`, `runtime`, `genres`, `imdb_id`, `rating`, `poster`, `release_date`) VALUES
(3604, 'The Door into Summer', 'A pioneering roboticist awakens in 2025 after decades in cryosleep. To change the past and reunite with his adopted sister, he seeks a way back to 1995.', '', '118', 'drama', 'tt13757540', '6.4', '', '1905-07-13'),
(3612, 'Untold: Crime & Penalties', 'They were the bad boys of hockey — a team bought by a man with mob ties, run by his 17-year-old son, and with a rep for being as violent as they were good.', 'R', '85', 'crime', 'tt15101956', '7.4', '', '1905-07-13'),
(3620, 'Bo Burnham: The Inside Outtakes', 'Exactly one year after the release of the one man show, \"Bo Burnham: Inside\" (made in one room, by one person, throughout the pandemic,) comes a series of unseen outtakes, deleted scenes, alternative versions of songs, and new songs unused from the special.', '', '63', 'comedy', 'tt20770080', '8.2', '', '1905-07-14'),
(3628, 'Thomas & Friends: All Engines Go - Race for the Sodor Cup', 'To win the Sodor Cup, it\'ll take more than speed. Swift engines Kana and Thomas must use their smarts and work together to cross the finish line first.', '', '60', 'animation', 'tt15337666', '3.7', '', '1905-07-13'),
(3644, 'Love', 'The story of a family and the various situations navigated by a husband and wife.', '', '91', 'thriller', 'tt12573294', '7', '', '1905-07-13'),
(3660, 'Route 10', 'Maryam and Nasser are set to travel from Riyadh to attend their father’s wedding in Abu Dhabi, until the flight is cancelled. Undaunted, they decide to make the journey by car instead. Their time together will mend a relationship that has frayed since their mother’s death as they share their feelings about their overbearing father––but, they underestimate the many hazards of the desert road, including an angry stranger whose terrifying pursuit has the brother and sister driving for their lives.', '', '82', 'thriller', 'tt18500680', '4.9', '', '1905-07-14'),
(3676, 'Naai Sekar Returns', 'Naai Sekar, who decides to make money by kidnapping dogs, learns about his pet dog which was taken away from their family during his childhood. Can he rescue his dog, which is considered as a lucky charm?', '', '144', 'comedy', 'tt15326968', '4.2', '', '1905-07-14'),
(3684, 'Dongalunnaru Jagratha', 'Raju a small time thief breaks into a customized car. As an unexpected scenario, the doors do not open and the control panel does not respond and will be trapped in it. He is in a bind as a series of unanticipated twists and turns change his life forever.', '', '96', 'thriller', 'tt15360418', '5.2', '', '1905-07-14'),
(3692, 'Before Valentine\'s', 'While preparing for the most romantic day of the year, four hairdressers at a Lagos salon face wild dramas in their love lives and their families.', '', '111', 'romance', 'tt17320674', '6.4', '', '1905-07-14'),
(3700, 'Mense van die Wind', 'After the devastating death of his girlfriend, singer-songwriter, Louw, flees the city and retreats to the tranquility of his family\'s farm, to make sense of his loss. He rekindles his friendship with an ex-girlfriend and befriends an abused and troubled teenager. By taking the teenager under his wing, Louw finds new focus and the strength to carry on.', '', '101', 'drama', 'tt21371224', '6.6', '', '1905-07-14'),
(3716, 'Hadath Fe 2 Talaat Harb', 'Four stories take place in a furnished apartment that we follow through the doorman and his family who live on top of the building in a miserable room. In the first story, a doctor tries to treat a figure with a political position. In the second story, Hassan meets in the 1970s with his old friend Nadim, who comes from Lebanon during its Civil War. The third story takes place at the beginning of the new millennium and the takeover of businessmen. As for the fourth story, it takes place before January 2011 when Sami returns under pressure from his family to sell the apartment and the whole building.', '', '115', 'drama', 'tt22393194', '5.4', '', '1905-07-14'),
(3732, 'Fine Wine', 'A beautiful love story that can happen between two people regardless of their age gaps.', '', '100', 'romance', 'tt13857480', '7.2', '', '1905-07-13'),
(3740, 'Ikaw', 'Manila-based real estate broker Dee returns to Bulusan, Sorsogon, for her grandmother Dulce’s 80th birthday. She re-acquaints with past schoolmate Edong, a seemingly unambitious and simple-minded coconut farmer. While starting at the wrong foot, they soon get to know each other more. Their mutual admiration gradually turns into love.', '', '110', 'drama', 'tt16210966', '6.4', '', '1905-07-13'),
(3748, 'Breaded Life', 'An irresponsible young man in conflict with his mother wakes up one day and to his surprise, no-one he knows can recognize him, except for a local bread hawker.', '', '120', 'comedy', 'tt15150454', '8.1', '', '1905-07-13'),
(3756, 'Oga Bolaji', 'Oga Bolaji is a story that is centered around the simple happy go lucky life of a 40-year-old retired musician \"Gold Ikponmosa\". His life takes a drastic turn when he crosses paths with a young girl. Perhaps it leads to the worst or best part of his life. Oga Bolaji showcases the resilient, ingenuity of the Nigerian spirit. The way we live, our pain, our limitations, yet we continue to strive, we continue to hope and we continue to dream.', '', '91', 'drama', 'tt8847418', '5.8', '', '1905-07-13'),
(3764, 'Al Maht', 'Based on the successful social series, “Al Maht” revolves around a struggling high school graduate in choosing his destiny.', '', '62', 'animation', 'tt14835308', '7.6', '', '1905-07-13'),
(3772, 'Spilt Gravy on Rice', 'The story revolves around the central character of Bapak, an ageing, polygamous, British-educated, Malay, Muslim, retired journalist, patriarch, who realises he doesn\'t have much time left on Earth and so invites his five children to have dinner with him to discuss some unresolved family matters with them, including who will inherit his house, their childhood home, an old decaying mansion, set in an acre of lush garden in the centre of the rapidly developing capital city of Malaysia, Kuala Lumpur.', '', '112', 'comedy', 'tt2583428', '8.1', '', '1905-07-14'),
(3780, 'A Stand Worthy of Men', 'A comedy about a group of friends as they get reunited to help one of their own find his way out of major trouble. As the situation gets more complicated, they are forced to take a trip to a coastal town.', '', '113', 'drama', 'tt13758760', '7.2', '', '1905-07-13'),
(3788, 'The Strays', 'A Black woman\'s meticulously crafted life of privilege starts to unravel when two strangers show up in her quaint suburban town.', 'R', '97', 'thriller', 'tt16437278', '4.7', '', '1905-07-15'),
(3796, 'Love at First Kiss', 'The story of Javier who, at the age of 16, while kissing a girl for the first time, realized that he had a gift of romantic clairvoyance. Javier can see the future... and he finally knows who the love of his life is.', '', '96', 'comedy', 'tt14463514', '5.7', '', '1905-07-15'),
(3804, 'Thunivu', 'A gang goes to rob a bank only to find that there\'s already a criminal mastermind holding it for ransom, but his identities and motives behind the heist remains mysterious. As they plan to collect the bounty and disappear without a trace, their crimes and their past slowly catches up with them.', '', '146', 'thriller', 'tt15163652', '6.2', '', '1905-07-15'),
(3812, 'Black Sunshine Baby', 'Family memories and personal art movingly portray author and motivational speaker Aisha Chaudhary\'s journey with an immune disorder and terminal illness.', '', '85', 'documentation', 'tt25399478', '8.5', '', '1905-07-15'),
(3820, 'Mumbai Mafia: Police vs the Underworld', 'In 1990s Mumbai, a crime boss and his network wield unchecked power over the city - until the rise of \'encounter cops\' who brazenly kill their targets.', '', '87', 'documentation', 'tt24224996', '6.4', '', '1905-07-15');

-- --------------------------------------------------------

--
-- Table structure for table `series`
--

CREATE TABLE `series` (
  `id` int(11) NOT NULL,
  `Title` varchar(83) DEFAULT NULL,
  `Description` varchar(1731) DEFAULT NULL,
  `COL 6` varchar(17) DEFAULT NULL,
  `runtime` varchar(7) DEFAULT NULL,
  `genres` varchar(122) DEFAULT NULL,
  `seasons` int(7) DEFAULT NULL,
  `imdb_id` varchar(10) DEFAULT NULL,
  `rating` varchar(10) DEFAULT NULL,
  `poster` text DEFAULT NULL,
  `release_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `series`
--

INSERT INTO `series` (`id`, `Title`, `Description`, `COL 6`, `runtime`, `genres`, `seasons`, `imdb_id`, `rating`, `poster`, `release_date`) VALUES
(38, 'Arrested Development', 'The story of a wealthy family that lost everything, and the one son who had no choice but to keep them all together.', 'TV-MA', '28', 'comedy', 5, 'tt0367279', '8.7', 'https://m.media-amazon.com/images/M/MV5BNTFlYTE2YTItZmQ1NS00ZWQ5LWI3OGUtYTQzNDMyZmEyYTZjXkEyXkFqcGdeQXVyNDg4NjY5OTQ@._V1_SX300.jpg', '2003-00-00'),
(42, 'Supernatural', 'When they were boys, Sam and Dean Winchester lost their mother to a mysterious and demonic supernatural force. Subsequently, their father raised them to be soldiers. He taught them about the paranormal evil that lives in the dark corners and on the back roads of America ... and he taught them how to kill it. Now, the Winchester brothers crisscross the country in their \'67 Chevy Impala, battling every kind of supernatural threat they encounter along the way. ', 'TV-14', '45', 'drama', 15, 'tt0460681', '8.4', 'https://m.media-amazon.com/images/M/MV5BNzRmZWJhNjUtY2ZkYy00N2MyLWJmNTktOTAwY2VkODVmOGY3XkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg', '2005-00-00'),
(46, 'The IT Crowd', 'Two I.T. nerds and their clueless female manager, who work in the basement of a very successful company. When they are called on for help, they are never treated with any respect at all.', 'TV-14', '25', 'comedy', 5, 'tt0487831', '8.5', 'https://m.media-amazon.com/images/M/MV5BMjE5MThjMzAtNWVmNC00YThkLTlmNzktMTM3Yzk4YTZhMTgwXkEyXkFqcGdeQXVyNTAyODkwOQ@@._V1_SX300.jpg', '2006-00-00'),
(50, 'Monster', 'Kenzou Tenma, a Japanese brain surgeon in Germany, finds his life in utter turmoil after getting involved with a psychopath that was once a former patient.', 'TV-14', '23', 'drama', 1, 'tt0434706', '8.7', 'https://m.media-amazon.com/images/M/MV5BM2ZkYTAwMGMtOGEwOS00MzBjLTgxOGYtZTYwY2E1ZjMyZmY4XkEyXkFqcGdeQXVyNTgyNTA4MjM@._V1_SX300.jpg', '2004-00-00'),
(54, 'Ancient Aliens', 'Did intelligent beings from outer space visit Earth thousands of years ago? From the age of the dinosaurs to ancient Egypt, from early cave drawings to continued mass sightings in the US, each episode gives historic depth to the questions, speculations, provocative controversies, first-hand accounts and grounded theories surrounding this age old debate.', 'TV-PG', '46', 'scifi', 19, 'tt1643266', '8.1', 'https://m.media-amazon.com/images/M/MV5BMGY1ZTdmMWItNjI1MS00MTUwLTkwNTgtYTFiMGVjOTBmMDMyXkEyXkFqcGdeQXVyNzM3MjY2MjU@._V1_SX300.jpg', '2010-00-00'),
(58, 'Pawn Stars', 'Go inside the colorful world of the pawn business. At the Gold & Silver Pawn Shop on the outskirts of Las Vegas, generations of the Harrison family run the family business, and there’s clashing and camaraderie every step of the way.', 'TV-PG', '25', 'reality', 21, 'tt1492088', '7.2', 'https://m.media-amazon.com/images/M/MV5BMTQ3OTkxMDEwMV5BMl5BanBnXkFtZTgwMjAyMDI2MDI@._V1_SX300.jpg', '2009-00-00'),
(62, 'Transformers: Prime', 'Roll out with Optimus Prime, Bumblebee, Arcee, Ratchet, Bulkhead, and the rest of the heroic Autobots as they battle the evil Decepticons. Now that big bad Megatron has returned with a mysterious and dangerous element, Team Prime must prepare for an epic battle.', 'TV-Y7', '22', 'action', 4, 'tt1659175', '7.9', 'https://m.media-amazon.com/images/M/MV5BMGY0ZGMwY2QtMGUwOC00MmVhLTljMzktNGYzNDFmYzAzODMwXkEyXkFqcGdeQXVyODk1MjAxNzQ@._V1_SX300.jpg', '2010-00-00'),
(66, 'Laguna Beach', 'Like other teens in California, the lives of the Laguna Beach teenagers are filled with sandy beaches, beautiful friends and love triangles. But unlike other teens, they had cameras following them around. It may look like fantasyland, but they\'re not acting: they really are this rich and beautiful. For them, life really is a day at the beach.', 'TV-PG', '23', 'reality', 4, 'tt0426738', '4.8', 'https://m.media-amazon.com/images/M/MV5BMTgyNTM4MzM3NV5BMl5BanBnXkFtZTcwNjMyOTIzMQ@@._V1_SX300.jpg', '2004-00-00'),
(70, 'Hidden Passion', 'The Reyes-Elizondo\'s idyllic lives are shattered by a murder charge against Eric and León.', 'TV-14', '43', 'drama', 2, 'tt0387763', '7.8', 'https://m.media-amazon.com/images/M/MV5BY2NmODYxZjMtMGY1Zi00YTlhLTk5NjMtZWQ4MWMxZTA5ODZlXkEyXkFqcGdeQXVyMzA5NzYzNw@@._V1_SX300.jpg', '2003-00-00'),
(74, 'Sonic X', 'Sonic and his friends team up with 12 year old Christopher to collect all the Chaos Emeralds and defeat the evil Dr. Eggman.', 'TV-Y7', '21', 'action', 3, 'tt0367413', '6.2', 'https://m.media-amazon.com/images/M/MV5BMzE3NmQ5ZmQtZTU0ZS00YjEyLWJiOTItMTAzNzNkYWYyZDcyXkEyXkFqcGdeQXVyNTUxMTQwOTg@._V1_SX300.jpg', '2003-00-00'),
(78, 'Autumn\'s Concerto', 'Ren Guang Xi, a cocky law student, seems to lead the perfect life. He\'s the sole successor to a huge and famous business and is a talented ice hockey player. But in reality, his lonely life lacks joy, laughter and motivation. That is until he meets Liang Mu Cheng, the new bento seller at his school canteen. A harmless bet brings the two together and Guang Xi slowly changes as Mu Cheng teaches him how to give and love. Tragedy strikes when Guang Xi suddenly has to go through a major brain surgery which causes him to lose his memory.', 'TV-14', '58', 'drama', 1, 'tt3530668', '7.9', 'https://m.media-amazon.com/images/M/MV5BMjM5MGRiZTQtOTk4Zi00NzM4LWFhNmItZjk3MmYwNDU4MWVjXkEyXkFqcGdeQXVyNjc3MjQzNTI@._V1_SX300.jpg', '2009-00-00'),
(82, 'Toradora!', 'Ryūji Takasu is a gentle high school student with a love for housework; but in contrast to his kind nature, he has an intimidating face that often gets him labeled as a delinquent. On the other hand is Taiga Aisaka, a small, doll-like student who is anything but a cute and fragile girl. Equipped with a wooden katana and feisty personality, Taiga is known throughout the school as the \"Palmtop Tiger.\" One day, an embarrassing mistake causes the two students to cross paths. Ryūji discovers that Taiga actually has a sweet side: she has a crush on the popular vice president, Yūsaku Kitamura, who happens to be his best friend. But things only get crazier when Ryūji reveals that he has a crush on Minori Kushieda—Taiga\'s best friend! Toradora! is a romantic comedy that follows this odd duo as they embark on a quest to help each other with their respective crushes, forming an unlikely alliance in the process.', 'TV-14', '30', 'animation', 2, 'tt1279024', '8', 'https://m.media-amazon.com/images/M/MV5BNWEwMjE2MjQtZTQ3NC00OTUxLWEwMWUtMThjZjg4Zjc5ZDYwXkEyXkFqcGdeQXVyMzgxODM4NjM@._V1_SX300.jpg', '2008-00-00'),
(86, 'Code Lyoko', 'Code Lyoko centers on four children who travel to the virtual world of Lyoko to battle against a sentient artificial intelligence named XANA, with a virtual human called Aelita.', 'TV-G', '24', 'scifi', 5, 'tt0417311', '7.3', 'https://m.media-amazon.com/images/M/MV5BNzkwZDJjYWEtZTY5Yy00OTRmLWIyNzEtN2ZlZjVlMzI1NDVkXkEyXkFqcGdeQXVyNjcwMzExMzU@._V1_SX300.jpg', '2003-00-00'),
(90, 'H2O: Just Add Water', 'H2O: Just Add Water revolves around three teenage girls facing everyday teen problems with an added twist: they cope with the burden of growing a giant fin and transforming into mermaids whenever they come in contact with water.', 'TV-PG', '25', 'drama', 3, 'tt0491603', '7.2', 'https://m.media-amazon.com/images/M/MV5BYzY5MmYxNDItOWVkZS00MzFiLTlhMDQtNzZlZjQ3YmY3YzAxXkEyXkFqcGdeQXVyMTUyNjc3NDQ4._V1_SX300.jpg', '2006-00-00'),
(94, 'The Legend of Bruce Lee', 'The story of the legendary martial arts icon Bruce Lee following him from Hong Kong to America and back again, leading up to his tragic death at the age of 32.', '', '45', 'action', 1, 'tt1059455', '7', 'https://m.media-amazon.com/images/M/MV5BMjA4MDc3MTQ3NV5BMl5BanBnXkFtZTcwNDU4MDc5MQ@@._V1_SX300.jpg', '2008-00-00'),
(98, 'Big Time Rush', 'Four teenage friends move from Minneapolis to Los Angeles to form a potential chart-topping boy band after Kendall is inadvertently discovered by an eccentric record executive, Gustavo Rocque. As they seize this opportunity of a lifetime, these friends embark on an exciting comedy and music-filled journey to prove to themselves and their record label that they are serious about their new career choice.', 'TV-G', '25', 'comedy', 4, 'tt1131746', '6.4', 'https://m.media-amazon.com/images/M/MV5BMjIzNDE4MTM2Ml5BMl5BanBnXkFtZTcwNjYyNTA2Mw@@._V1_SX300.jpg', '2009-00-00'),
(102, 'Masha and the Bear', 'Masha is an energetic three-year-old who can’t seem to keep herself out of trouble. Bear is a warm, fatherly figure that does his best to guide his friend and keep her from harm, often ending up the unintended victim of her misadventures.', 'TV-Y', '6', 'animation', 5, 'tt1884856', '7.5', 'https://m.media-amazon.com/images/M/MV5BOTBkNWQ3OWEtYjUyNy00ODBmLWE3ZTMtOWJhZWYyMmE2MGI1XkEyXkFqcGdeQXVyNzMwOTY2NTI@._V1_SX300.jpg', '2009-00-00'),
(106, 'Ben & Holly\'s Little Kingdom', 'The friendship between fairy princess Holly and Ben Elf in an enchanted magical kingdom of elves and fairies.', 'TV-G', '14', 'comedy', 3, 'tt1436544', '7.4', 'https://m.media-amazon.com/images/M/MV5BYTViNmY1MmEtNDNmMi00ODgyLWJhNDgtY2E5NzA0NGFmMTk5XkEyXkFqcGdeQXVyNjMxMzM3NDI@._V1_SX300.jpg', '2009-00-00'),
(110, 'Wakfu', 'Follow Yogu and his friends Amalia, Evangelyne, Tristepin, Ruel and Az as they try to rescue the world of Wakfu from destruction.', 'TV-Y7', '22', 'scifi', 3, 'tt1807824', '8.1', 'https://m.media-amazon.com/images/M/MV5BMjNlMzNjMTMtNDAxYi00M2QxLTlmYWQtMTdkZDljMmIzYjI5XkEyXkFqcGdeQXVyMzM4NjcxOTc@._V1_SX300.jpg', '2008-00-00'),
(114, 'Chhota Bheem', 'Chhota Bheem is an Indian animated series adventures about a boy named Bheem and his friends in fictional village of Dholakpur.Bheem and his friends are usually involved in protecting the village from various evil forces.', '', '22', 'action', 12, 'tt4570986', '4.4', 'https://m.media-amazon.com/images/M/MV5BMzAyMDQwMGYtMGNmNS00OWM4LTlmMTAtM2E5YjQ4Yjk1ZmEwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2008-00-00'),
(118, 'The Prince Who Turns into a Frog', 'The Prince Who Turns Into a Frog is a 2005 Taiwanese drama starring Ming Dow and Sam Wang of boyband 183 Club; and Joe Chen and Joyce Zhao of girl group 7 Flowers, as well as all the members of the former and two members of the latter, who are signed by Jungiery Entertainment. It was produced by Sanlih E-Television and directed by Chen Ming Zhang and Liu Jun Jie.\n\nThe series was first broadcast in Taiwan on free-to-air Taiwan Television from 5 June 2005 to 16 October 2005, every Sunday at 21:30 and cable TV Sanlih E-Television from 11 June 2005 to 22 October 2005, every Saturday at 21:00.\n\nEpisode seven was broadcast on 17 July 2005, it achieved an average rating of 7.05 and peaked at 8.05, which broke the previous average record of 6.43 held by Meteor Garden and was the highest peak for a single episode for a Taiwanese drama until it was broken by episode 13 of Fated To Love You which peaked at 8.13 in 2008.', 'TV-14', '44', 'drama', 1, 'tt1454440', '6.8', 'https://m.media-amazon.com/images/M/MV5BZDNmM2EwODEtZDBjMC00NmJlLWJmYWItNGYxOTA5ODUyZjU1XkEyXkFqcGdeQXVyMjg0MTI5NzQ@._V1_SX300.jpg', '2005-00-00'),
(122, 'Kung Fu Panda Awesome Secrets', 'In this pair of adventures, Po tells the story of how masters Thundering Rhino, Storming Ox and Croc met and takes on Shifu\'s biggest challenge yet.', 'TV-PG', '0', 'action', 1, 'tt6963796', '7', 'https://m.media-amazon.com/images/M/MV5BNWMxZjI1ZGEtMWE3Zi00NjNmLTg4OWYtZWE1MzU2NmNhZTdmXkEyXkFqcGdeQXVyNDY5MTUyNjU@._V1_SX300.jpg', '2008-00-00'),
(126, 'The Hospital', 'When the President\'s only daughter, Liu Xinping, checks into a hospital for her chemotherapy treatment, the head of internal medicine and the head of surgery become core members of the President\'s medical team. Both men plan to use this opportunity to prove themselves as the best candidate for the position of hospital director. As a result, the two men appoint rival surgeons to attend to Xiuping\'s surgery.', 'TV-14', '48', 'drama', 1, 'tt2823414', '7.3', 'https://m.media-amazon.com/images/M/MV5BNTVkNzVhNjEtNzVlOS00MjA5LWFmODItZmE1YzI5YmIyOWYzXkEyXkFqcGdeQXVyMjg0MTI5NzQ@._V1_SX300.jpg', '2006-00-00'),
(130, 'Pink Zone', 'Is the story of four friends: Natalia, Angélica, Vicky and Sara. The four of them live together and try to live together despite having their differences. They all support Natalia\'s dream. Natalia is a 25-year-old young woman, recently graduated from her cooking studies, who dreams of setting up her own restaurant, and wants her friends to be her partners and that her best friend Andrés also be the administrator. However, despite her dreams, Natalia has had very bad luck in her relationships. Her last boyfriend Federico was cheating on her and leaves her to marry another woman. However, she does not suspect that her best friend Andrés is secretly in love with her and tries to win her over and change her perception of men.', '', '15', 'romance', 1, 'tt11194518', '6.2', 'https://m.media-amazon.com/images/M/MV5BZDMzZmY0NDAtNjY0NC00NjdiLWE4YjUtZjZmZTc5NTg5ZjcwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2007-00-00'),
(134, 'Shameless', 'Chicagoan Frank Gallagher is the proud single dad of six smart, industrious, independent kids, who without him would be... perhaps better off. When Frank\'s not at the bar spending what little money they have, he\'s passed out on the floor. But the kids have found ways to grow up in spite of him. They may not be like any family you know, but they make no apologies for being exactly who they are.', 'TV-MA', '54', 'drama', 11, 'tt1586680', '8.6', 'https://m.media-amazon.com/images/M/MV5BZDgxNjQ2MjMtMjk2Yi00M2Q2LWI0ZDktOGM1NWI5YWUzMjk4XkEyXkFqcGdeQXVyOTA3MTMyOTk@._V1_SX300.jpg', '2011-00-00'),
(138, 'Arrow', 'Spoiled billionaire playboy Oliver Queen is missing and presumed dead when his yacht is lost at sea. He returns five years later a changed man, determined to clean up the city as a hooded vigilante armed with a bow.', 'TV-14', '42', 'drama', 8, 'tt2193021', '7.5', 'https://m.media-amazon.com/images/M/MV5BMTI0NTMwMDgtYTMzZC00YmJhLTg4NzMtMTc1NjI4MWY4NmQ4XkEyXkFqcGdeQXVyNTY3MTYzOTA@._V1_SX300.jpg', '2012-00-00'),
(142, 'The Legend of Korra', 'Avatar Korra, a headstrong, rebellious, feisty young woman who continually challenges and breaks with tradition, is on her quest to become a fully realized Avatar. In this story, the Avatar struggles to find balance within herself.', 'TV-Y7', '23', 'scifi', 4, 'tt1695360', '8.4', 'https://m.media-amazon.com/images/M/MV5BYTZhNGY2ZDAtYWYxYy00YWNlLWI3NDUtNjBiM2NkMGVmODIxXkEyXkFqcGdeQXVyODUwNjEzMzg@._V1_SX300.jpg', '2012-00-00'),
(146, 'JoJo\'s Bizarre Adventure', 'Follow the intergenerational feud between the Joestar Family and various forces of evil, the most prominent of which is Dio Brando and his followers.', 'TV-MA', '24', 'animation', 5, 'tt2359704', '8.5', 'https://m.media-amazon.com/images/M/MV5BZDc3NGQ3ZWQtYjNkOC00MjhiLTg2N2YtNmZlOGNiZTFkOWNhXkEyXkFqcGdeQXVyNjc2NjA5MTU@._V1_SX300.jpg', '2012-00-00'),
(150, 'Lilyhammer', 'After Frank The Fixer Tagliano testifies against his Mafia boss in New York, he enters the Witness Protection Program and makes an unusual demand: he wants to be set up with a new life in the Norwegian small town of Lillehammer or as he calls it, Lilyhammer.', 'TV-MA', '45', 'drama', 3, 'tt1958961', '7.9', 'https://m.media-amazon.com/images/M/MV5BMTU5NjAyOTkyM15BMl5BanBnXkFtZTgwNzIzODAwMzE@._V1_SX300.jpg', '2012-00-00'),
(154, 'Rita', 'Independent, outspoken and adored by her students, private school teacher Rita fares less well with adults.', 'TV-MA', '40', 'drama', 5, 'tt1973692', '8.1', 'https://m.media-amazon.com/images/M/MV5BYmQwOTA1ZTAtYTUwMS00ZGFhLTljMWYtZGNkZWZjYjgzMjIwXkEyXkFqcGdeQXVyMTAxNDMzOTk1._V1_SX300.jpg', '2012-00-00'),
(158, 'Transformers: Rescue Bots', 'A team of specialized Autobots not quite ready for prime-time battles against the Decepticons is given a vital mission by Optimus Prime. The goal for the Bots is to learn about mankind and how to help others to find out what it really means to be a hero.', 'TV-Y7', '22', 'scifi', 4, 'tt2139371', '6.6', 'https://m.media-amazon.com/images/M/MV5BMTkwNTE2MzU1Nl5BMl5BanBnXkFtZTgwNjQ1MDgwMDE@._V1_SX300.jpg', '2012-00-00'),
(162, 'Cuckoo', 'Cuckoo is every parent\'s worst nightmare - a slacker full of outlandish, New Age ideas. Ken is the over-protective father of a girl who\'s impulsively married an American hippie on her gap year.', 'TV-MA', '27', 'comedy', 5, 'tt2222352', '5.9', 'https://m.media-amazon.com/images/M/MV5BZjVhMGQzYTAtZGU3Ni00ZThjLTgzZWYtN2YwZmU3OWNiOTJjXkEyXkFqcGdeQXVyOTA1ODU0Mzc@._V1_SX300.jpg', '2012-00-00'),
(166, 'The Ultimate Braai Master', 'A South African team competition on open fire cooking.', 'TV-PG', '45', 'reality', 5, 'tt3264864', '7.9', 'https://m.media-amazon.com/images/M/MV5BM2VlYmRhYTMtZmM0Mi00OWZmLWFmZmEtNTFlZGVmYTEyYjcxXkEyXkFqcGdeQXVyMjExMzA5NTU@._V1_SX300.jpg', '2012-00-00'),
(170, 'Magi', 'This story is about the flow of fate and the battle to keep the world on the right path. Aladdin is a boy who has set out to explore the world after being trapped in a room for most of his life. His best friend is a flute with a djinn in it named Ugo. Soon enough, Aladdin discovers he is a Magi, a magician who chooses kings, and he was born to choose kings who will follow the righteous path, battling against those who want to destroy fate. Follow his adventures as he meets others from 1001 Arabian Nights, like Ali Baba and Sinbad, and fights to keep the balance of world in check!', 'TV-14', '24', 'action', 3, 'tt2425098', '7.8', 'https://m.media-amazon.com/images/M/MV5BZGEyNmQ0ZWQtYzE1Mi00ZDhkLThlZDctOTkxNTMyZWU5MmE1XkEyXkFqcGdeQXVyMjQzMjY4MjU@._V1_SX300.jpg', '2012-00-00'),
(174, 'LEGO City', 'The robbers escape from their cells and are up to no good – their adventures are funny and entertaining. The city police are put to the test. Will our heroes catch the robber? See the Lego City characters and the trusted city police dog come together to help put them back behind bars.', 'TV-G', '3', 'animation', 3, 'tt6800590', '5', 'https://m.media-amazon.com/images/M/MV5BMmVjZDA1MWEtMjVjZS00NjlhLWIwM2QtMjI1OTc3N2FiNGY3XkEyXkFqcGdeQXVyNDA3MzI1ODQ@._V1_SX300.jpg', '2011-00-00'),
(178, 'Love, Now', 'Love, Now is a 72 episode Taiwanese idol romance drama television series created and developed by SETTV. It stars Annie Chen, George Hu as the main leads and Bobby Dou, Harry Chang from Taiwanese band Da Mouth and Vivi Lee as the supporting leads. The drama is set to debut on SETTV and ETTV on 31 October 2012. It ended its last episode on 5 March 2013 with 72 episodes', 'TV-Y', '45', 'drama', 1, 'tt6273116', '7.4', 'https://m.media-amazon.com/images/M/MV5BNmJmODY3ZDUtYWE4ZC00N2RkLTg4ZTQtMDMzNzAwODQ4NDI4L2ltYWdlXkEyXkFqcGdeQXVyMjg0MTI5NzQ@._V1_SX300.jpg', '2012-00-00'),
(182, 'Smile PreCure!', 'Candy, a fairy from Märchenland follows the shining light that leads to the five legendary PreCure warriors in order to fight Bad End Kingdom villains who are trying to vanquish the entire world to the “Worst Ending.', 'TV-Y7', '22', 'action', 2, 'tt2230557', '6.2', 'https://m.media-amazon.com/images/M/MV5BZDA4ZDVkMjQtNzIyNC00YTRiLTk3ODYtYzIzZGZlN2EyMzBlXkEyXkFqcGdeQXVyMTEzMTI1Mjk3._V1_SX300.jpg', '2012-00-00'),
(186, '19-Feb', 'Character-driven drama, 19-2 revolves around the day-to-day life of two  unwilling partners of the Montreal Police Department, Officers Nick  Barron and Ben Chartier. These two beat cops patrol the urban sprawl of  downtown\'s 19th district, in cruiser No. 2. 19-2 is about the tensions  and bonds that develop between two incompatible men of very different  temperaments and life experiences. Over time, Nick and Ben\'s mistrust  and antagonism for each other give way to moments of mutual respect and a  wavering chance at a true partnership. As Season 1 progresses, we also  get to know the tight-knit squad of 19. We see friendship and enmity,  loyalty and betrayal. The series delivers in portraying the  unpredictability and fragility of the world of a beat cop through  moments of life-threatening intensity to its characters, both on and off  duty, cementing 19-2 as a powerful character study and a gripping  police drama.', 'TV-MA', '43', 'action', 3, 'tt1840973', '8.6', 'https://m.media-amazon.com/images/M/MV5BNjcyNDc1NTAyNV5BMl5BanBnXkFtZTcwMjE2MDc1OQ@@._V1_SX300.jpg', '2011-00-00'),
(190, 'The Flash', 'After a particle accelerator causes a freak storm, CSI Investigator Barry Allen is struck by lightning and falls into a coma. Months later he awakens with the power of super speed, granting him the ability to move through Central City like an unseen guardian angel. Though initially excited by his newfound powers, Barry is shocked to discover he is not the only \"meta-human\" who was created in the wake of the accelerator explosion -- and not everyone is using their new powers for good. Barry partners with S.T.A.R. Labs and dedicates his life to protect the innocent. For now, only a few close friends and associates know that Barry is literally the fastest man alive, but it won\'t be long before the world learns what Barry Allen has become...The Flash.', 'TV-14', '42', 'scifi', 9, 'tt3107288', '7.5', 'https://m.media-amazon.com/images/M/MV5BYmMxNGQ4NzYtYmQzNC00N2I2LWI5NzUtMTU5MDczZGEzNDBlXkEyXkFqcGdeQXVyMTUzMTg2ODkz._V1_SX300.jpg', '2014-00-00'),
(194, 'Peaky Blinders', 'A gangster family epic set in 1919 Birmingham, England and centered on a gang who sew razor blades in the peaks of their caps, and their fierce boss Tommy Shelby, who means to move up in the world.', 'TV-MA', '58', 'drama', 6, 'tt2442560', '8.8', 'https://m.media-amazon.com/images/M/MV5BZjYzZDgzMmYtYjY5Zi00YTk1LThhMDYtNjFlNzM4MTZhYzgyXkEyXkFqcGdeQXVyMTE5NDQ1MzQ3._V1_SX300.jpg', '2013-00-00'),
(198, 'BoJack Horseman', 'Meet the most beloved sitcom horse of the 90s - 20 years later. BoJack Horseman was the star of the hit TV show \"Horsin\' Around,\" but today he\'s washed up, living in Hollywood, complaining about everything, and wearing colorful sweaters.', 'TV-MA', '26', 'comedy', 6, 'tt3398228', '8.8', 'https://m.media-amazon.com/images/M/MV5BYWQwMDNkM2MtODU4OS00OTY3LTgwOTItNjE2Yzc0MzRkMDllXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg', '2014-00-00'),
(202, 'Orange Is the New Black', 'A crime she committed in her youthful past sends Piper Chapman to a women\'s prison, where she trades her comfortable New York life for one of unexpected camaraderie and conflict in an eccentric group of fellow inmates.', 'TV-MA', '59', 'comedy', 7, 'tt2372162', '8.1', 'https://m.media-amazon.com/images/M/MV5BYjYyM2FmMmMtZDgyZi00NGU3LWI3NzktODllZDY0YzQyNzgyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg', '2013-00-00'),
(206, 'Henry Danger', 'When 13-year-old Henry Hart lands a job as Danger, the sidekick-in-training to superhero Captain Man, he must learn to navigate a double life balancing the challenges of 8th grade with the crazy adventures of a real-life crime fighter!', 'TV-G', '24', 'comedy', 5, 'tt3596174', '5.8', 'https://m.media-amazon.com/images/M/MV5BOGFlOGIyMDMtYTg4My00MzQxLTgwYWItZDQxOThjNDllYWE5XkEyXkFqcGdeQXVyODk4Nzg5NjE@._V1_SX300.jpg', '2014-00-00'),
(210, 'Saving My Stupid Youth', 'Heisuke teaches at his alma mater, an all-boy’s Buddhist high school and leads a very ordinary life, except for the fact that he is still tortured by the memory of an unfortunate incident that took place there involving him and his school 14 years ago. In hopes of closure, he strikes upon a plan to jointly hold this year’s Culture Festival with a nearby girl’s school, with which there are chilly relations. Determined at all costs to make the event a success, Heisuke finds himself dealing with a constant stream of problems along the way.', 'TV-14', '54', 'drama', 1, 'tt3912208', '7.3', 'https://m.media-amazon.com/images/M/MV5BNTZkMmMwMzgtODFiMS00ZjE3LWIzNTMtOWRhOTJmYzczMzNkXkEyXkFqcGdeQXVyMjU0ODQ5NTA@._V1_SX300.jpg', '2014-00-00'),
(214, 'Moving Art', 'Experience nature\'s art as filmmaker Louie Schwartzberg highlights the beauty that lurks in oceans, forests, deserts and flowers.', '', '28', 'documentation', 3, 'tt6953912', '8.6', 'https://m.media-amazon.com/images/M/MV5BZDBlYjIwOGItZjdkZi00ZjZiLTkwOTItNTRjYjFhYzI0NjAxXkEyXkFqcGdeQXVyMTc3MTI1NzE@._V1_SX300.jpg', '2014-00-00'),
(222, 'Sailor Moon Crystal', 'Usagi Tsukino is chosen to be a guardian of justice and is sent on a quest to locate a Silver Crystal before the Dark Kingdom invades the Earth.', 'TV-14', '24', 'animation', 4, 'tt0114327', '7.8', 'https://m.media-amazon.com/images/M/MV5BZDI4MmMyMjgtNjgxMi00NDU4LTliOGUtMzgxNDE3ZmIxM2NkXkEyXkFqcGdeQXVyNjk1Njg5NTA@._V1_SX300.jpg', '2014-00-00'),
(226, 'Rabbids Invasion', 'The Rabbids are back in their new tv show. The rabbids discovers new things and learn what they do. But that they don\'t know is that they are curious.', 'TV-Y7', '10', 'animation', 4, 'tt3105674', '5.4', 'https://m.media-amazon.com/images/M/MV5BMzcxOTcxNjgtZTM3Zi00N2YyLTlhY2MtYjY5NDQxNjhmNzAyXkEyXkFqcGdeQXVyMjI3MDQ5NDY@._V1_SX300.jpg', '2013-00-00'),
(230, 'Nicky, Ricky, Dicky & Dawn', 'The story of a 10-year-old girl Dawn Haley whose sibling rivalry with her three brothers is heightened by the fact that they are quadruplets.', 'TV-G', '23', 'comedy', 4, 'tt3596176', '5.2', 'https://m.media-amazon.com/images/M/MV5BMzc5ZDc3NzgtYWVmMS00NjcyLWFiOGMtMmRmYmY4MGNiYTY5XkEyXkFqcGdeQXVyNzQwNzI0OA@@._V1_SX300.jpg', '2014-00-00'),
(234, 'Lalaloopsy', 'The Lalaloopsy gang and their adorable pets know every day is a perfect day to celebrate the magic of friendship, creativity and collaboration.', 'TV-Y', '23', 'animation', 3, 'tt2827502', '4.4', 'https://m.media-amazon.com/images/M/MV5BMTg0OTYzNTk2OV5BMl5BanBnXkFtZTgwMjk5ODAxMzE@._V1_SX300.jpg', '2013-00-00'),
(238, 'Incomplete Life', 'Equipped with nothing more than a GED and strategies for the game of go, an office intern gets thrown into the cold reality of the corporate world.', 'TV-14', '73', 'drama', 1, 'tt4240730', '8.5', 'https://m.media-amazon.com/images/M/MV5BZmNiYjU3MDYtZDhlNy00ZWZjLTg0ZWUtYzA1OGQ3NTJkMDRlXkEyXkFqcGdeQXVyMzE4MDkyNTA@._V1_SX300.jpg', '2014-00-00'),
(242, 'Talking Tom and Friends', 'Armed with technological gear, great ideas and an unfailing sense of humour, Talking Tom and his friends are on a mission to reach stardom at all costs.', 'TV-G', '9', 'comedy', 5, 'tt13011686', '6.1', 'https://m.media-amazon.com/images/M/MV5BZGIwZWI1MmEtNWEyZC00NjFiLTgyNDktMzc0M2RkYmMzZTljXkEyXkFqcGdeQXVyMTI3Mzk5NDg0._V1_SX300.jpg', '2014-00-00'),
(246, 'Masha\'s Spooky Stories', 'Masha explains why there\'s no need to be scared of things like monsters, the dark, going to a new school, thunder and other common childhood fears.', 'TV-Y', '6', 'family', 1, 'tt6979430', '6.2', 'https://m.media-amazon.com/images/M/MV5BMmIwZTZhNTktNjcxMS00MGU0LTg3YTctYjVjZDA1ZTA5YjVkXkEyXkFqcGdeQXVyMjA4OTQ2OTk@._V1_SX300.jpg', '2014-00-00'),
(250, 'Mighty Raju', 'A four-year-old Raju receives super human strength when his then pregnant mother accidentally consumes a compound created by his scientist father.', '', '20', 'animation', 4, 'tt6491030', '4.7', 'https://m.media-amazon.com/images/M/MV5BNDliYjY5ZGItNmQzNC00YTE4LWIwZmYtOTQyMjFhM2M3MzE3XkEyXkFqcGdeQXVyMTAzOTAxNjIw._V1_SX300.jpg', '2014-00-00'),
(254, 'Dreamworks How to Train Your Dragon Legends', 'In this set of shorts Hiccup and the gang learn about different species of dragons.Then, Gobber goes in search of the Boneknapper Dragon.', '', '23', 'animation', 1, 'tt6963396', '7.3', 'https://m.media-amazon.com/images/M/MV5BODdhMzNjNGItYmUzMC00NWM5LTgyYmEtNzI3YjFlNGY5MTkyXkEyXkFqcGdeQXVyNTM3MDMyMDQ@._V1_SX300.jpg', '2013-00-00'),
(258, 'Stranger Things', 'When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl.', 'TV-14', '61', 'drama', 5, 'tt4574334', '8.7', 'https://m.media-amazon.com/images/M/MV5BMDZkYmVhNjMtNWU4MC00MDQxLWE3MjYtZGMzZWI1ZjhlOWJmXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg', '2016-00-00'),
(262, 'Documentary Now!', 'Loving parodies of some of the world\'s best-known documentaries. Each episode is shot in a different style of documentary filmmaking, and honors some of the most important stories that didn\'t actually happen.', 'TV-14', '22', 'comedy', 4, 'tt4677934', '8.1', 'https://m.media-amazon.com/images/M/MV5BMTQ2Mjg3NTA5NV5BMl5BanBnXkFtZTgwNzExNTU1NjE@._V1_SX300.jpg', '2015-00-00'),
(266, 'Lucifer', 'Bored and unhappy as the Lord of Hell, Lucifer Morningstar abandoned his throne and retired to Los Angeles, where he has teamed up with LAPD detective Chloe Decker to take down criminals. But the longer he\'s away from the underworld, the greater the threat that the worst of humanity could escape.', 'TV-14', '47', 'scifi', 6, 'tt4052886', '8.1', 'https://m.media-amazon.com/images/M/MV5BNDJjMzc4NGYtZmFmNS00YWY3LThjMzQtYzJlNGFkZGRiOWI1XkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg', '2016-00-00'),
(274, 'The OA', 'Prairie Johnson, blind as a child, comes home to the community she grew up in with her sight restored. Some hail her a miracle, others a dangerous mystery, but Prairie won’t talk with the FBI or her parents about the seven years she went missing.', 'TV-MA', '55', 'scifi', 2, 'tt4635282', '7.8', 'https://m.media-amazon.com/images/M/MV5BMTY5OTkwNDkzOF5BMl5BanBnXkFtZTgwMDEyNzI1NzM@._V1_SX300.jpg', '2016-00-00'),
(278, 'Slasher', 'Thirty years ago, in the sleepy community of Waterbury, a killer known as “The Executioner” murdered Sarah Bennett\'s parents. Now Sarah and her husband Dylan have returned to town, only to find herself the centerpiece in a series of horrifying murders centered around the seven deadly sins.', 'TV-MA', '46', 'crime', 5, 'tt4667888', '6.7', 'https://m.media-amazon.com/images/M/MV5BYzc3ZWFhNzItMGRkMi00YWQxLWIxN2YtZjQ0MDVlNTExMzJjXkEyXkFqcGdeQXVyMTQ5MDIxMzkw._V1_SX300.jpg', '2016-00-00'),
(282, 'iZombie', 'A medical student who becomes a zombie joins a Coroner\'s Office in order to gain access to the brains she must reluctantly eat so that she can maintain her humanity. But every brain she eats, she also inherits their memories and must now solve their deaths with help from the Medical examiner and a police detective.', 'TV-14', '42', 'scifi', 5, 'tt3501584', '7.8', 'https://m.media-amazon.com/images/M/MV5BZWNhODE4NzAtN2JjOC00ODJjLThhNzAtMWM1NDg4ZDQxNzMzXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg', '2015-00-00'),
(286, 'Medici: Masters of Florence', 'The story of the Medici family of Florence, their ascent from simple merchants to power brokers sparking an economic and cultural revolution. Along the way, they also accrue a long list of powerful enemies.', 'TV-14', '54', 'drama', 3, 'tt5057130', '7.9', 'https://m.media-amazon.com/images/M/MV5BMzY2M2E1MGMtMjA4MS00ODcwLWEwNDctNTAwOWQ2MTYwZmFkXkEyXkFqcGdeQXVyMTk4NDUxNzY@._V1_SX300.jpg', '2016-00-00'),
(290, '60 Days In', 'An unprecedented look at life behind bars at Indiana\'s Clark County Jail as seven innocent volunteers are sent to live among its general population for 60 days without officers, fellow inmates, or staff knowing their secret.', 'TV-14', '46', 'reality', 7, 'tt10112398', '7.6', 'https://m.media-amazon.com/images/M/MV5BYjgzYTM3MGQtMDk4Yy00NTg5LTkxYzAtMWM2MDBlNjExOWVkXkEyXkFqcGdeQXVyMjk1NzczNzY@._V1_SX300.jpg', '2016-00-00'),
(294, 'The Full-Time Wife Escapist', 'A series of events leads single, 25-year-old Mikuri Moriyama and 36-year-old Hiramasa Tsuzaki to marry as a cover.', 'TV-PG', '55', 'drama', 1, 'tt5917100', '7.9', 'https://m.media-amazon.com/images/M/MV5BNGUzNjYwYWUtNTljZi00ZGU2LTg2NjAtZGY2ZTFlNzRiM2JmXkEyXkFqcGdeQXVyNzMwOTY2NTI@._V1_SX300.jpg', '2016-00-00'),
(298, 'ERASED', 'Satoru Fujinuma is a struggling manga artist who has the ability to turn back time and prevent deaths. When his mother is killed he turns back time to solve the mystery, but ends up back in elementary school, just before the disappearance of his classmate Kayo.', 'TV-14', '22', 'drama', 1, 'tt5249462', '8.5', 'https://m.media-amazon.com/images/M/MV5BYzJmZjZkMjQtZjJmZC00M2JkLTg5MzktN2FkOTllNTc5MmMzXkEyXkFqcGdeQXVyNjAwNDUxODI@._V1_SX300.jpg', '2016-00-00'),
(302, 'Roman Empire', 'This stylish mix of documentary and historical epic chronicles the reign of Commodus, the emperor whose rule marked the beginning of Rome\'s fall.', 'TV-14', '44', 'drama', 3, 'tt6233538', '7', 'https://m.media-amazon.com/images/M/MV5BY2UxYmY0NDktYTk2Mi00ZjI4LWJhYTAtYTEzMzYyNGU3ZTEzL2ltYWdlL2ltYWdlXkEyXkFqcGdeQXVyMjMyMTk1OQ@@._V1_SX300.jpg', '2016-00-00'),
(306, 'Versailles', 'The story of a young Louis XIV on his journey to become the most powerful monarch in Europe, from his battles with the fronde through his development into the Sun King. Historical and fictional characters guide us in a world of betrayal and political maneuvering, revealing Versailles in all its glory and brutality.', 'TV-MA', '54', 'drama', 3, 'tt10509540', '7.9', 'https://m.media-amazon.com/images/M/MV5BOWVjMmMwMjItMjEyNy00ZmZjLWE0OTAtYzljNWFjMDAxMGIwXkEyXkFqcGdeQXVyNTM4MjQ4MA@@._V1_SX300.jpg', '2015-00-00'),
(310, 'Unnatural Selection', 'Three high school students decide to escape the mundane urban environment and embark on a fishing adventure.', 'TV-MA', '35', 'reality', 1, 'tt11063952', '7.9', 'https://m.media-amazon.com/images/M/MV5BYmRjOWU0MDAtMzRiZi00ZGUzLWFmZjItOTQwZDAxYzlkZjM1XkEyXkFqcGdeQXVyMjMyNTY1MDc@._V1_SX300.jpg', '2015-00-00'),
(314, 'Occupied', 'In the near future, Norway is occupied by Russia on behalf of the European Union, due to the fact that the newly elected environmental friendly Norwegian government has stopped the all important oil- and gas-production in the North Sea.', 'TV-MA', '45', 'war', 3, 'tt4192998', '7.6', 'https://m.media-amazon.com/images/M/MV5BODVkNzdiZmQtNGRkYS00MWQwLWEzY2EtOTI3ZmU5MjAyOWYwXkEyXkFqcGdeQXVyMTQ5MjkwNDI@._V1_SX300.jpg', '2015-00-00'),
(318, 'Haters Back Off', 'Delve into the oddball family life of Miranda Sings, an incredibly confident, totally untalented star on the rise, who continues to fail upward by the power of her belief that she was born famous, it\'s just no one knows it yet.', 'TV-14', '29', 'comedy', 2, 'tt5467814', '6', 'https://m.media-amazon.com/images/M/MV5BMjMzNzEwNDIzNl5BMl5BanBnXkFtZTgwMzI4OTMyMDI@._V1_SX300.jpg', '2016-00-00'),
(322, 'Public Enemy', 'Freed after 20 years in prison, the child killer Guy Beranger found refuge with the monks in Vielsart, a small village in Belgian\'s Ardennes. He is placed under the protection of a young Federal Police\'s inspector, Chloé Muller. A little while after his release, a little girl disappears.', 'TV-MA', '53', 'drama', 2, 'tt4706558', '7.5', 'https://m.media-amazon.com/images/M/MV5BYWRhZjcxMjktOTk5Zi00N2I3LWFiYmYtOTM3ZGI0NTQ4NDY0XkEyXkFqcGdeQXVyNDMyMTQwNjg@._V1_SX300.jpg', '2016-00-00'),
(326, 'Coach Snoop', 'See a different side of Snoop Dogg in this unique documentary, which details the famous rapper\'s efforts to mentor young athletes and create opportunities for them to compete at the highest level of youth football. We\'ll meet the kids and coaches that form Snoop\'s squad -- and witness the important life lessons they learn with every game.', 'TV-MA', '30', 'documentation', 2, 'tt5697642', '6.8', 'https://m.media-amazon.com/images/M/MV5BMjQ3OWNlNDAtODZlOS00Y2NhLThiNTEtMWI4MWFkMTZjMGUzXkEyXkFqcGdeQXVyODQ1NTk5OQ@@._V1_SX300.jpg', '2016-00-00'),
(330, 'PJ Masks', 'Connor, Greg and Amaya are normal kids by day, but at night they activate their bracelets, which link into their pajamas and give them fantastic super powers, turning them into their alternate identities: The PJ Masks. The team consists of Catboy (Connor), Gekko (Greg) and Owelette (Amaya). Together, they go on adventures, solve mysteries, and learn valuable lessons.', 'TV-G', '15', 'fantasy', 5, 'tt4148744', '5.3', 'https://m.media-amazon.com/images/M/MV5BMWEzOGY1ZjUtNzdkNS00YzI1LWE0ODktODBiZTVjZDM5ODI5XkEyXkFqcGdeQXVyOTcyNTkzOTA@._V1_SX300.jpg', '2015-00-00'),
(334, 'Trollhunters: Tales of Arcadia', 'After uncovering a mysterious amulet, an average teen assumes an unlikely destiny and sets out to save two worlds.', 'TV-Y7', '22', 'scifi', 3, 'tt1734135', '8.4', 'https://m.media-amazon.com/images/M/MV5BN2Y2YWE0ZDMtNzQzMC00MDI0LThlZjAtMWY4YjZlYWM2OWFjXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2016-00-00'),
(338, 'Hip Hop Evolution', 'Hip-Hop today is a global culture that has changed music, dance, fashion, language —and even politics. But where did this worldwide cultural movement begin? We trace hip-hop back to its humble beginnings, when the kids of the Bronx crammed into house parties, rec rooms, and public parks to hear music like they’d never heard it before.', 'TV-MA', '45', 'documentation', 4, 'tt4130418', '8.4', 'https://m.media-amazon.com/images/M/MV5BODRiOTFhNWItMDc2Yi00OGY2LTgxZDktMDYwMTU1ZjFkZDQyL2ltYWdlL2ltYWdlXkEyXkFqcGdeQXVyMjQzNDE1NTc@._V1_SX300.jpg', '2016-00-00'),
(342, 'Marseille', 'The longtime mayor of Marseille is preparing to hand over the reins to his protégé when a sudden and ruthless battle erupts for control of the city.', 'TV-MA', '42', 'drama', 2, 'tt4003966', '6.9', 'https://m.media-amazon.com/images/M/MV5BMjMwNTY0NjU5N15BMl5BanBnXkFtZTgwODYyNzc3NDM@._V1_SX300.jpg', '2016-00-00'),
(346, 'Chef\'s Table', 'In this Emmy-nominated docuseries, find out what\'s inside the kitchens and minds of the international culinary stars who are redefining gourmet food.', 'TV-MA', '50', 'documentation', 7, 'tt4295140', '8.5', 'https://m.media-amazon.com/images/M/MV5BMjE3MDQ2OTYyN15BMl5BanBnXkFtZTgwNjQ0Nzg0NzM@._V1_SX300.jpg', '2015-00-00'),
(350, 'The Deep', 'The adventures of the Nekton family, a family of daring underwater explorers who live aboard a state-of-the-art submarine, The Aronnax, and explore uncharted areas of the earth\'s oceans to unravel the mysteries of the deep.', 'TV-Y7', '22', 'action', 4, 'tt4991910', '7.9', 'https://m.media-amazon.com/images/M/MV5BMTQ4ODY1NTYzMl5BMl5BanBnXkFtZTgwMTUwMjYwODE@._V1_SX300.jpg', '2015-00-00'),
(354, 'The Princess Weiyoung', 'A princess descended from a ruined noble family disguises herself as the woman who saved her life and embarks on a mission to avenge her loved ones.', 'TV-14', '45', 'drama', 1, 'tt6353308', '7.8', 'https://m.media-amazon.com/images/M/MV5BNGFlNDQwMzItMDdjYS00YzQ1LWI1N2QtZTYxMjhjMDI5YWNjXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2016-00-00'),
(358, 'The Haunted House', 'With help from a 102-year-old goblin dwelling beneath their haunted apartment building, two siblings deal with ghosts and take on spooky mysteries.', 'TV-PG', '25', 'thriller', 7, 'tt9518312', '8.3', 'https://m.media-amazon.com/images/M/MV5BODQyNDM5NjYtNDk4OS00ZDZjLWFiNDYtNTRkYTc4OGFhOGE2XkEyXkFqcGdeQXVyMTA4MTc3OTc0._V1_SX300.jpg', '2016-00-00'),
(362, 'Danger Mouse', 'Danger Mouse is back saving London, saving the World and, most importantly, saving Penfold in brand new and fantastically absurd, energetic adventures.', '', '12', 'animation', 2, 'tt4196822', '7.1', 'https://m.media-amazon.com/images/M/MV5BOTkxNTU0NjgtOGQ0Yi00YTYwLWEzZTQtY2QzYjY1NGFiNWRhXkEyXkFqcGdeQXVyNTU0MTE4NjY@._V1_SX300.jpg', '2015-00-00'),
(366, 'Good Morning Call', 'A high school girl finally gets her own apartment, but she has to share it with the most popular boy in school. No one can know they\'re living together.', 'TV-14', '48', 'comedy', 2, 'tt5520732', '7.5', 'https://m.media-amazon.com/images/M/MV5BZDIzODYyYzctZTI3OS00OWFhLWI1ZWMtNzNhMzJhY2MyMzM0XkEyXkFqcGdeQXVyMjU0ODQ5NTA@._V1_SX300.jpg', '2016-00-00'),
(370, 'Degrassi: Next Class', 'Follow a group of high school freshmen, sophomores, juniors, and seniors from Degrassi Community School, a fictional school in Toronto, Ontario, as they encounter some of the typical issues and challenges common to a teenager\'s life.', 'TV-PG', '24', 'drama', 6, 'tt10947610', '6.9', 'https://m.media-amazon.com/images/M/MV5BNDVjMzVkNjQtM2ZlZi00NzM1LThlODctZTBkOTBiZDdkNTU4XkEyXkFqcGdeQXVyNzQ3MjAyOTU@._V1_SX300.jpg', '2016-00-00'),
(374, 'Transformers: Robots In Disguise', 'Years after the events of Predacons Rising, Bumblebee is summoned back to Earth to battle several of Cybertron\'s most wanted Decepticons that escaped from a crashed prison ship and assembles a team of young Autobots that includes Sideswipe (a rebel \"bad boy bot\"), Strongarm (an Elite Guard cadet), Grimlock (a bombastic Dinobot), and Fixit (a hyperactive Mini-Con with faulty wiring).', 'TV-Y7', '21', 'animation', 5, 'tt3604232', '6', 'https://m.media-amazon.com/images/M/MV5BNjk0NjY1YjItZjNlNC00ZGJhLTg1YzAtZWYzZDljOGUyN2IxXkEyXkFqcGdeQXVyMTA0MTM5NjI2._V1_SX300.jpg', '2015-00-00'),
(378, 'Lady Dynamite', 'A single-camera half-hour comedy based on what Maria Bamford has accepted to be \"her life.\" It\'s the sometimes surreal story of a woman who loses — and then finds — her s**t.', 'TV-MA', '30', 'comedy', 2, 'tt4789300', '7.3', 'https://m.media-amazon.com/images/M/MV5BMTU2OTM0NjkzNF5BMl5BanBnXkFtZTgwOTc2MDU5MzI@._V1_SX300.jpg', '2016-00-00'),
(382, 'Beat Bugs', 'Jay, Kumi, Crick, Buzz, and Walter are best friends who band together to explore and learn in an overgrown suburban backyard, which to them is their entire universe. Each episode of this animated series features songs by The Beatles performed by artists including Daniel Johns, Robbie Williams and Pink to tell uplifting and life-affirming stories filled with hope and melody.', 'TV-Y', '15', 'animation', 3, 'tt4716268', '7.6', 'https://m.media-amazon.com/images/M/MV5BMmUxNDZiYjktM2U1Zi00NTkwLTgyZGItM2FkMTk4NTU1MGM4XkEyXkFqcGdeQXVyMjM5MTQyODM@._V1_SX300.jpg', '2016-00-00'),
(386, 'Terrace House: Aloha State', 'The beautiful island of Oahu is host to a new batch of six strangers who share a single roof, multiple conflicts and no script in this reality series.', '', '36', 'reality', 4, 'tt6588218', '7.5', 'https://m.media-amazon.com/images/M/MV5BNzM4ZGM4MWUtNDFkMS00ZjdmLWI2MDMtMDFjZGFlYzFmOWI0XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2016-00-00'),
(390, 'Paranoid', 'The murder of a female GP in a rural playground in front of numerous witnesses draws a group of detectives into an ever-darkening mystery that takes them across Europe, aided by mysterious notes sent by the \"Ghost Detective\".', '', '44', 'thriller', 1, 'tt5839454', '6.6', 'https://m.media-amazon.com/images/M/MV5BNWJlNjA5MjMtMDRlOS00NGE0LTk3YTYtNTM4ZjBhNTNlNzcwXkEyXkFqcGdeQXVyNzQ5MzY0NjM@._V1_SX300.jpg', '2016-00-00'),
(394, 'Dinotrux', 'Half dinosaur, half construction truck, full-on fun! Watch giant Ty Rux, his little buddy Revvit and the crew come face-to-face with evil D-Structs.', 'TV-Y7', '23', 'animation', 5, 'tt1396212', '6.8', 'https://m.media-amazon.com/images/M/MV5BZjMyYWE2NDEtMzgxYi00MzQ3LTlmZWEtNDI5NGIxMjdjMDg3XkEyXkFqcGdeQXVyMzQwMDg1MDI@._V1_SX300.jpg', '2015-00-00'),
(398, 'Project Mc²', 'McKeyla, Adrienne, Bryden, and Camryn are four super smart and science-skilled girls recruited to join the spy organization, NOV8.', 'TV-G', '25', 'family', 6, 'tt4861760', '6.1', 'https://m.media-amazon.com/images/M/MV5BMjQxMjkxNTY4Nl5BMl5BanBnXkFtZTgwNjk5MjE1NjE@._V1_SX300.jpg', '2015-00-00'),
(402, 'Terrace House: Boys & Girls in the City', 'Six men and women start off as strangers and live together under one roof. All that is provided is a beautiful house and a car. There is no script.', 'TV-14', '28', 'reality', 1, 'tt4790546', '8.1', 'https://m.media-amazon.com/images/M/MV5BN2ZhNmJmY2QtMjBjYy00NWM0LTllZTUtZTJkNjFmMmYyMWJiL2ltYWdlXkEyXkFqcGdeQXVyMjYzMjA3NzI@._V1_SX300.jpg', '2015-00-00'),
(406, 'Word Party', 'Meet Bailey, Franny, Kip and Lulu. They\'re adorable baby animals, and they want you to join the party and help them learn!', 'TV-Y', '13', 'animation', 5, 'tt5235950', '5.6', 'https://m.media-amazon.com/images/M/MV5BNmQwYzgzMzUtZDY2ZC00NTI5LWE2OTctZTY4NmEzOGU5MDk5XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2016-00-00'),
(410, 'White Nights', 'Seo Yi-Kyung ambitiously wants to build her own empire. She is calm and also passionate. She doesn\'t believe greed is a sin. Park Gun-Woo possesses good looks and comes from a wealthy family that runs a large company. Seo Yi-Kyung is his first love and he is still in love with her. Lee Se-Jin comes from a poor background. She desperately wants to escape from her situation.', 'TV-14', '62', 'drama', 1, 'tt6168004', '6.9', 'https://m.media-amazon.com/images/M/MV5BZGIyN2VhMzEtYmRkMi00NmRlLWJhOTItMmZhMTUzM2NhMmRjL2ltYWdlL2ltYWdlXkEyXkFqcGdeQXVyMzE4MDkyNTA@._V1_SX300.jpg', '2016-00-00'),
(414, 'Hibana: Spark', 'Tokunaga, a comedian who is down on his luck, has a shock encounter with Kamiya, an older comedian when he visits a fireworks event in Atami on a job. Tokunaga is deeply touched by Kamiya and asks if he can become his apprentice. Kamiya is a genius type of comedian who is full of human kindness. He accepts Tokunaga’s proposition on the condition that he will write his biography.', 'TV-MA', '53', 'drama', 1, 'tt5301958', '7.8', 'https://m.media-amazon.com/images/M/MV5BODFlYzk2YWEtYWUxOC00NGQwLWE0NDEtMDdmYTU0ZGIxZmQ2XkEyXkFqcGdeQXVyMjI1ODY4OTk@._V1_SX300.jpg', '2016-00-00'),
(418, 'Cinderella and Four Knights', 'Eun Ha-Won is a college student. She is a bright girl who wants to be a veterinarian, but at home she is lonely. She is isolated from her family members. Eun Ha-Won lives with father, step-mother and step-sister after her mother died in a car accident. One day, she helps a mysterious old man. The old man suggests to her to live in a mansion and pursue her dream of becoming a veterinarian. Since than, she moves into the mansion and lives with three cousins Kang Ji-Woon, Kang Hyun-Min, Kang Seo-Woo and their bodyguard Lee Yoon-Sung.', 'TV-PG', '61', 'drama', 1, 'tt5764414', '7.4', 'https://m.media-amazon.com/images/M/MV5BZDk4MzYxMjYtNWI0ZS00NDE1LTk5YjYtZjI4NDM1ZTBhZjdmXkEyXkFqcGdeQXVyMzE4MDkyNTA@._V1_SX300.jpg', '2016-00-00'),
(422, 'Sunny Bunnies', 'Furry little bunnies hop through wild adventures as they find solutions, fun and sometimes mischief wherever there is light.', 'TV-Y', '3', 'animation', 5, 'tt7264084', '6.1', 'https://m.media-amazon.com/images/M/MV5BY2ZiNDdhMTctNTFkOS00NGI4LWJjYjYtZGI1ZjY1M2Q5NmRiXkEyXkFqcGdeQXVyODE2ODYyNjg@._V1_SX300.jpg', '2015-00-00'),
(426, 'The Sound of Your Heart', 'Comedy following Cho Seok\'s ridiculous but hilarious adventures with his girlfriend-turned-wife Ae Bong, their dogs, older brother Jo Joon, and parents. Based on the popular webtoon series of the same name.', '', '24', 'drama', 2, 'tt4613520', '8.2', 'https://m.media-amazon.com/images/M/MV5BOTNjMDIyMDktMDQwOS00OGU0LWI1ZjAtNTliOTZlNzA0MmMzXkEyXkFqcGdeQXVyMjgxMTM2OQ@@._V1_SX300.jpg', '2016-00-00'),
(430, 'The Good Cop', 'Danny Confino is a full-time cop, during one of the police\'s worst times. A period in which its image is at a low ebb, they are ousted every week, harassed by commanders twice a week, budgets are cut and complaints against police are piled up in DIP offices. He returns to his parents\' home in order to live there temporarily, but the temporary becomes permanent and Danny finds that life at home is superior to any crime scene.', 'TV-MA', '28', 'comedy', 3, 'tt6070434', '7.6', 'https://m.media-amazon.com/images/M/MV5BYjRhMzVmNGEtYzNlYS00ZWE0LTg4YTMtYjFkZTU3NTk1NDFiXkEyXkFqcGdeQXVyMjMyMzI4MzY@._V1_SX300.jpg', '2015-00-00'),
(434, 'Atelier', 'A young \"fabric geek\" lands a job at an upscale Japanese lingerie company — and quickly discovers she\'ll need help to survive.', 'TV-14', '69', 'drama', 1, 'tt0843393', '5', 'https://m.media-amazon.com/images/M/MV5BNGYyNWFjOTgtYTQwOS00MGNmLTkxYzctZTAwMDU1NmU2MTExXkEyXkFqcGdeQXVyMjY4NDQyNDI@._V1_SX300.jpg', '2015-00-00'),
(438, 'Luna Petunia', 'Luna Petunia follows the adventures of a girl who lives in our world and plays in a dreamland where she learns how to make the impossible possible.', 'TV-Y', '24', 'animation', 3, 'tt4588068', '6.4', 'https://m.media-amazon.com/images/M/MV5BYTljZWZiY2QtYzA0Zi00ZTQ0LWJkY2EtNjBmMTgxNzNmZTQyXkEyXkFqcGdeQXVyMTU3NDg0OTgx._V1_SX300.jpg', '2016-00-00'),
(442, 'Netflix Presents: The Characters', 'No rules. No expectations. A half hour to make their mark. Eight different comedians each get an episode to show their skills in comedy.', 'TV-MA', '31', 'comedy', 1, 'tt5228026', '5.4', 'https://m.media-amazon.com/images/M/MV5BMDQ5OGQyZDItM2RkYi00YjIwLTk5MTctMTAzNzczZDI5YzE0XkEyXkFqcGdeQXVyNjYzMDA4MTI@._V1_SX300.jpg', '2016-00-00'),
(446, 'Love Storm', 'Three grown siblings must rethink their idea of family when they learn their parents are getting divorced and have their eyes on new partners.', 'TV-14', '87', 'family', 1, 'tt6093070', '5.5', 'https://m.media-amazon.com/images/M/MV5BYThhNWE2ZDMtMjE5MS00MzI0LTkzMzctYzc3ZTVkMTEzODM4XkEyXkFqcGdeQXVyMjU1NTY2NTA@._V1_SX300.jpg', '2016-00-00'),
(454, 'StoryBots Super Songs', 'Based on the award-winning educational apps, \"StoryBots Super Songs\" centers on the StoryBots, the curious little creatures who live in the world beneath our screens and help answer humans\' biggest questions.', 'TV-Y', '21', 'animation', 1, 'tt6163070', '8.7', 'https://m.media-amazon.com/images/M/MV5BM2EwY2M4NjgtN2NiMC00MzUwLWFmMjctMDkzODEwZmVhYmRhXkEyXkFqcGdeQXVyNjgxOTE3Njc@._V1_SX300.jpg', '2016-00-00'),
(458, 'You', 'A dangerously charming, intensely obsessive young man goes to extreme measures to insert himself into the lives of those he is transfixed by.', 'TV-MA', '48', 'drama', 4, 'tt7335184', '7.7', 'https://m.media-amazon.com/images/M/MV5BNGZjZDc3NjAtYjI1OC00NWUzLWIxOWItNzUyODc5NDIwMWRjXkEyXkFqcGdeQXVyNTQ4ODA2NzQ@._V1_SX300.jpg', '2018-00-00'),
(462, 'Derry Girls', 'Amidst the political conflict of Northern Ireland in the 1990s, five secondary school students square off with the universal challenges of being a teenager.', 'TV-MA', '26', 'comedy', 3, 'tt7120662', '8.5', 'https://m.media-amazon.com/images/M/MV5BNzU0MTFiNjUtNzIxMi00ZGZiLTgwZmUtMjIxOWNmMDE0NTE1XkEyXkFqcGdeQXVyNjg0NTcxMTg@._V1_SX300.jpg', '2018-00-00');
INSERT INTO `series` (`id`, `Title`, `Description`, `COL 6`, `runtime`, `genres`, `seasons`, `imdb_id`, `rating`, `poster`, `release_date`) VALUES
(466, 'Babylon Berlin', 'Beneath the decadence of 1929 Berlin, lies an underworld city of sin. Police investigator Gareon Rath has been transferred from Cologne to the epicenter of political and social changes in the Golden Twenties.', 'TV-MA', '47', 'drama', 4, 'tt4378376', '8.4', 'https://m.media-amazon.com/images/M/MV5BMjQ2MzVhMmMtYWJmNy00NmVlLThmODktOTI5YzBjMTU4N2E3XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2017-00-00'),
(470, 'The Haunting of Hill House', 'The Crains, a fractured family, confront haunting memories of their old home and the terrifying events that drove them from it.', 'TV-MA', '58', 'drama', 1, 'tt6763664', '8.6', 'https://m.media-amazon.com/images/M/MV5BMTU4NzA4MDEwNF5BMl5BanBnXkFtZTgwMTQxODYzNjM@._V1_SX300.jpg', '2018-00-00'),
(474, 'Godless', 'A ruthless outlaw terrorizes the West in search of a former member of his gang, who’s found a new life in a quiet town populated only by women.', 'TV-MA', '65', 'western', 1, 'tt5516154', '8.3', 'https://m.media-amazon.com/images/M/MV5BMTY0NzkxNDcxNF5BMl5BanBnXkFtZTgwOTI5ODM5MzI@._V1_SX300.jpg', '2017-00-00'),
(478, 'A Series of Unfortunate Events', 'The orphaned Baudelaire children face trials, tribulations and the evil Count Olaf, all in their quest to uncover the secret of their parents\' death.', 'TV-PG', '47', 'action', 3, 'tt4834206', '7.8', 'https://m.media-amazon.com/images/M/MV5BMTYzMjA3OTgxOV5BMl5BanBnXkFtZTgwMjAwMDU5NjM@._V1_SX300.jpg', '2017-00-00'),
(486, 'MTV Floribama Shore', 'Eight young people spend the summer in Panama City Beach in hopes of finding love, cash and close friends.', 'TV-14', '41', 'reality', 5, 'tt7577814', '5.2', 'https://m.media-amazon.com/images/M/MV5BYzNkZTBkNDktNTdlYy00MmY4LWFlMDMtYjQ1YjJlZDY5YzQ4XkEyXkFqcGdeQXVyMTUwNjg3NTUw._V1_SX300.jpg', '2017-00-00'),
(490, 'The End of the F***ing World', 'James is 17 and is pretty sure he is a psychopath. Alyssa, also 17, is the cool and moody new girl at school. The pair make a connection and she persuades him to embark on a darkly comedic road trip in search of her real father.', 'TV-MA', '21', 'drama', 2, 'tt6257970', '8', 'https://m.media-amazon.com/images/M/MV5BN2ZhNmQ2MjQtMmQzMi00YjE5LTlkMWMtMjk5YzIxMjk2NDc2XkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg', '2017-00-00'),
(494, 'Imposters', 'Maddie, a persona shifting con-artist who is as beautiful as she is dangerous, leaves her unwitting victims tormented when they realize they have been used and robbed of everything – including their hearts. But things get complicated when her former targets, Ezra, Richard, and Jules team up to track her down.', 'TV-14', '43', 'drama', 2, 'tt5212822', '7.8', 'https://m.media-amazon.com/images/M/MV5BNzYzMTY2MzYyNF5BMl5BanBnXkFtZTgwMjE2NDMzNTM@._V1_SX300.jpg', '2017-00-00'),
(498, 'Good Girls', 'Three \"good girl\" suburban wives and mothers suddenly find themselves in desperate circumstances and decide to stop playing it safe and risk everything to take their power back.', 'TV-14', '42', 'drama', 4, 'tt6474378', '7.7', 'https://m.media-amazon.com/images/M/MV5BYmFmNTVjM2ItNDNmNC00NTU3LWIwNDQtNDhlNThhNjE1MDBjXkEyXkFqcGdeQXVyMTEyMjM2NDc2._V1_SX300.jpg', '2018-00-00'),
(502, 'My Next Guest Needs No Introduction With David Letterman', 'TV legend David Letterman teams up with fascinating global figures for in-depth interviews and curiosity-fueled excursions in this monthly talk show.', 'TV-MA', '50', '', 4, 'tt7829834', '7.9', 'https://m.media-amazon.com/images/M/MV5BZmM1NjcwYWItOWVjNy00NTMyLTk1YjYtMGMwZWFhMDQ1MWU4XkEyXkFqcGdeQXVyNDA5NTgxNjU@._V1_SX300.jpg', '2018-00-00'),
(506, 'Norm Macdonald Has a Show', 'Based on his podcast, comedianNorm Macdonald and his sidekick Adam Egret sit down and chat with celebrity guests about their life, career and views in a somewhat unconventional and often irreverent way.', '', '30', 'comedy', 1, 'tt8139862', '8.5', 'https://m.media-amazon.com/images/M/MV5BMDFmNWNmNmItNDBhOS00MmNmLThlNzktM2ZmNjliZjMxMjU4XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(510, 'Medal of Honor', 'Honoring service members whose courage merited the awarding of a Medal of Honor, this docudrama series re-creates their inspiring true stories.', 'TV-MA', '55', 'documentation', 1, 'tt7440274', '8.3', 'https://m.media-amazon.com/images/M/MV5BMjIxMjExNjktM2E1MS00ZjFjLThmNjQtZjFmMjYzYWI1MDdmXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(514, 'On My Block', 'A coming of age comedy following a diverse group of teenage friends as they confront the challenges of growing up in gritty inner-city Los Angeles.', 'TV-14', '29', 'comedy', 4, 'tt7879820', '7.9', 'https://m.media-amazon.com/images/M/MV5BY2Q0MDJiNGYtZTU0MS00YzBkLTkzNGEtNTUzNzQ4MDA1YjMwXkEyXkFqcGdeQXVyMTEyMjM2NDc2._V1_SX300.jpg', '2018-00-00'),
(518, 'The New Legends of Monkey', 'Follow a teenage girl and a trio of fallen gods on a perilous journey as they attempt to bring an end to a demonic reign of chaos and restore balance to their world. Inspired by the 16th Century Chinese fable “Journey to the West.”', 'TV-PG', '26', 'scifi', 2, 'tt6807662', '6.5', 'https://m.media-amazon.com/images/M/MV5BMjc4ODY2NzctOGJlNy00MjA0LTg3NzQtODBmZTgwN2QzMzliXkEyXkFqcGdeQXVyMTQyMTMwOTk0._V1_SX300.jpg', '2018-00-00'),
(522, 'Knightfall', 'Go deep into the clandestine world of the legendary brotherhood of warrior monks known as The Knights Templar.', 'TV-14', '44', 'action', 2, 'tt4555364', '6.8', 'https://m.media-amazon.com/images/M/MV5BODgyODU5MjcyNF5BMl5BanBnXkFtZTgwNTgwMjQ4NzM@._V1_SX300.jpg', '2017-00-00'),
(526, 'Westside', 'Nine struggling musicians share the spotlight in this deeply personal reality series about the challenges and thrills of staging a Hollywood showcase.', 'TV-MA', '50', 'reality', 1, 'tt8693758', '6.2', 'https://m.media-amazon.com/images/M/MV5BMjM5Mzc2MjE4Ml5BMl5BanBnXkFtZTgwMDMxMTI1NjM@._V1_SX300.jpg', '2018-00-00'),
(530, 'She-Ra and the Princesses of Power', 'In this reboot of the \'80s series, a magic sword transforms an orphan girl into warrior She-Ra, who unites a rebellion to fight against evil.', 'TV-Y7', '24', 'scifi', 5, 'tt7745956', '8', 'https://m.media-amazon.com/images/M/MV5BNGIzOGQxZDEtOTVhNC00YzgyLWE2ZjItNDM5YjQ0MTZlZTUwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(538, 'Samantha!', 'A child star in the \'80s, Samantha clings to the fringes of celebrity with hilarious harebrained schemes to launch herself back into the spotlight.', 'TV-MA', '28', 'comedy', 2, 'tt6626676', '6.6', 'https://m.media-amazon.com/images/M/MV5BNDBmMGZiNmUtNTRhYS00NDk3LTlkNWUtYzk5YjcxN2M5MmRhXkEyXkFqcGdeQXVyMTAyNDU1Njc2._V1_SX300.jpg', '2018-00-00'),
(542, 'Cold Case Files', 'There are over 100,000 cold cases in America, and only about 1% are ever solved. With recent advancements in technology and the methods used to solve these cases, as well as the unwavering dedication of victims’ families, law enforcement and the public, “Cold Case Files” explores the cases that defied the odds.\n\nEach episode of the Emmy-nominated series examines the twists and turns of one murder case that remained unsolved for years, and the critical element that heated it up, leading to the evidence that finally solved it. Featuring interviews with family members, friends, detectives, and others close to the cases, the refreshed classic series examines all facets of the crime and shines a light on a range of voices and victims.', 'TV-14', '43', 'crime', 3, 'tt6459472', '7.9', 'https://m.media-amazon.com/images/M/MV5BNDFmZmJjOWItMDdjYy00ZmM5LWExZmEtZTQ5YWMzYmUzNzVhXkEyXkFqcGdeQXVyNzM3MjY2MjU@._V1_SX300.jpg', '2017-00-00'),
(546, 'White Gold', 'The story of a double-glazing showroom in Essex in the 80s, led by charismatic Vincent Swan, and his unscrupulous sales team, Brian Fitzpatrick and Martin Lavender.', 'TV-MA', '29', 'comedy', 2, 'tt6010920', '7.4', 'https://m.media-amazon.com/images/M/MV5BZmJiNDMzZDktNjliNC00ZmU4LWI4MDEtODRjOWZjNDhmM2U3XkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_SX300.jpg', '2017-00-00'),
(550, 'Nailed It!', 'Home bakers with a terrible track record take a crack at re- creating edible masterpieces for a $10,000 prize. It\'s part reality contest, part hot mess.', 'TV-PG', '33', 'reality', 7, 'tt6987788', '7.4', 'https://m.media-amazon.com/images/M/MV5BYzZkMzBlZDgtOTFjOS00MDM2LTlkYTctMGJiM2FkYzBmZDVhXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SX300.jpg', '2018-00-00'),
(554, 'Violet Evergarden', 'The Great War finally came to an end after four long years of conflict; fractured in two, the continent of Telesis slowly began to flourish once again. Caught up in the bloodshed was Violet Evergarden, a young girl raised for the sole purpose of decimating enemy lines. Hospitalized and maimed in a bloody skirmish during the War\'s final leg, she was left with only words from the person she held dearest, but with no understanding of their meaning.\n\nRecovering from her wounds, Violet starts a new life working at CH Postal Services after a falling out with her new intended guardian family. There, she witnesses by pure chance the work of an \"Auto Memory Doll,\" amanuenses that transcribe people\'s thoughts and feelings into words on paper. Moved by the notion, Violet begins work as an Auto Memory Doll, a trade that will take her on an adventure, one that will reshape the lives of her clients and hopefully lead to self-discovery.', 'TV-14', '25', 'animation', 1, 'tt7078180', '8.4', 'https://m.media-amazon.com/images/M/MV5BZmUzMThjOTItZGY4ZS00ODcwLTliNTMtYjVkM2JmY2QxNmRhXkEyXkFqcGdeQXVyMzgxODM4NjM@._V1_SX300.jpg', '2018-00-00'),
(558, 'Queer Eye', 'An all-new “Fab Five” advise men on fashion, grooming, food, culture and design in this modern reboot of the Emmy Award-winning reality series.', 'TV-14', '47', 'reality', 6, 'tt7259746', '8.5', 'https://m.media-amazon.com/images/M/MV5BMTdiYmYxYjItYjU2OS00NTU3LWJhYTAtYzIxYmNjOTkwMTE0XkEyXkFqcGdeQXVyMTUyNjc3NDQ4._V1_SX300.jpg', '2018-00-00'),
(562, 'Bumping Mics with Jeff Ross & Dave Attell', 'When Jeff Ross and Dave Attell take the stage, no one is safe. With the help of special guests, they\'re packing a lot of laughs into one epic weekend.', 'TV-MA', '36', 'comedy', 1, 'tt9203078', '7.7', 'https://m.media-amazon.com/images/M/MV5BY2JjZDNiODItNmVmNy00OTljLThkYWUtMGRkZjE2OTdkYWViXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(566, 'Suburra: Blood on Rome', 'In 2008, a fight over land in a seaside town near Rome spirals into a deadly battle between organized crime, corrupt politicians and the Vatican.', 'TV-MA', '48', 'drama', 3, 'tt7197684', '7.9', 'https://m.media-amazon.com/images/M/MV5BM2MwN2Y4ZWEtNTk2Mi00MzcwLTk1YWMtMmQzNGRlYjBkMDFmXkEyXkFqcGdeQXVyMTEyMjM2NDc2._V1_SX300.jpg', '2017-00-00'),
(570, 'The A List', 'Romance, rivalry and radical mystery collide as a group of teens attend a remote island sleepaway camp in this suspenseful, supernatural drama.', 'TV-PG', '26', 'drama', 2, 'tt9185110', '5.4', 'https://m.media-amazon.com/images/M/MV5BM2M5OGY5NTEtYmE2Ny00OWRlLWE3MmItYjJlZTgyZmI0YzA3XkEyXkFqcGdeQXVyMzQyMDgzOTU@._V1_SX300.jpg', '2018-00-00'),
(574, 'Ask the Doctor', 'An innovative, fun, and exploratory factual series that addresses the state of the nation\'s health, the latest in medical treatments and the future of healthcare as we know it.', '', '28', 'documentation', 3, 'tt7188736', '6.5', 'https://m.media-amazon.com/images/M/MV5BYTAyOWI5ZDMtNTQ2NC00MDc5LTg1M2MtZmQxOTc4Y2M4MWQwXkEyXkFqcGdeQXVyNTE4NTk4Njg@._V1_SX300.jpg', '2017-00-00'),
(578, 'The Who Was? Show', 'Fresh voices bring some of the most famous names in history to life. A live-action sketch comedy show based on the series of best-selling books.', 'TV-PG', '25', 'comedy', 1, 'tt7488702', '6.5', 'https://m.media-amazon.com/images/M/MV5BZDZmZDRiNDktZjc0NC00ZWI0LWIwZTUtMzdiZGY5NmYxNjE4XkEyXkFqcGdeQXVyODc1NzM4Nzc@._V1_SX300.jpg', '2018-00-00'),
(582, 'The Hook Up Plan', 'In a misguided attempt to build up perpetually single Elsa\'s confidence, her friends hire a male escort. A comedy series set in Paris.', 'TV-14', '27', 'comedy', 3, 'tt9170638', '7.1', 'https://m.media-amazon.com/images/M/MV5BZmM0MDhkZjctMmEyYS00NDFmLTliNGYtMjNkOWZjM2E3NjM1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(586, 'The Honeymoon Stand Up Special', 'Impending parenthood does funny things to Natasha Leggero and Moshe Kasher, who dissect family, relationships and more in a trio of stand-up specials.', '', '32', 'comedy', 1, 'tt7698408', '6.8', 'https://m.media-amazon.com/images/M/MV5BOTZkZjM0ZTktYmE1NC00YWVkLTg5NDYtMDQwNjYxZjYwOTkzXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(590, 'Woman of Dignity', 'Woo Ah-Jin lives a luxurious life due to her wealthy father-in-law, but her father-in-law\'s finances become decimated and her husband betrays her. Woo Ah-Jin\'s life hits rock bottom. Park Bok-Ja is a mysterious woman and she hides her heartbreaking story. She brings about fierce hardship on Woo Ah-Jin.', 'TV-MA', '61', 'drama', 1, 'tt6898288', '7.5', 'https://m.media-amazon.com/images/M/MV5BNmUxNjA5NDMtNmRjYy00NTVmLWIwMGYtMjFlM2FlZWRmOTY3XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2017-00-00'),
(594, 'Magic for Humans', 'From baffling people on the street to orchestrating elaborate tricks, Justin Willman blends good-natured magic with grown-up laughs.', 'TV-14', '23', 'reality', 3, 'tt8425308', '7.2', 'https://m.media-amazon.com/images/M/MV5BMzc4Y2JlYWEtMmE4MS00Yjk5LThjYjYtNDRiN2FlMTAwOWFmXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(598, 'Million Yen Women', 'Five beautiful but mysterious women move in with unsuccessful novelist Shin, who manages their odd household in exchange for a tidy monthly sum.', '', '30', 'drama', 1, 'tt6686450', '7.5', 'https://m.media-amazon.com/images/M/MV5BMzA5MWM5NWEtZjUyYy00MjU0LThhNGQtYzczZmU4MDFmZGM0XkEyXkFqcGdeQXVyMjIwNjIzOTY@._V1_SX300.jpg', '2017-00-00'),
(602, 'A Taiwanese Tale of Two Cities', 'A Taipei doctor and a San Francisco engineer swap homes in a daring pact, embarking on journeys filled with trials, secrets and unexpected encounters.', '', '69', 'drama', 2, 'tt8893498', '6.5', 'https://m.media-amazon.com/images/M/MV5BMGEyYzUzYzktNWVkNC00N2NiLWIyYzUtZGZjOWY0ZGNmMTAxXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(606, 'B: The Beginning', 'In a world powered by advanced technology, crime and action unfold in the archipelagic nation of Cremona. Genius investigator Keith Flick rejoins the royal police force just as serial killer “B” emerges. Mysterious youth Koku may be an ally, or a target.', 'TV-MA', '25', 'action', 2, 'tt7944664', '7.1', 'https://m.media-amazon.com/images/M/MV5BMzY2ZTcxODctOTk1OC00YTRkLWI5NDMtZGY3NGUxMzE1YzZjXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(610, 'Nightflyers', 'In the year 2093, a team of scientists aboard the Nightflyer, the most advanced ship ever built, embarks on a journey to find other life forms. Their mission takes them to the edge of the solar system, and to the edge of insanity, as they realize true horror isn\'t waiting for them in outer space—it\'s already on their ship.', '', '44', 'scifi', 1, 'tt6903284', '5.8', 'https://m.media-amazon.com/images/M/MV5BN2Y4NzIwZTUtYTMyMC00OGM1LWE1YjktYzhkZDBiM2UxMDc1XkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg', '2018-00-00'),
(614, 'Re:Mind', 'Eleven high school classmates awaken, restrained to a large dining room. While fearing for their lives, they question a motive to this bizarre act.', 'TV-MA', '23', 'drama', 1, 'tt7332652', '4.9', 'https://m.media-amazon.com/images/M/MV5BZWIxODRmZDctMDJkMS00Yzk5LTkzZjctMDgzZjIzZDI0ZWJhXkEyXkFqcGdeQXVyMzgxODM4NjM@._V1_SX300.jpg', '2017-00-00'),
(618, 'Daughters of Destiny', 'Five girls from India\'s most impoverished families attend a boarding school designed to create opportunities as they strive for a brighter future.', '', '65', 'documentation', 1, 'tt1877895', '8.6', 'https://m.media-amazon.com/images/M/MV5BYzBmNDg0MGUtZjBiYy00YmNhLThlNjgtN2Q3M2VmN2FhNDA0XkEyXkFqcGdeQXVyNzQzNjYwMDM@._V1_SX300.jpg', '2017-00-00'),
(622, 'Cloudy with a Chance of Meatballs', 'The series is a prequel, featuring the high school years of Flint Lockwood, the eccentric young scientist in the films. In his adventures, he will be joined by Sam Sparks, a new girl in town and the school\'s \"wannabe\" reporter, along with Flint\'s dad Tim, Steve the Monkey, Manny as the head of the school\'s audiovisual club, Earl as a school gym teacher, Brent as a baby wear model, and Mayor Shelbourne, who wins every election on the pro-sardine platform.', 'TV-Y7', '11', 'comedy', 2, 'tt4123482', '3.4', 'https://m.media-amazon.com/images/M/MV5BNzUwNzA1Y2EtZTcwZi00M2IyLWJiYTUtZmEwNjU1YWRlOTYwXkEyXkFqcGdeQXVyNjk1Njg5NTA@._V1_SX300.jpg', '2017-00-00'),
(626, 'Black Spot', 'In the small bordertown of Villefranche, lost in the heart of a large forest, crime rate is six times higher than elsewhere in the area. Each new crime Major Laurène Weiss solves with the help of her unusual team makes her sink deeper and deeper into secrets of the area.', 'TV-MA', '55', 'drama', 2, 'tt6519410', '7.4', 'https://m.media-amazon.com/images/M/MV5BOTI3Y2VlNjItNzIxMy00OTI4LTkxMWItYzFiY2Q3ODBiOWU2XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2017-00-00'),
(630, 'Prince of Peoria', 'A prankster prince who wants to experience life as an ordinary teen leaves his kingdom to live incognito with a single mom and her studious son.', 'TV-Y7', '26', 'comedy', 2, 'tt8001718', '6.1', 'https://m.media-amazon.com/images/M/MV5BOGIwODUzZjYtZGVlOS00ZmRjLWE4ODUtYWJmYjI0OTAzNDYzXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(634, 'The Fix', 'Comedians Jimmy Carr, D.L. Hughley and Katherine Ryan tackle the world\'s woes with help from a rotating crew of funny guests and an actual expert.', 'TV-MA', '27', 'comedy', 1, 'tt5960546', '7', 'https://m.media-amazon.com/images/M/MV5BYTNhMjQ4ZmMtZjAwOC00NmZmLWFhNTQtMThjZWFkNjAzMGRjXkEyXkFqcGdeQXVyNzg1NDY3OTE@._V1_SX300.jpg', '2018-00-00'),
(638, 'Unauthorized Living', 'When a Galician shipper and drug lord hiding his Alzheimer\'s disease plans to retire, his second-in-command plots to steal the empire from the heir.', 'TV-MA', '75', 'drama', 2, 'tt6970700', '7.4', 'https://m.media-amazon.com/images/M/MV5BODViZTFhNjgtNmQ0Mi00NTExLWJkMDgtYjhmZTUyMGI1OGEwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(642, 'The Confession Tapes', 'This true crime documentary series investigates cases where people convicted of murder claim their confessions were coerced, involuntary or false.', 'TV-MA', '45', 'documentation', 2, 'tt7349602', '7.5', 'https://m.media-amazon.com/images/M/MV5BM2U4NzMxODItMDM0ZC00MzExLWI4ODktZjNjNDIzOTYyMTE2XkEyXkFqcGdeQXVyMjQzNzk2ODk@._V1_SX300.jpg', '2017-00-00'),
(650, 'Prison Playbook', 'Kim Je Hyuk, a famous baseball player, is arrested after using excessive force while chasing a man trying to sexually assault his sister. Shockingly to him and the rest of the nation, he is sentenced to a year in prison. There, he meets his childhood friend and fellow baseball player, Lee Joon Ho, who gave up on baseball after a car accident, but now is a prison guard and one of Je Hyuk\'s biggest fans. The drama revolves around Je Hyuk\'s time in prison, as well as prisoners he meets and events that take place there.', 'TV-MA', '91', 'drama', 1, 'tt7622902', '8.4', 'https://m.media-amazon.com/images/M/MV5BMTQzMzYwNzEtY2U1Zi00MTA1LWJhZTctZjE2NjMzYjlmNmQwXkEyXkFqcGdeQXVyMzE4MDkyNTA@._V1_SX300.jpg', '2017-00-00'),
(654, 'Fastest Car', 'The drivers of exotic supercars put their street cred on the line against deceptively fast sleeper cars built and modified by true gearheads.', 'TV-MA', '44', 'reality', 2, 'tt8295694', '7.1', 'https://m.media-amazon.com/images/M/MV5BYmFkM2M1ZDItOGVkNy00ODU1LWEzODUtMWNiMGNkN2JlMzI2XkEyXkFqcGdeQXVyMjQxNzY5NTc@._V1_SX300.jpg', '2018-00-00'),
(658, 'Jimmy: The True Story of a True Idiot', 'In the 1980s, a simple-minded fool named Hideaki meets comedy legend Sanma, changes his name to Jimmy and becomes a comedic superstar.', 'TV-MA', '46', 'drama', 1, 'tt6866914', '6.7', 'https://m.media-amazon.com/images/M/MV5BNTkyNTNmMGQtODU5My00YTU0LWE4ZjAtZWNhYjE0NmVlNDM2XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(662, 'Dogs of Berlin', 'A politically sensitive murder forces two disparate detectives into a battle with the Berlin underworld and a confrontation with their own corruption.', 'TV-MA', '60', 'drama', 1, 'tt6839788', '7.5', 'https://m.media-amazon.com/images/M/MV5BMTY4MTczNzkyOF5BMl5BanBnXkFtZTgwNTUxMzQ4NjM@._V1_SX300.jpg', '2018-00-00'),
(666, 'Superwog', 'Follow Superwog and best friend Johnny as their misadventures cause Superwog\'s primitive, highly-strung father stress as he battles to keep his delusional, but loyal wife happy.', 'TV-MA', '22', 'comedy', 2, 'tt7786486', '7.4', 'https://m.media-amazon.com/images/M/MV5BNmE5MDM1ZmEtZWEwNC00NThmLWEwOWMtNTFiNThmY2FkNzA5XkEyXkFqcGdeQXVyMTMxNzA4NDkx._V1_SX300.jpg', '2018-00-00'),
(670, 'Cleo & Cuquin', 'Sister and brother Cleo and Cuquin carry out different job roles to help their friends.', 'TV-Y', '6', 'animation', 2, 'tt7956374', '8.1', 'https://m.media-amazon.com/images/M/MV5BZDllMjdkNzctMzMzNS00ZmRkLTkzNzItNTJhYzM1MmM5YmQ3XkEyXkFqcGdeQXVyMjgzNjA3Mw@@._V1_SX300.jpg', '2018-00-00'),
(674, 'Watership Down', 'Fleeing their doomed warren, a group of rabbits struggle to find and defend a new home.', 'TV-PG', '50', 'animation', 1, 'tt5670764', '7.2', 'https://m.media-amazon.com/images/M/MV5BOTk4YmJmZjQtNmZmZi00ZmRkLWIyMTgtNGNhZmM4NGY3MTJkXkEyXkFqcGdeQXVyMjExNjgyMTc@._V1_SX300.jpg', '2018-00-00'),
(678, 'The Magic School Bus Rides Again', 'Ms. Frizzle\'s sister takes her class on a slew of wild science adventures in this update of the beloved animated show.', 'TV-Y', '25', 'animation', 3, 'tt3869122', '6.3', 'https://m.media-amazon.com/images/M/MV5BMTY0MjA5Mjc4Ml5BMl5BanBnXkFtZTgwNDE2NDMzNTM@._V1_SX300.jpg', '2017-00-00'),
(682, 'Titipo Titipo', 'Titipo the train is out to prove that he\'s got what it takes to help the folks of Train Village ride the rails safely and reliably.', 'TV-Y', '18', 'comedy', 2, 'tt12987396', '7.2', 'https://m.media-amazon.com/images/M/MV5BMGE5MDZiNGItMDZmZC00MWU0LWIzM2EtOTI3OTkzMjBkZWIyXkEyXkFqcGdeQXVyNDI5Njk2Mzc@._V1_SX300.jpg', '2018-00-00'),
(686, 'The House of Flowers', 'The outward perfection of a family-run flower business hides a dark side rife with dysfunctional secrets in this darkly humorous comedy series.', 'TV-MA', '31', 'drama', 3, 'tt8387348', '7.6', 'https://m.media-amazon.com/images/M/MV5BMjI0Njk0NDM2NF5BMl5BanBnXkFtZTgwNDY4ODA3NTM@._V1_SX300.jpg', '2018-00-00'),
(690, 'Somewhere Between', 'Laura Price, a local news producer in San Francisco, is helping the police to hunt down a serial killer. After the killer strikes close to home, a twist of fate allows a “Groundhog Day”-type reset, and Laura relives the week prior to the string of murders. Can she change fate and stop the killer?', 'TV-14', '42', 'drama', 1, 'tt6467294', '6.2', 'https://m.media-amazon.com/images/M/MV5BMjMyNjk5NTg2N15BMl5BanBnXkFtZTgwNjIzNDQ3MjI@._V1_SX300.jpg', '2017-00-00'),
(694, 'A.I.C.O. -Incarnation-', 'In Japan in the year 2035, an accident known as the \"Burst\" occurs during a research project, spawning an out-of-control artificial life form called \"Matter\" that has spread throughout the Kurobe Gorge. The research city that was once hailed as the hope for humanity is cordoned off by the government. Two years later, 15-year-old Aiko Tachibana, who lost her family in the Burst, learns something unbelievable from Yuya Kanzaki, a new student at her school. A secret is hidden within her body, and the answer to the puzzle lies at the \"Primary Point\" that was the center of the Burst. Aiko resolves to infiltrate the restricted area, escorted by a team of divers and with Yuya as her guide. When boy meets girl with the fate of humanity in their hands, what new truth will come to light?', 'TV-14', '25', 'action', 1, 'tt8116380', '6.3', 'https://m.media-amazon.com/images/M/MV5BNzY5NzdlYTktODFjNi00ZDZkLWEyMjUtYzkwNTA2NTY1N2RhXkEyXkFqcGdeQXVyMjg1NDcxNDE@._V1_SX300.jpg', '2018-00-00'),
(698, 'Requiem', 'In 1994, a toddler disappeared from a small Welsh village, never to be seen again. 23 years later, in London, the mother of rising cello star Matilda Gray commits suicide, without apparent reason. Among her possessions, Matilda discovers tantalising evidence, linking her mother to the Welsh girl\'s disappearance all those years ago.', 'TV-MA', '58', 'drama', 1, 'tt6712390', '6.4', 'https://m.media-amazon.com/images/M/MV5BMzQyOTA0NWEtZmNiNC00YjdkLThlZmQtMmJlY2E3NjYyZjc0XkEyXkFqcGdeQXVyNzQ2NTg4NzI@._V1_SX300.jpg', '2018-00-00'),
(702, 'SKY Castle', 'The drama revolves around the lives of housewives living in a luxurious residential area called SKY Castle in suburban Seoul, where wealthy doctors and professors live. The wives are determined to make their husbands more successful and to raise their children like princes and princesses and to be top students.', 'TV-MA', '68', 'drama', 1, 'tt9151274', '8.6', 'https://m.media-amazon.com/images/M/MV5BNTQ1YmFmYmEtZjEwZi00NTI1LWJmMzYtY2NiN2YxMDM5NjJmXkEyXkFqcGdeQXVyMzE4MDkyNTA@._V1_SX300.jpg', '2018-00-00'),
(706, 'Hot Girls Wanted: Turned On', 'Porn has gone mainstream; the question is, can we handle it? This exploration of the intersection of sex and technology is told through the stories of the people whose lives are defined by the current explosion of internet porn-whether they\'re creating it, consuming it, or both.', 'TV-MA', '47', 'documentation', 1, 'tt6333104', '6.6', 'https://m.media-amazon.com/images/M/MV5BMjM5NDI3ODMxM15BMl5BanBnXkFtZTgwNTIwOTcwMjI@._V1_SX300.jpg', '2017-00-00'),
(710, 'Gypsy', 'The journey of Jean Holloway – a therapist who begins to develop dangerous and intimate relationships with the people in her patients\' lives.', 'TV-MA', '52', 'drama', 1, 'tt5503718', '6.8', 'https://m.media-amazon.com/images/M/MV5BMTEzMTA1MTMyMjReQTJeQWpwZ15BbWU4MDY3MzUyMzIy._V1_SX300.jpg', '2017-00-00'),
(714, 'Treehouse Detectives', 'When their animal friends need help, brother-and-sister team Toby and Teri use the clues and follow the facts to solve mysteries in their own backyard.', 'TV-Y7', '24', 'animation', 3, 'tt8591984', '7.9', 'https://m.media-amazon.com/images/M/MV5BZmE4Mjk2ZTYtOTc1Mi00YjM4LTkxODktZDU1MmQyMGM5M2QxXkEyXkFqcGdeQXVyNjM2NzI4MDc@._V1_SX300.jpg', '2018-00-00'),
(718, 'Perfume', 'When a singer is found murdered, with her scent glands excised from her body, detectives probe a group of friends who attended boarding school with her.', 'TV-MA', '58', 'crime', 1, 'tt6811236', '7.1', 'https://m.media-amazon.com/images/M/MV5BNDI2YzFhNzgtNzM1Mi00NmY2LTgxZDUtMmFkYzY3Nzg3ZjlmXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(722, 'The Worst Witch', 'Join Mildred Hubble in CBBC\'s adaptation of The Worst Witch books, written by Jill Murphy.', 'TV-Y7', '28', 'scifi', 4, 'tt5721172', '7.2', 'https://m.media-amazon.com/images/M/MV5BY2ZmMzIxMDktOGUwZS00ZTY0LTg1NjEtNzNkZjFlZjVkZGMwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2017-00-00'),
(726, 'Barbie: Dreamhouse Adventures', 'Barbie, her sisters, friends and neighbour Ken share vlogs filmed in her Dreamhouse.', 'TV-Y', '22', 'family', 5, 'tt7661472', '6.7', 'https://m.media-amazon.com/images/M/MV5BMzMyNDVjMzQtODI0Yy00YWE0LWJkMTgtYzI4MDJkYjhiMTRmXkEyXkFqcGdeQXVyNzQyNTU2MjI@._V1_SX300.jpg', '2018-00-00'),
(730, 'Because This Is My First Life', 'Nam Se-Hee is a single man in his early 30s. He has chosen to not marry. He owns his home, but he owes a lot on his mortgage. Yoon Ji-Ho is a single woman in her early 30s. She does not own a home and envies those that do. She has given up on dating due to her financial struggles. Yoon Ji-Ho begins to live at Nam Se-Hee’s house. They become housemates.', 'TV-14', '68', 'drama', 1, 'tt7278588', '8.1', 'https://m.media-amazon.com/images/M/MV5BNzIzNjRiMjEtNDg0Ny00NmUxLThkNDctMDYyOTU2ZjBhYTIyXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2017-00-00'),
(734, 'Afflicted', 'Baffling symptoms. Controversial diagnoses. Costly treatments. Seven people with chronic illnesses search for answers -- and relief.', 'TV-MA', '42', 'reality', 1, 'tt8792570', '5.2', 'https://m.media-amazon.com/images/M/MV5BNjEzYWI5ODgtYjZhNS00NzJiLWI1NjEtNTIxMGQ3Zjg1Y2M1XkEyXkFqcGdeQXVyMzU3MTc5OTE@._V1_SX300.jpg', '2018-00-00'),
(738, 'Sirius the Jaeger', 'Imperial Capital, 1930. A strange group of people carrying musical instrument cases landed on Tokyo station. They are called the \"Jaegers\", who came to hunt vampires. Amongst them, there stood a young man with striking serenity and unusual aura. His name is Yuliy, a werewolf whose home village was destroyed by vampires. Yuliy and the Jaegers engage in deadly battle over a mysterious holy arc only known as \"The Arc of Sirius\". What truth awaits them at the end...?', 'TV-MA', '25', 'action', 1, 'tt8565136', '6.8', 'https://m.media-amazon.com/images/M/MV5BZjg3NmNjYTUtNGQ4Ny00MTA3LWJmOTctY2MzNzE2NTdhYzYwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(742, 'Sick Note', 'When Daniel Glass is misdiagnosed with a fatal disease he begins to notice how everyone around him treats him better. But then he finds out he was misdiagnosed by the most incompetent oncologist on Earth and now he has a big decision to make: come clean and go back to his old rubbish life, or keep pretending to be ill.', 'TV-MA', '24', 'crime', 2, 'tt5770788', '6.8', 'https://m.media-amazon.com/images/M/MV5BOWRiOTQ3MGEtYWVlZC00MzE4LWJhZGUtZDgyZDk5N2FjMDE5XkEyXkFqcGdeQXVyMzQxMTMwMDQ@._V1_SX300.jpg', '2017-00-00'),
(746, 'The Joel McHale Show with Joel McHale', 'Trending news, pop culture, social media, original videos and more come together in host Joel McHale\'s weekly comedy commentary show.', 'TV-MA', '28', 'comedy', 2, 'tt7895706', '7.2', 'https://m.media-amazon.com/images/M/MV5BYTBkMjcyY2EtOGFjNS00MDllLTk3MTktNzExNGY1NWRmZGU2XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(750, 'Sisters', 'Sisters follows the story of three women who discover that they are sisters. Julia finds out that her Nobel prize winning father secretly used his own sperm in a number of \"In Vitro Fertilisation\" procedures.', 'TV-14', '29', 'drama', 1, 'tt6258050', '7.4', 'https://m.media-amazon.com/images/M/MV5BMjI4NzQ3MDU3M15BMl5BanBnXkFtZTgwMDI3MjcwNDI@._V1_SX300.jpg', '2017-00-00'),
(754, 'Surviving Escobar - Alias JJ', 'As the Medellín Cartel crumbles, Pablo Escobar\'s No. 1 hit man struggles to stay alive and gain respect in the prison hierarchy.', 'TV-MA', '45', 'drama', 1, 'tt6809396', '7.8', 'https://m.media-amazon.com/images/M/MV5BNWQ3MzkwZDAtODg5MS00ODY1LWI0N2YtZGE3Nzk2NTM2YzQ4XkEyXkFqcGdeQXVyMzM0NTc2MTE@._V1_SX300.jpg', '2017-00-00'),
(758, 'Polly Pocket', 'The series, based on the doll of the same name, will feature a young girl called Polly who has a magical locket that allows her and her friends to shrink down to a tiny size.', '', '14', 'animation', 4, 'tt13210196', '6.1', 'https://m.media-amazon.com/images/M/MV5BOGZiYmJhZDAtYzM2Yi00ZjIxLTk0MTAtNjE3MDQyZTRjODRjXkEyXkFqcGdeQXVyMTU1MTc2MzU0._V1_SX300.jpg', '2018-00-00'),
(762, 'The Innocents', 'When a teenage couple runs away to be together, the extraordinary gift they possess unleashes powerful forces intent on dividing them forever.', 'TV-MA', '46', 'scifi', 2, 'tt8021824', '6.2', 'https://m.media-amazon.com/images/M/MV5BMjEwNjM1MzE0N15BMl5BanBnXkFtZTgwMzU1MjgwNjM@._V1_SX300.jpg', '2018-00-00'),
(766, 'The Velvet Collection', 'It is the year 1967. After five happy years of marriage in New York with Alberto and their young son, Anna Ribera returns to Spain to take her project Velvet to the next level. She and Alberto had been managing all things Velvet from across the ocean and, together with their best friends and partners, had made a name for Velvet as the number one address in the world of fashion and innovation. Now they decide to take the next step and turn their reputation into a franchise, first at home, then abroad. The first step is opening shop in the other great Spanish city, Barcelona, on its world famous promenade, the Passeig de Gracia. There, the second Velvet Fashion Store is about to open its gates, managed by Ana\'s good friend Clara who had made it up the career ladder from seamstress to directorial assistant in the Madrid Velvet years.', 'TV-14', '57', 'drama', 3, 'tt6762348', '7.2', 'https://m.media-amazon.com/images/M/MV5BMTBlZDAxNmQtOGE5My00Nzg0LWFhMjgtMjlmY2NmNTUwMGQ3XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2017-00-00'),
(770, 'First Team: Juventus', 'Follow renowned soccer club Juventus on and off the pitch as they attempt to win a seventh straight Italian title and achieve Champions League glory.', 'TV-G', '36', 'scifi', 2, 'tt7924812', '7.2', 'https://m.media-amazon.com/images/M/MV5BMWUyYWEzNjYtOTRiYS00ZDg0LThjYWYtYTFjOTc0ODExYjQ3XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(774, 'November 13: Attack on Paris', 'Survivors and first responders share personal stories of anguish, kindness and bravery that unfolded amid the Paris terror attacks of Nov. 13, 2015.', 'TV-MA', '54', 'documentation', 1, 'tt8194716', '8.3', 'https://m.media-amazon.com/images/M/MV5BOGMxYjQ5YzYtNzA3YS00MGQzLWIyNDEtODdhMTA0MjlhOWM5XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg', '2018-00-00'),
(778, 'Kiss Me First', 'To escape reality 17-year-old Leila turns to a secret virtual paradise. Her real journey begins when this digital Eden turns dark.', 'TV-MA', '47', 'scifi', 1, 'tt5730690', '6.2', 'https://m.media-amazon.com/images/M/MV5BMTUzMDgzNzMzNl5BMl5BanBnXkFtZTgwMTU5MDI3NTM@._V1_SX300.jpg', '2018-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `single_account`
--

CREATE TABLE `single_account` (
  `user_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `single_account`
--

INSERT INTO `single_account` (`user_id`, `name`, `surname`) VALUES
(1, 'Herrie', 'Engelbrecht'),
(6, 'johny', 'heat'),
(15, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_series` (`movie_id`),
  ADD KEY `fk_newseries` (`series_id`);

--
-- Indexes for table `family`
--
ALTER TABLE `family`
  ADD KEY `fk_fam` (`user_id`);

--
-- Indexes for table `family_members`
--
ALTER TABLE `family_members`
  ADD KEY `fk_member` (`family_id`);

--
-- Indexes for table `favourites`
--
ALTER TABLE `favourites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fav_content` (`content_id`),
  ADD KEY `fav_user` (`user_id`);

--
-- Indexes for table `head`
--
ALTER TABLE `head`
  ADD KEY `fk_head` (`family_id`);

--
-- Indexes for table `loginInfo`
--
ALTER TABLE `loginInfo`
  ADD KEY `fk_user` (`user_id`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `single_account`
--
ALTER TABLE `single_account`
  ADD KEY `fk_singeluser` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=770;

--
-- AUTO_INCREMENT for table `favourites`
--
ALTER TABLE `favourites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3833;

--
-- AUTO_INCREMENT for table `series`
--
ALTER TABLE `series`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2307;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `content`
--
ALTER TABLE `content`
  ADD CONSTRAINT `fk_content` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_newseries` FOREIGN KEY (`series_id`) REFERENCES `series` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `family`
--
ALTER TABLE `family`
  ADD CONSTRAINT `fk_fam` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `family_members`
--
ALTER TABLE `family_members`
  ADD CONSTRAINT `fk_member` FOREIGN KEY (`family_id`) REFERENCES `family` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `favourites`
--
ALTER TABLE `favourites`
  ADD CONSTRAINT `fav_content` FOREIGN KEY (`content_id`) REFERENCES `content` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fav_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `head`
--
ALTER TABLE `head`
  ADD CONSTRAINT `fk_head` FOREIGN KEY (`family_id`) REFERENCES `family` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `loginInfo`
--
ALTER TABLE `loginInfo`
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `single_account`
--
ALTER TABLE `single_account`
  ADD CONSTRAINT `fk_singeluser` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
