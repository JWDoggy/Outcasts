<?php
/*session_start();
$_SESSION['user_id'] = 14;*/ // The session should be started upon login, so this is not needed
$conn = include 'connect.php';
if ($conn === null) {
    die("Connection failed. Check the response message.");
}

function getFamilyMembers($conn) {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $sql = "SELECT fm.name, fm.surname
                FROM family_members fm
                JOIN family f ON fm.family_id = f.user_id
                WHERE f.user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($result) {
                $familyMembers = [];
                while ($row = mysqli_fetch_assoc($result)) {
                    $familyMembers[] = [
                        'name' => $row['name'],
                        'surname' => $row['surname']
                    ];
                }

                mysqli_free_result($result);
                mysqli_stmt_close($stmt);
                return $familyMembers;
            } else {
                echo "Error: " . mysqli_error($conn);
                mysqli_stmt_close($stmt);
                return [];
            }
        } else {
            echo "Error: " . mysqli_error($conn);
            return [];
        }
    }
    return [];
}

function getUserData($conn)
{
    if (!isset($_SESSION['user_id'])) {
        return []; 
    }
    
    $user_id = $_SESSION['user_id'];

    $emailQuery = "SELECT email FROM loginInfo WHERE user_id = ?";
    $emailStmt = mysqli_prepare($conn, $emailQuery);

    if (!$emailStmt) {
        echo "Error: " . mysqli_error($conn);
        return [];
    }
    
    mysqli_stmt_bind_param($emailStmt, "i", $user_id);
    mysqli_stmt_execute($emailStmt);
    $emailResult = mysqli_stmt_get_result($emailStmt);
    if (!$emailResult) {
        echo "Error: " . mysqli_error($conn);
        mysqli_stmt_close($emailStmt);
        return [];
    }
    $userData = [];
    if ($row = mysqli_fetch_assoc($emailResult)) {
        $userData['email'] = $row['email'];
    }
    mysqli_free_result($emailResult);
    mysqli_stmt_close($emailStmt);
    $contentQuery = "SELECT 
                        CASE 
                            WHEN c.movie_id IS NOT NULL THEN m.title 
                            ELSE s.title 
                        END AS title
                    FROM content c
                    LEFT JOIN movies m ON c.movie_id = m.id
                    LEFT JOIN series s ON c.series_id = s.id
                    WHERE EXISTS (
                        SELECT 1 FROM favourites f 
                        WHERE f.content_id = c.id 
                        AND f.user_id = ?
                    )";
    $contentStmt = mysqli_prepare($conn, $contentQuery);
    if (!$contentStmt) {
        echo "Error: " . mysqli_error($conn);
        return [];
    }
    mysqli_stmt_bind_param($contentStmt, "i", $user_id);
    mysqli_stmt_execute($contentStmt);
    $contentResult = mysqli_stmt_get_result($contentStmt);
    if (!$contentResult) {
        echo "Error: " . mysqli_error($conn);
        mysqli_stmt_close($contentStmt);
        return [];
    }
    while ($row = mysqli_fetch_assoc($contentResult)) {
        $userData['favorites'][] = $row['title']; 
    }

    mysqli_free_result($contentResult);
    mysqli_stmt_close($contentStmt);

    return $userData;
}



$familyMembers = getFamilyMembers($conn);
$userData = getUserData($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Family Panel</title>
    <script>
        function populateFamilyMemberPanel(familyMembers) {
            var familyPanel = document.getElementById("familyPanel");
            familyPanel.innerHTML = "";
            if (familyMembers.length === 0) {
                familyPanel.innerHTML = "No family members found.";
                return;
            }
            familyMembers.forEach(function(member) 
            {
                var memberDiv = document.createElement("div");
                memberDiv.classList.add("family-member");
                
                var memberInfo = document.createElement("p");
                memberInfo.textContent = member.name + " " + member.surname;
                
                memberDiv.appendChild(memberInfo);
                familyPanel.appendChild(memberDiv);
            });
        }

        function populateUserPanel(userData) 
        {
            var userPanel = document.getElementById("userPanel");
            userPanel.innerHTML = "";

            var emailDiv = document.createElement("div");
            emailDiv.classList.add("user-email");
            
            var emailInfo = document.createElement("p");
            emailInfo.textContent = "Email: " + userData.email;
            
            emailDiv.appendChild(emailInfo);
            userPanel.appendChild(emailDiv);

            var favoritesDiv = document.createElement("div");
            favoritesDiv.classList.add("user-favorites");

            var favoritesTitle = document.createElement("h3");
            favoritesTitle.textContent = "Favorite Titles:";
            favoritesDiv.appendChild(favoritesTitle);

            if (userData.favorites.length === 0) 
            {
                var noFavorites = document.createElement("p");
                noFavorites.textContent = "No favorites";
                favoritesDiv.appendChild(noFavorites);
            } 
            else 
            {
                var favoritesList = document.createElement("ul");
                userData.favorites.forEach(function(title) {
                    var listItem = document.createElement("li");
                    listItem.textContent = title;
                    favoritesList.appendChild(listItem);
                });
                favoritesDiv.appendChild(favoritesList);
            }

            userPanel.appendChild(favoritesDiv);
        }

        window.onload = function() {
            var familyMembers = <?php echo json_encode($familyMembers); ?>;
            var userData = <?php echo json_encode($userData); ?>;
            populateFamilyMemberPanel(familyMembers);
            populateUserPanel(userData);
        };
    </script>
</head>
<body>
    <div id="userPanel">
        <!-- User panel -->
    </div>

    <div id="familyPanel">
        <!-- Family member panel -->
    </div>
    <button onclick="addtofam()">Add a new member to the family</button> 
    <script>
        function addtofam(){
            window.location.href = "addToFam.php";
        }
    </script>
</body>
</html>
