<!DOCTYPE html>
<html>
<head>
    <title>Add to family</title>
</head>
<body>
<form method="post" action="createFamMem.php">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name" required><br>

    <label for="surname">Surname:</label><br>
    <input type="text" id="surname" name="surname" required><br>

    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email" required><br>

    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password" required><br>

    <input type="submit" value="Submit">
</form>
</body>
</html>
