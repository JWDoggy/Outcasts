<?php
session_start(); 

// Function to authenticate user
function authenticate($username, $password) {
    // Perform your authentication logic here
    // For example, check if username and password are valid
    // Replace this logic with your actual authentication mechanism
    return ($username === 'u22512374' && $password === 'Eirreh732');
}

// Check if the user has provided credentials
if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
    // Prompt for authentication
    header('WWW-Authenticate: Basic realm="Authentication required"');
    http_response_code(401);
    echo 'Unauthorized';
    exit;
}

// Attempt authentication
$username = $_SERVER['PHP_AUTH_USER'];
$password = $_SERVER['PHP_AUTH_PW'];
if (!authenticate($username, $password)) {
    // Authentication failed
    header('WWW-Authenticate: Basic realm="Authentication required"');
    http_response_code(401);
    echo 'Unauthorized';
    exit;
}

// Authentication successful, proceed with session data retrieval
if(isset($_SESSION['apikey'])) {
    $userData  = [
        "apikey" => $_SESSION['apikey'],
        'name'=> $_SESSION['name'],
        "id" => $_SESSION["id"],
        "theme"=> $_SESSION["theme"]
    ] ;
    
    header('Content-Type: application/json');
    echo json_encode($userData);
} else {
    header('Content-Type: application/json');
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized", "message" => "Session data not available"]);
}
?>
