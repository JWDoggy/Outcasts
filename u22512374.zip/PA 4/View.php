<!-- u22512374 Herman Engelbrecht-->
<?php
include('header.php');
if(isset($_SESSION['theme'])){
  $cssFile = $_SESSION['theme'];
  if($_SESSION['theme'] ==='light'){
    $cssFile = 'css/ViewStyleLight.css';
  } else {
    $cssFile = 'css/ViewStyle.css';
  }
} else {
  $cssFile = 'css/ViewStyle.css';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Page</title>
  <link rel="stylesheet" href="<?php echo $cssFile; ?>">
  <script src="View.js" defer></script>
</head>
<body>

  <img src="img/Loading/icegif-1260.gif" alt="gif" id="loading">

  <div id="BigContainer">
    <section class="slideshow">
      <span id="item_1">
      </span>
      <span id="itemLeft">
      </span>
      <span id="itemRight">
      </span>
      <span id="farLeft">
      </span>
      <span id="farRight">
      </span>
    </section>
  
    <div class="Buttons">
      <span class="button">
        <button type="button" id="btnLeft">
          <i class="arrow left"></i>
        </button>
      </span>
      <span class="button">
        <button type="button" id="btnRight">
          <i class="arrow right"></i>
        </button>
      </span>
    </div>
  
    <div class="Details">
      <span id="charactersitics">
      </span>
      <span id="description">
      </span>
    </div>
  </div>
  
</body>
</html>

<?php
  include('footer.php');
?>