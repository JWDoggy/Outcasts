<footer>
  <div id="FooterContainer">
    <div id="FooterTitle">
      <h3>High End Homes</h3>
    </div>
    <div id="FooterInfo">
      <h5> About Us</h5>
      <p>
        Here at High End Homes we are all about finding the perfect home, apartment and living area for our clients. <br>
        We pride ourselves on our working ethics and consistency is doing just the best work. <br>
        Look no further for another property agency and your dream home.
      </p>
      <ul>
        <li>Contact Information: 011 459 3211</li>
        <li>Copyritght 2024 High End Homes</li>
      </ul>

      <?php if(isset($_SESSION['apikey'])): ?>
    <div id="ThemeSelection">
      <h5>Theme Selection</h5>
      <label><input type="radio" name="theme" value="light"<?php if(isset($_SESSION['theme']) && $_SESSION['theme'] === 'light') echo ' checked'; ?> > Light</label>
      <label><input type="radio" name="theme" value="dark" <?php if(!isset($_SESSION['theme']) || $_SESSION['theme'] === 'dark') echo ' checked'; ?>> Dark</label>
    </div>
    <?php endif; ?>

  </div>
</footer>