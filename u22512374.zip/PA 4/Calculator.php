<!-- u22512374 Herman Engelbrecht-->
<?php
include('header.php');
if(isset($_SESSION['theme'])){
  $cssFile = $_SESSION['theme'];
  if($_SESSION['theme'] ==='light'){
    $cssFile = 'css/CalculatorLight.css';
  } else {
    $cssFile = 'css/Calculator.css';
  }
} else {
  $cssFile = 'css/Calculator.css';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Calculator</title>
  <link rel="stylesheet" href="<?php echo $cssFile; ?>">
  <script src="Calculator.js" defer></script>
</head>
<body>
  
  <section class="Agents">
    <div class="container">

      <span class="box">
        <span class="Input">
          <form id="Mortage">
            <fieldset>
              <legend>Mortage</legend>
    
              <label for="HomePrice">Home Price (R):</label><br>
              <input type="number" id="HomePrice" name="HomePrice"><br>
    
              <label for="Deposit"> Deposit (R):</label><br>
              <input type="number" id="Deposit" name="Deposit"><br>
    
              <label for="InterestRate">Interest Rate (%):</label><br>
              <input type="number" id="InterestRate" name="InterestRate" value="11.75" disabled><br>
    
              <label for="LoanTerm">Loan Term (years)</label><br>
              <input type="number" name="LoanTerm" id="LoanTerm">

              <input type="submit" value="Submit">
            </fieldset>
          </form>
        </span>
        <span id="OutputMortage">
          <h3>Mortage summary:</h3>
          <ul></ul>
        </span>
      </span>

    </div>

    <div class="container">
      <span class="box">
        <span class="Input">
          <form id="PriceRent">
            <fieldset>
              <legend>Qualification Ratio</legend>
    
              <label for="Income">Enter your monthly salary:</label><br>
              <input type="number" id="Income" name="HomePrice"><br>

              <input type="submit" value="Submit">
            </fieldset>
          </form>
        </span>
        <span id="OutputPricetoRent">
          <p></p>
        </span>
      </span>
    </div>

  </section>
</body>
</html>

<?php
  include('footer.php');
?>