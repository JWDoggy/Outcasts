<!-- u22512374 Herman Engelbrecht-->
<?php
include('header.php');
if(isset($_SESSION['theme'])){
  $cssFile = $_SESSION['theme'];
  if($_SESSION['theme'] ==='light'){
    $cssFile = 'css/style2light.css';
  } else {
    $cssFile = 'css/style2.css';
  }
} else {
  $cssFile = 'css/style2.css';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agents</title>
  <link rel="stylesheet" href="<?php echo $cssFile; ?>">
  <script src="Agents.js"></script>
</head>
<body>

  <section class="Heading">
    <h1>Real Estate Agents:</h1>
  </section>
  <img src="img/Loading/icegif-1260.gif" alt="gif" id="loading">
  <section id="Agents">

  </section>
  
</body>
</html>

<?php
  include('footer.php');
?>