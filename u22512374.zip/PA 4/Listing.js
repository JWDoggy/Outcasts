document.addEventListener("DOMContentLoaded", function() {
    // Get the radio buttons for theme selection
    var lightRadio = document.querySelector('input[value="light"]');
    var darkRadio = document.querySelector('input[value="dark"]');
  
    // Listen for click event on the radio buttons
    lightRadio.addEventListener('click', function(event) {
        event.preventDefault();
      // Set the theme to light when the light radio button is clicked
        //   document.documentElement.setAttribute('data-theme', 'light');
        console.log("Light clicked");
        // send request to api to change the theme in the database 
        fetch('getSessionData.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
        
            // type "changeTheme", theme "newTheme"
            var Obj = {}
            Obj['type'] = "ChangeTheme";
            Obj['NewTheme'] = "light";
            Obj['apikey'] = data.apikey;
            var jsonObj = JSON.stringify(Obj);

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if(xhr.readyState === XMLHttpRequest.DONE) {
                            
                    //console.log(responseData);
                      if(xhr.status === 200) {
                        // update was successfull

                        console.log("Update was successfull");
                      } else {
                        console.log("Update was not successfull");
                      }
                }
            };
          
            xhr.open('POST', '../../api.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(jsonObj);

            this.checked = true;
        location.reload();
            })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
    });
  
    darkRadio.addEventListener('click', function(event) {
        event.preventDefault();
      // Set the theme to dark when the dark radio button is clicked
      console.log("Dark clicked");
    //   document.documentElement.setAttribute('data-theme', 'dark');
    fetch('getSessionData.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
        
            // type "changeTheme", theme "newTheme"
            var Obj = {}
            Obj['type'] = "ChangeTheme";
            Obj['NewTheme'] = "dark";
            Obj['apikey'] = data.apikey;
            var jsonObj = JSON.stringify(Obj);

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if(xhr.readyState === XMLHttpRequest.DONE) {
                            
                    //console.log(responseData);
                      if(xhr.status === 200) {
                        // update was successfull
                        console.log("Update was successfull");
                      } else {
                        console.log("Update was not successfull");
                      }
                }
            };
          
            xhr.open('POST', '../../api.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(jsonObj);

            this.checked = true;
        location.reload();
            })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
        
    });
  });


document.addEventListener("DOMContentLoaded", function(){
    var gridContainer = document.getElementById("grid-container");
    gridContainer.addEventListener('click', function(event){
      var target = event.target;
      //console.log(target);
      
      if(target.matches('a[href="View.php"]')){
        console.log("entered 1");
        var parent = target.closest('.overlay-text');
        var header = parent.querySelector('h4');
        var pElements = parent.querySelectorAll('p');
        var info = [];
        for(var i=0; i<pElements.length; i++){
          info.push(pElements[i].textContent);
        }

        myObj = {};
        myObj['title'] =header.textContent;
        info.forEach(function(item){
          var keyVal = item.split(": ");
          myObj[keyVal[0].toLowerCase()] = keyVal[1];
        });
        var stringObj = JSON.stringify(myObj);
        var check = false;
        for(var i=0; i< localStorage.length; i++){
          var key = localStorage.key(i);
      
          if(key.startsWith('View')){
            localStorage.removeItem(key);
            break;
          }
        }
        localStorage.setItem('View',stringObj);
        

      }

      // event.defaultPrevented = false;

  }); 
})

var count = 0;
document.addEventListener('DOMContentLoaded', function() {
  // localStorage.clear();
  var gridContainer = document.getElementById("grid-container");

  gridContainer.addEventListener('click', function(event) {
      var target = event.target;
      console.log("entered 2");
             fetch('getSessionData.php')
              .then(response => {
                  if (!response.ok) {
                      throw new Error('Network response was not ok');
                  }
                  return response.json();
              })
              .then(data => {
                if (target.matches('input#favourite') || target.matches('label[for="favourite"]')) {
                  count++;
                  if(target.checked){
                    var homeBlock = target.closest('.home-block');
                    if (homeBlock) {
                      var overlayTextDiv = homeBlock.querySelector('.overlay-text');
                      var h4Element = overlayTextDiv.querySelector('h4');
                      var pElements = overlayTextDiv.querySelectorAll('p');
                      var info = [];
                      for(var i=0; i<pElements.length; i++){
                        info.push(pElements[i].textContent);
                      }
                      var h4TextContent = h4Element.textContent;
                      var myObj = {};
                      myObj.title = h4TextContent;
                      info.forEach(function(item){
                        var keyVal = item.split(": ");
                        myObj[keyVal[0].toLowerCase()] = keyVal[1];
                      });


                      const myObjectString = JSON.stringify(myObj);
                      var final ={
                      }
                      final['type'] = "GetAllListings";
                      var string = [
                        "id"
                      ];
                      final['return'] = string;
                      final['apikey'] = data.apikey;
                      final['search'] = myObj;
                      console.log(final);
                      final.search.price = final.search.price.replace("R","");
                      var jsonObj = JSON.stringify(final);
                      // make request 
                      //localStorage.setItem('favourite'+count, myObjectString);
                      var ID;
                      var secondSearch ={};
                      var xhr = new XMLHttpRequest();
                      xhr.onreadystatechange = function() {
                         if(xhr.readyState === XMLHttpRequest.DONE) {
                            
                            //console.log(responseData);
                              if(xhr.status === 200) {
                                
                                if(xhr.responseText.length === 0){
                                  var noListingMessage = document.createElement('p');
                                  noListingMessage.id = "error";
                                  noListingMessage.textContent = 'No results were found for your search';
                                  document.body.appendChild(noListingMessage);
                                } else {
                                 console.log("Entered succes");
                                 var responseData = JSON.parse(xhr.responseText);
                                        var propertiesData = responseData.data;
                                        ID = propertiesData[0].id;
                                        
                                        secondSearch['id'] = ID;
                                        secondSearch['apikey'] = data.apikey;
                                        secondSearch['type'] = "Favourite";
                                        // console.log(secondSearch);

                                        jsonObj = JSON.stringify(secondSearch);
                                        // send request to api
                                        var xhr2 = new XMLHttpRequest();
                                        xhr2.onreadystatechange = function(){
                                            if(xhr.readyState === XMLHttpRequest.DONE) {
                                            if (xhr.status === 200) {
                                                console.log("Success");
                                            } else {
                                                console.log("Failed");
                                            }
                                            }
                                        }
                                        xhr2.open('POST', '../../api.php', true);
                                        xhr2.setRequestHeader('Content-Type', 'application/json');
                                        //   console.log
                                        xhr2.send(jsonObj);
                                }
                                
                                       
                              } else {
                                  console.error('Request failed with status:', xhr.status);
                              }
                            // var responseData = JSON.parse(xhr.responseText);
                            // if(responseData.status = "success"){
                            //     console.log("success");
                            // }
                         }
                      };
          
                      xhr.open('POST', '../../api.php', true);
                      xhr.setRequestHeader('Content-Type', 'application/json');
                      xhr.send(jsonObj);

                      //console.log(secondSearch);
                      

                                           
                    }
                  }
                  } 
                
                    })
              .catch(error => {
                    console.error('There was a problem with the fetch operation:', error);
              });


  });
});

var btnsave = document.getElementById('savebtn');
savebtn.addEventListener('click', function(){
  // get info
  console.log("clicked button");
  var minP = document.getElementById("miP").value;
          var maxP = document.getElementById("maP").value;
          var bedrooms = document.getElementById("nBe").value;
          var bathrooms = document.getElementById("nBa").value;
    var jsondata = {};      
      // save it into local storage
    if (!(minP === '')) {
      jsondata['min_price'] = minP;
      // localStorage.setItem('min_price',minP);
    }
    if (!(maxP === '')) {
      jsondata['max_price'] = maxP;
      // localStorage.setItem('max_price',maxP);
    }
    if (!(bedrooms=== '')) {
      jsondata['bedrooms'] = bedrooms;
      // localStorage.setItem('bedrooms',bedrooms);
    }
    if (!(bathrooms === '')) {
      jsondata['bathrooms'] = bathrooms;
      // localStorage.setItem('bathrooms', bathrooms);
    }

    fetch('getSessionData.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log("entered correct");
            // Use the API key obtained from session data
            if(Object.keys(jsondata).length > 0){
              localStorage.setItem(data.apikey,JSON.stringify(jsondata));
            }
        })
        .catch(error => {
              console.error('There was a problem with the fetch operation:', error);
        });
        
        location.reload();

});


document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        var loadingContainer = document.getElementById('loading');
        var gridContainer = document.getElementById('grid-container');

        loadingContainer.style.display = 'none';
        gridContainer.style.display = 'grid'; 
    }, 500); 
});

document.addEventListener('DOMContentLoaded', function(){
    var myObj = {
        "type": "GetAllListings",
        "return": "*"
    };

    fetch('getSessionData.php')
        .then(response => {
            // console.log("fetch did not work");
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response);
            return response.json();
        })
        .then(data => {
            // Use the API key obtained from session data
            myObj['apikey'] = data.apikey;
            if(localStorage.getItem(myObj['apikey']) !== null){
              // load content with already set preferences:
              // get the data from local storage
              var jsonData = JSON.parse(localStorage.getItem(myObj['apikey']));
              var search = {};

              for( var key in jsonData){
                if(key == "min_price" ){
                  myObj[key] = jsonData[key];
                } else if(key == "max_price"){
                  myObj[key] = jsonData[key];
                } else {
                  search[key] = jsonData[key]
                }
              }

              if(Object.keys(search).length > 0){
                myObj['search'] = search;
              }

              
              //console.log(myObj);
              var jsonObj = JSON.stringify(myObj);

              // load contents:
              var xhr = new XMLHttpRequest();
              xhr.onreadystatechange = function() {
                  if(xhr.readyState === XMLHttpRequest.DONE) {
                      if(xhr.status === 200) {
                        if(xhr.responseText.length === 0){
                          var noListingMessage = document.createElement('p');
                          noListingMessage.id = "error";
                          noListingMessage.textContent = 'No results were found for your search';
                          document.body.appendChild(noListingMessage);
                        } else {
                         // console.log(xhr.responseText);
                        var responseData = JSON.parse(xhr.responseText);
                                var propertiesData = responseData.data;
                                propertiesData.forEach(element => {
                                  const images = element.images.split(',');
                                  const firstImgaeUrl = images[0];
                        
                                  var container = document.getElementById("grid-container");
                        
                                  //<div class="home-block"
                                    var homeblock = document.createElement("div");
                                    homeblock.className = "home-block";
                                    container.appendChild(homeblock);
                        
                                    // <img>
                                    var imgElement = document.createElement("img");
                                    imgElement.src = firstImgaeUrl;
                                    imgElement.alt = "Home ";
                                    homeblock.appendChild(imgElement);
                                    // <div>
                                    var overlay = document.createElement("div");
                                    overlay.className = "overlay";
                                    homeblock.appendChild(overlay);
                                    // <div>
                                    var overlayT = document.createElement("div");
                                    overlayT.className = "overlay-text";
                                    overlay.appendChild(overlayT);
                        
                                    // title :
                                   var head4 = document.createElement("h4");
                                   head4.textContent = element.title;
                                   overlayT.appendChild(head4);
                        
                                   var bedrooms = document.createElement('p');
                                  bedrooms.textContent ="Bedrooms: " +element.bedrooms;
                                  overlayT.appendChild(bedrooms);
                        
                                  var bathrooms = document.createElement('p');
                                  bathrooms.textContent = "Bathrooms: "+element.bathrooms;
                                  overlayT.appendChild(bathrooms);
                        
                                  var squareFeet = document.createElement('p');
                                  squareFeet.textContent ="Location: "+ element.location;
                                  overlayT.appendChild(squareFeet);
                        
                                  var rent = document.createElement('p');
                                  rent.textContent = 'Price: R'+element.price;
                                  overlayT.appendChild(rent);
                        
                                  var checkbox = document.createElement('input');
                                  checkbox.setAttribute('type', 'checkbox');
                                  checkbox.setAttribute('id', 'favourite');
                                  checkbox.setAttribute('name', 'favourite');
                                  overlayT.appendChild(checkbox);
                        
                                  var label = document.createElement('label');
                                  label.setAttribute('for', 'favourite');
                                  label.textContent = 'Favourite';
                                  label.setAttribute('id', 'lblFav');
                                  overlayT.appendChild(label);
                        
                                  var breakb = document.createElement('br');
                                  overlayT.appendChild(breakb);
                        
                                  var viewLink = document.createElement('a');
                                  viewLink.setAttribute('href', 'View.php');
                                  viewLink.textContent = 'View this property';
                                  overlayT.appendChild(viewLink);   
                                  
                        document.body.appendChild(container);
                          });
                        }
                        
                               
                      } else {
                          console.error('Request failed with status:', xhr.status);
                      }
                  }
              };
  
              xhr.open('POST', '../../api.php', true);
              xhr.setRequestHeader('Content-Type', 'application/json');
              xhr.send(jsonObj);
            } else {
              // load normally 
              
              myObj['limit'] = 30;
              console.log(myObj);
              var jsonObj = JSON.stringify(myObj);

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if(xhr.readyState === XMLHttpRequest.DONE) {
                    if(xhr.status === 200) {
                      var responseData = JSON.parse(xhr.responseText);
                              var propertiesData = responseData.data;
                              propertiesData.forEach(element => {
                                const images = element.images.split(',');
                                const firstImgaeUrl = images[0];
                      
                                var container = document.getElementById("grid-container");
                      
                                //<div class="home-block"
                                  var homeblock = document.createElement("div");
                                  homeblock.className = "home-block";
                                  container.appendChild(homeblock);
                      
                                  // <img>
                                  var imgElement = document.createElement("img");
                                  imgElement.src = firstImgaeUrl;
                                  imgElement.alt = "Home ";
                                  homeblock.appendChild(imgElement);
                                  // <div>
                                  var overlay = document.createElement("div");
                                  overlay.className = "overlay";
                                  homeblock.appendChild(overlay);
                                  // <div>
                                  var overlayT = document.createElement("div");
                                  overlayT.className = "overlay-text";
                                  overlay.appendChild(overlayT);
                      
                                  // title :
                                 var head4 = document.createElement("h4");
                                 head4.textContent = element.title;
                                 overlayT.appendChild(head4);
                      
                                 var bedrooms = document.createElement('p');
                                bedrooms.textContent ="Bedrooms: " +element.bedrooms;
                                overlayT.appendChild(bedrooms);
                      
                                var bathrooms = document.createElement('p');
                                bathrooms.textContent = "Bathrooms: "+element.bathrooms;
                                overlayT.appendChild(bathrooms);
                      
                                var squareFeet = document.createElement('p');
                                squareFeet.textContent ="Location: "+ element.location;
                                overlayT.appendChild(squareFeet);
                      
                                var rent = document.createElement('p');
                                rent.textContent = 'Price: R'+element.price;
                                overlayT.appendChild(rent);
                      
                                var checkbox = document.createElement('input');
                                checkbox.setAttribute('type', 'checkbox');
                                checkbox.setAttribute('id', 'favourite');
                                checkbox.setAttribute('name', 'favourite');
                                overlayT.appendChild(checkbox);
                      
                                var label = document.createElement('label');
                                label.setAttribute('for', 'favourite');
                                label.textContent = 'Favourite';
                                label.setAttribute('id', 'lblFav');
                                overlayT.appendChild(label);
                      
                                var breakb = document.createElement('br');
                                overlayT.appendChild(breakb);
                      
                                var viewLink = document.createElement('a');
                                viewLink.setAttribute('href', 'View.php');
                                viewLink.textContent = 'View this property';
                                overlayT.appendChild(viewLink);   
                                
                      document.body.appendChild(container);
                        });
                    } else {
                        console.error('Request failed with status:', xhr.status);
                    }
                }
            };

            xhr.open('POST', '../../api.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(jsonObj);
            }

            
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
});

var searchForm = document.querySelector('.SB'); 

function clearGridContainer() {
    var container = document.getElementById('grid-container');
    while (container.firstChild) {
        container.removeChild(container.firstChild);
    }
}

// clear the paragrap 
    function clearError() {
      var container = document.getElementById('error');
      if(container){
        container.parentElement.removeChild(container);
      }
    }

searchForm.addEventListener('submit', function(event) {
    event.preventDefault(); 
    var input = document.getElementById("usertext").value;
    
    // Fetch session data to obtain API key
    fetch('getSessionData.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Create request object with API key from session data
            var myObj = {
                "apikey": data.apikey,
                "type": "GetAllListings",
                "return": "*",
                "limit": 30
            };

            var search = {
                "title": input
            };
            myObj['fuzzy'] = true;
            myObj['search'] = search;

            var jsonObj = JSON.stringify(myObj);
            
            // Clear current listings 
            clearError();
            clearGridContainer();
            
            // Make call to fetch properties with that title
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function(){
                if(xhr.readyState === XMLHttpRequest.DONE) {
                    if(xhr.status === 200) {
                        var responseData = JSON.parse(xhr.responseText);
                        var array = responseData.data; 

                        if(array.length === 0){
                            var noListingMessage = document.createElement('p');
                            noListingMessage.id = "error";
                            noListingMessage.textContent = 'No results were found for your search';
                            document.body.appendChild(noListingMessage);
                        } else {
                            array.forEach(element =>{
                              const images = element.images.split(',');
                                const firstImgaeUrl = images[0];
                      
                                var container = document.getElementById("grid-container");
                      
                                //<div class="home-block"
                                  var homeblock = document.createElement("div");
                                  homeblock.className = "home-block";
                                  container.appendChild(homeblock);
                      
                                  // <img>
                                  var imgElement = document.createElement("img");
                                  imgElement.src = firstImgaeUrl;
                                  imgElement.alt = "Home ";
                                  homeblock.appendChild(imgElement);
                                  // <div>
                                  var overlay = document.createElement("div");
                                  overlay.className = "overlay";
                                  homeblock.appendChild(overlay);
                                  // <div>
                                  var overlayT = document.createElement("div");
                                  overlayT.className = "overlay-text";
                                  overlay.appendChild(overlayT);
                      
                                  // title :
                                 var head4 = document.createElement("h4");
                                 head4.textContent = element.title;
                                 overlayT.appendChild(head4);
                      
                                 var bedrooms = document.createElement('p');
                                bedrooms.textContent ="Bedrooms: " +element.bedrooms;
                                overlayT.appendChild(bedrooms);
                      
                                var bathrooms = document.createElement('p');
                                bathrooms.textContent = "Bathrooms: "+element.bathrooms;
                                overlayT.appendChild(bathrooms);
                      
                                var squareFeet = document.createElement('p');
                                squareFeet.textContent ="Location: "+ element.location;
                                overlayT.appendChild(squareFeet);
                      
                                var rent = document.createElement('p');
                                rent.textContent = 'Price: R'+element.price;
                                overlayT.appendChild(rent);
                      
                                var checkbox = document.createElement('input');
                                checkbox.setAttribute('type', 'checkbox');
                                checkbox.setAttribute('id', 'favourite');
                                checkbox.setAttribute('name', 'favourite');
                                overlayT.appendChild(checkbox);
                      
                                var label = document.createElement('label');
                                label.setAttribute('for', 'favourite');
                                label.textContent = 'Favourite';
                                label.setAttribute('id', 'lblFav');
                                overlayT.appendChild(label);
                      
                                var breakb = document.createElement('br');
                                overlayT.appendChild(breakb);
                      
                                var viewLink = document.createElement('a');
                                viewLink.setAttribute('href', 'View.php');
                                viewLink.textContent = 'View this property';
                                overlayT.appendChild(viewLink);  
                                document.body.appendChild(container);
                            });
                        }
                    } else {
                        console.error('Request failed with status:', xhr.status);
                    }
                }
            };

            xhr.open('POST', '../../api.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(jsonObj);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
});

// Buy or Rent
var BuyButton = document.getElementById("Buy");
var RentButton = document.getElementById("Rent");

BuyButton.addEventListener('click', function() {
    // Fetch session data to obtain API key
    fetch('getSessionData.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Create request object with API key from session data
            var myObj = {
                "apikey": data.apikey,
                "type": "GetAllListings",
                "return": "*",
                "limit": 30
            };

            // Change JSON object
            var newJsonObj = {
                "type": "sale"
            };
            myObj["search"] = newJsonObj;
            var jsonObj = JSON.stringify(myObj);

            console.log('Buy radio button clicked');
            clearGridContainer();

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function(){
                if(xhr.readyState === XMLHttpRequest.DONE) {
                    if(xhr.status === 200) {
                        var responseData = JSON.parse(xhr.responseText);
                        var array = responseData.data; 

                        if(array.length === 0){
                            var noListingMessage = document.createElement('p');
                            noListingMessage.id = "error";
                            noListingMessage.textContent = 'No results were found for your search';
                            document.body.appendChild(noListingMessage);
                        } else {
                            array.forEach(element =>{
                              const images = element.images.split(',');
                                const firstImgaeUrl = images[0];
                      
                                var container = document.getElementById("grid-container");
                      
                                //<div class="home-block"
                                  var homeblock = document.createElement("div");
                                  homeblock.className = "home-block";
                                  container.appendChild(homeblock);
                      
                                  // <img>
                                  var imgElement = document.createElement("img");
                                  imgElement.src = firstImgaeUrl;
                                  imgElement.alt = "Home ";
                                  homeblock.appendChild(imgElement);
                                  // <div>
                                  var overlay = document.createElement("div");
                                  overlay.className = "overlay";
                                  homeblock.appendChild(overlay);
                                  // <div>
                                  var overlayT = document.createElement("div");
                                  overlayT.className = "overlay-text";
                                  overlay.appendChild(overlayT);
                      
                                  // title :
                                 var head4 = document.createElement("h4");
                                 head4.textContent = element.title;
                                 overlayT.appendChild(head4);
                      
                                 var bedrooms = document.createElement('p');
                                bedrooms.textContent ="Bedrooms: " +element.bedrooms;
                                overlayT.appendChild(bedrooms);
                      
                                var bathrooms = document.createElement('p');
                                bathrooms.textContent = "Bathrooms: "+element.bathrooms;
                                overlayT.appendChild(bathrooms);
                      
                                var squareFeet = document.createElement('p');
                                squareFeet.textContent ="Location: "+ element.location;
                                overlayT.appendChild(squareFeet);
                      
                                var rent = document.createElement('p');
                                rent.textContent = 'Price: R'+element.price;
                                overlayT.appendChild(rent);
                      
                                var checkbox = document.createElement('input');
                                checkbox.setAttribute('type', 'checkbox');
                                checkbox.setAttribute('id', 'favourite');
                                checkbox.setAttribute('name', 'favourite');
                                overlayT.appendChild(checkbox);
                      
                                var label = document.createElement('label');
                                label.setAttribute('for', 'favourite');
                                label.textContent = 'Favourite';
                                label.setAttribute('id', 'lblFav');
                                overlayT.appendChild(label);
                      
                                var breakb = document.createElement('br');
                                overlayT.appendChild(breakb);
                      
                                var viewLink = document.createElement('a');
                                viewLink.setAttribute('href', 'View.php');
                                viewLink.textContent = 'View this property';
                                overlayT.appendChild(viewLink); 

                                document.body.appendChild(container);
                            });
                        }
                    } else {
                        console.error('Request failed with status:', xhr.status);
                    }
                }
            };

            xhr.open('POST', '../../api.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(jsonObj);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
});


RentButton.addEventListener('click', function() {
    // Fetch session data to obtain API key
    fetch('getSessionData.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Create request object with API key from session data
            var myObj = {
                "apikey": data.apikey,
                "type": "GetAllListings",
                "return": "*",
                "limit": 30
            };

            // Change JSON object
            var newJsonObj = {
                "type": "rent"
            };
            myObj["search"] = newJsonObj;
            var jsonObj = JSON.stringify(myObj);

            console.log('Buy radio button clicked');
            clearGridContainer();

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function(){
                if(xhr.readyState === XMLHttpRequest.DONE) {
                    if(xhr.status === 200) {
                        var responseData = JSON.parse(xhr.responseText);
                        var array = responseData.data; 

                        if(array.length === 0){
                            var noListingMessage = document.createElement('p');
                            noListingMessage.id = "error";
                            noListingMessage.textContent = 'No results were found for your search';
                            document.body.appendChild(noListingMessage);
                        } else {
                            array.forEach(element =>{
                              const images = element.images.split(',');
                                const firstImgaeUrl = images[0];
                      
                                var container = document.getElementById("grid-container");
                      
                                //<div class="home-block"
                                  var homeblock = document.createElement("div");
                                  homeblock.className = "home-block";
                                  container.appendChild(homeblock);
                      
                                  // <img>
                                  var imgElement = document.createElement("img");
                                  imgElement.src = firstImgaeUrl;
                                  imgElement.alt = "Home ";
                                  homeblock.appendChild(imgElement);
                                  // <div>
                                  var overlay = document.createElement("div");
                                  overlay.className = "overlay";
                                  homeblock.appendChild(overlay);
                                  // <div>
                                  var overlayT = document.createElement("div");
                                  overlayT.className = "overlay-text";
                                  overlay.appendChild(overlayT);
                      
                                  // title :
                                 var head4 = document.createElement("h4");
                                 head4.textContent = element.title;
                                 overlayT.appendChild(head4);
                      
                                 var bedrooms = document.createElement('p');
                                bedrooms.textContent ="Bedrooms: " +element.bedrooms;
                                overlayT.appendChild(bedrooms);
                      
                                var bathrooms = document.createElement('p');
                                bathrooms.textContent = "Bathrooms: "+element.bathrooms;
                                overlayT.appendChild(bathrooms);
                      
                                var squareFeet = document.createElement('p');
                                squareFeet.textContent ="Location: "+ element.location;
                                overlayT.appendChild(squareFeet);
                      
                                var rent = document.createElement('p');
                                rent.textContent = 'Price: R'+element.price;
                                overlayT.appendChild(rent);
                      
                                var checkbox = document.createElement('input');
                                checkbox.setAttribute('type', 'checkbox');
                                checkbox.setAttribute('id', 'favourite');
                                checkbox.setAttribute('name', 'favourite');
                                overlayT.appendChild(checkbox);
                      
                                var label = document.createElement('label');
                                label.setAttribute('for', 'favourite');
                                label.textContent = 'Favourite';
                                label.setAttribute('id', 'lblFav');
                                overlayT.appendChild(label);
                      
                                var breakb = document.createElement('br');
                                overlayT.appendChild(breakb);
                      
                                var viewLink = document.createElement('a');
                                viewLink.setAttribute('href', 'View.php');
                                viewLink.textContent = 'View this property';
                                overlayT.appendChild(viewLink); 

                                document.body.appendChild(container);
                            });
                        }
                    } else {
                        console.error('Request failed with status:', xhr.status);
                    }
                }
            };

            xhr.open('POST', '../../api.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(jsonObj);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
});


// Sort by title or price
var TitleBtn = document.getElementById("title1");
var PriceBtn = document.getElementById("price1");

TitleBtn.addEventListener('click', function(){
    // Fetch session data to obtain API key
    fetch('getSessionData.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Create request object with API key from session data
            var myObj = {
                "apikey": data.apikey,
                "type": "GetAllListings",
                "return": "*",
                "limit": 30
            };

            // Change JSON object to sort by title
            var sort = ["title"];
            myObj["sort"] = sort;
            var jsonObj = JSON.stringify(myObj);
            console.log(myObj);
            clearGridContainer();

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function(){
                if(xhr.readyState === XMLHttpRequest.DONE) {
                    if(xhr.status === 200) {
                        var responseData = JSON.parse(xhr.responseText);
                        var array = responseData.data; 

                        if(array.length === 0){
                            var noListingMessage = document.createElement('p');
                            noListingMessage.id = "error";
                            noListingMessage.textContent = 'No results were found for your search';
                            document.body.appendChild(noListingMessage);

                        } else {
                            array.forEach(element =>{
                              const images = element.images.split(',');
                                const firstImgaeUrl = images[0];
                      
                                var container = document.getElementById("grid-container");
                      
                                //<div class="home-block"
                                  var homeblock = document.createElement("div");
                                  homeblock.className = "home-block";
                                  container.appendChild(homeblock);
                      
                                  // <img>
                                  var imgElement = document.createElement("img");
                                  imgElement.src = firstImgaeUrl;
                                  imgElement.alt = "Home ";
                                  homeblock.appendChild(imgElement);
                                  // <div>
                                  var overlay = document.createElement("div");
                                  overlay.className = "overlay";
                                  homeblock.appendChild(overlay);
                                  // <div>
                                  var overlayT = document.createElement("div");
                                  overlayT.className = "overlay-text";
                                  overlay.appendChild(overlayT);
                      
                                  // title :
                                 var head4 = document.createElement("h4");
                                 head4.textContent = element.title;
                                 overlayT.appendChild(head4);
                      
                                 var bedrooms = document.createElement('p');
                                bedrooms.textContent ="Bedrooms: " +element.bedrooms;
                                overlayT.appendChild(bedrooms);
                      
                                var bathrooms = document.createElement('p');
                                bathrooms.textContent = "Bathrooms: "+element.bathrooms;
                                overlayT.appendChild(bathrooms);
                      
                                var squareFeet = document.createElement('p');
                                squareFeet.textContent ="Location: "+ element.location;
                                overlayT.appendChild(squareFeet);
                      
                                var rent = document.createElement('p');
                                rent.textContent = 'Price: R'+element.price;
                                overlayT.appendChild(rent);
                      
                                var checkbox = document.createElement('input');
                                checkbox.setAttribute('type', 'checkbox');
                                checkbox.setAttribute('id', 'favourite');
                                checkbox.setAttribute('name', 'favourite');
                                overlayT.appendChild(checkbox);
                      
                                var label = document.createElement('label');
                                label.setAttribute('for', 'favourite');
                                label.textContent = 'Favourite';
                                label.setAttribute('id', 'lblFav');
                                overlayT.appendChild(label);
                      
                                var breakb = document.createElement('br');
                                overlayT.appendChild(breakb);
                      
                                var viewLink = document.createElement('a');
                                viewLink.setAttribute('href', 'View.php');
                                viewLink.textContent = 'View this property';
                                overlayT.appendChild(viewLink); 

                                document.body.appendChild(container);
                            });
                        }
                    } else {
                        console.error('Request failed with status:', xhr.status);
                    }
                }
            };

            xhr.open('POST', '../../api.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(jsonObj);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
});

PriceBtn.addEventListener('click', function(){
  // Fetch session data to obtain API key
  fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
          // Create request object with API key from session data
          var myObj = {
              "apikey": data.apikey,
              "type": "GetAllListings",
              "return": "*",
              "limit": 30
          };

          // Change JSON object to sort by title
          var sort = ["price"];
          myObj["sort"] = sort;
          var jsonObj = JSON.stringify(myObj);
          console.log(myObj);
          clearGridContainer();

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function(){
              if(xhr.readyState === XMLHttpRequest.DONE) {
                  if(xhr.status === 200) {
                      var responseData = JSON.parse(xhr.responseText);
                      var array = responseData.data; 

                      if(array.length === 0){
                          var noListingMessage = document.createElement('p');
                          noListingMessage.id = "error";
                          noListingMessage.textContent = 'No results were found for your search';
                          document.body.appendChild(noListingMessage);

                      } else {
                          array.forEach(element =>{
                            const images = element.images.split(',');
                              const firstImgaeUrl = images[0];
                    
                              var container = document.getElementById("grid-container");
                    
                              //<div class="home-block"
                                var homeblock = document.createElement("div");
                                homeblock.className = "home-block";
                                container.appendChild(homeblock);
                    
                                // <img>
                                var imgElement = document.createElement("img");
                                imgElement.src = firstImgaeUrl;
                                imgElement.alt = "Home ";
                                homeblock.appendChild(imgElement);
                                // <div>
                                var overlay = document.createElement("div");
                                overlay.className = "overlay";
                                homeblock.appendChild(overlay);
                                // <div>
                                var overlayT = document.createElement("div");
                                overlayT.className = "overlay-text";
                                overlay.appendChild(overlayT);
                    
                                // title :
                               var head4 = document.createElement("h4");
                               head4.textContent = element.title;
                               overlayT.appendChild(head4);
                    
                               var bedrooms = document.createElement('p');
                              bedrooms.textContent ="Bedrooms: " +element.bedrooms;
                              overlayT.appendChild(bedrooms);
                    
                              var bathrooms = document.createElement('p');
                              bathrooms.textContent = "Bathrooms: "+element.bathrooms;
                              overlayT.appendChild(bathrooms);
                    
                              var squareFeet = document.createElement('p');
                              squareFeet.textContent ="Location: "+ element.location;
                              overlayT.appendChild(squareFeet);
                    
                              var rent = document.createElement('p');
                              rent.textContent = 'Price: R'+element.price;
                              overlayT.appendChild(rent);
                    
                              var checkbox = document.createElement('input');
                              checkbox.setAttribute('type', 'checkbox');
                              checkbox.setAttribute('id', 'favourite');
                              checkbox.setAttribute('name', 'favourite');
                              overlayT.appendChild(checkbox);
                    
                              var label = document.createElement('label');
                              label.setAttribute('for', 'favourite');
                              label.textContent = 'Favourite';
                              label.setAttribute('id', 'lblFav');
                              overlayT.appendChild(label);
                    
                              var breakb = document.createElement('br');
                              overlayT.appendChild(breakb);
                    
                              var viewLink = document.createElement('a');
                              viewLink.setAttribute('href', 'View.php');
                              viewLink.textContent = 'View this property';
                              overlayT.appendChild(viewLink); 

                              document.body.appendChild(container);
                          });
                      }
                  } else {
                      console.error('Request failed with status:', xhr.status);
                  }
              }
          };

          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);
      })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
});

// Populate filter
function json(bed, bath) {
  var newJsonObj = {};
  if (!(bed === '')) {
      newJsonObj["bedrooms"] = bed;
  }
  if (!(bath === '')) {
      newJsonObj["bathrooms"] = bath;
  }
  return newJsonObj;
}

// get data from the form
var form = document.getElementById("FilterForm");
form.addEventListener("submit", function (event) {
  event.preventDefault();

  // Fetch session data to obtain API key
  fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
          var myObj = {
              "apikey": data.apikey,
              "type": "GetAllListings",
              "return": "*"
          };

          var minP = document.getElementById("miP");
          var maxP = document.getElementById("maP");
          var bedrooms = document.getElementById("nBe");
          var bathrooms = document.getElementById("nBa");

          // Validate form input
          // ...

          // Change the JSON object
          var newJsonObj = json(bedrooms.value, bathrooms.value);
          if (!(minP.value === '')) {
              myObj["min_price"] = minP.value;
          }
          if (!(maxP.value === '')) {
              myObj["max_price"] = maxP.value;
          }
          if (Object.keys(newJsonObj).length !== 0) {
              myObj["search"] = newJsonObj;
          }

          console.log(myObj);

          var jsonObj = JSON.stringify(myObj);
          clearError();
          clearGridContainer();

          // make call to fetch properties with that title
          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function () {
              if (xhr.readyState === XMLHttpRequest.DONE) {
                  if (xhr.status === 200) {
                      var responseData = JSON.parse(xhr.responseText);
                      var array = responseData.data;

                      if (array.length === 0) {
                          var noListingMessage = document.createElement('p');
                          noListingMessage.id = "error";
                          noListingMessage.textContent = 'No results were found for your search';
                          document.body.appendChild(noListingMessage);

                      } else {
                          array.forEach(element => {
                            const images = element.images.split(',');
                              const firstImgaeUrl = images[0];
                    
                              var container = document.getElementById("grid-container");
                    
                              //<div class="home-block"
                                var homeblock = document.createElement("div");
                                homeblock.className = "home-block";
                                container.appendChild(homeblock);
                    
                                // <img>
                                var imgElement = document.createElement("img");
                                imgElement.src = firstImgaeUrl;
                                imgElement.alt = "Home ";
                                homeblock.appendChild(imgElement);
                                // <div>
                                var overlay = document.createElement("div");
                                overlay.className = "overlay";
                                homeblock.appendChild(overlay);
                                // <div>
                                var overlayT = document.createElement("div");
                                overlayT.className = "overlay-text";
                                overlay.appendChild(overlayT);
                    
                                // title :
                               var head4 = document.createElement("h4");
                               head4.textContent = element.title;
                               overlayT.appendChild(head4);
                    
                               var bedrooms = document.createElement('p');
                              bedrooms.textContent ="Bedrooms: " +element.bedrooms;
                              overlayT.appendChild(bedrooms);
                    
                              var bathrooms = document.createElement('p');
                              bathrooms.textContent = "Bathrooms: "+element.bathrooms;
                              overlayT.appendChild(bathrooms);
                    
                              var squareFeet = document.createElement('p');
                              squareFeet.textContent ="Location: "+ element.location;
                              overlayT.appendChild(squareFeet);
                    
                              var rent = document.createElement('p');
                              rent.textContent = 'Price: R'+element.price;
                              overlayT.appendChild(rent);
                    
                              var checkbox = document.createElement('input');
                              checkbox.setAttribute('type', 'checkbox');
                              checkbox.setAttribute('id', 'favourite');
                              checkbox.setAttribute('name', 'favourite');
                              overlayT.appendChild(checkbox);
                    
                              var label = document.createElement('label');
                              label.setAttribute('for', 'favourite');
                              label.textContent = 'Favourite';
                              label.setAttribute('id', 'lblFav');
                              overlayT.appendChild(label);
                    
                              var breakb = document.createElement('br');
                              overlayT.appendChild(breakb);
                    
                              var viewLink = document.createElement('a');
                              viewLink.setAttribute('href', 'View.php');
                              viewLink.textContent = 'View this property';
                              overlayT.appendChild(viewLink); 

                              document.body.appendChild(container);
                          });
                      }
                  } else {
                      console.error('First request failed with status:', xhr.status);
                  }
              }
          };

          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);
      })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
});