
function Family(event){
  event.preventDefault();
  var btnFamily = document.getElementById('fam');
  var btnSingle = document.getElementById('single');

  console.log('Fam clicked');
    btnSingle.style.display = 'none';
    var container = document.querySelectorAll('.form-box form .field');
    container.forEach(function(element) {
      element.style.display = 'flex';
  });
    
}

function Single(event){
  event.preventDefault
  var btnFamily = document.getElementById('fam');
  var btnSingle = document.getElementById('single');

  console.log('Single clicked');
    btnFamily.style.display = 'none';
    var container = document.querySelectorAll('.form-box form .field');
    container.forEach(function(element) {
      element.style.display = 'flex';
  });
}



function signUp(event){
  event.preventDefault();
  var email = document.getElementById('email').value;
  var name = document.getElementById('name').value;
  var surname = document.getElementById('surname').value;
  var password = document.getElementById('password').value;
  
  var jsonObj = {
    "type": "Register",
    "name": name,
    "surname": surname,
    "email": email,
    "password": password
  }

  var jsonstring = JSON.stringify(jsonObj);

  var req = new XMLHttpRequest();
  req.onreadystatechange = function(){
    if(req.readyState === XMLHttpRequest.DONE){
      if(req.status === 200){
        var responseData = JSON.parse(req.responseText);
        
        if(responseData.status === 'success'){
          // when a user register their theme is set to default and then in the listing page they can change it
          window.open("Listing.php",'_self');
        } else {
          console.log(responseData.message);
        }
      } else {
        console.log("error");
      }
    }
  };
  req.open('POST', "../../api.php", true);
  req.setRequestHeader('Content-Type', 'application/json');
  req.send(jsonstring);
}


function redirect(event){
  console.log("Entered the function");
  event.preventDefault();
  window.location.href = "Listing.php";
}