// on load get the listings that was favourited and then populate the document

//var jsonObj = JSON.stringify(myObj);
document.addEventListener("DOMContentLoaded", function() {
  // Get the radio buttons for theme selection
  var lightRadio = document.querySelector('input[value="light"]');
  var darkRadio = document.querySelector('input[value="dark"]');

  // Listen for click event on the radio buttons
  lightRadio.addEventListener('click', function(event) {
      event.preventDefault();
    // Set the theme to light when the light radio button is clicked
      //   document.documentElement.setAttribute('data-theme', 'light');
      console.log("Light clicked");
      // send request to api to change the theme in the database 
      fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
      
          // type "changeTheme", theme "newTheme"
          var Obj = {}
          Obj['type'] = "ChangeTheme";
          Obj['NewTheme'] = "light";
          Obj['apikey'] = data.apikey;
          var jsonObj = JSON.stringify(Obj);

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function() {
              if(xhr.readyState === XMLHttpRequest.DONE) {
                          
                  //console.log(responseData);
                    if(xhr.status === 200) {
                      // update was successfull

                      console.log("Update was successfull");
                    } else {
                      console.log("Update was not successfull");
                    }
              }
          };
        
          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);

          this.checked = true;
      location.reload();
          })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
  });

  darkRadio.addEventListener('click', function(event) {
      event.preventDefault();
    // Set the theme to dark when the dark radio button is clicked
    console.log("Dark clicked");
  //   document.documentElement.setAttribute('data-theme', 'dark');
  fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
      
          // type "changeTheme", theme "newTheme"
          var Obj = {}
          Obj['type'] = "ChangeTheme";
          Obj['NewTheme'] = "dark";
          Obj['apikey'] = data.apikey;
          var jsonObj = JSON.stringify(Obj);

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function() {
              if(xhr.readyState === XMLHttpRequest.DONE) {
                          
                  //console.log(responseData);
                    if(xhr.status === 200) {
                      // update was successfull
                      console.log("Update was successfull");
                    } else {
                      console.log("Update was not successfull");
                    }
              }
          };
        
          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);

          this.checked = true;
      location.reload();
          })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
      
  });
});


document.addEventListener('DOMContentLoaded', function(){
  fetch('getSessionData.php')
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      var myObj = {
        "type": "GetFavourites"
      }

      // body : apikey, type, id
      // wat wil ek return, die listing ids van favourites

      var apikey = data.apikey;
      console.log("something")
      console.log(apikey);
      myObj['id'] = data.id;
      myObj['apikey'] = apikey;
      console.log(myObj);

      var stringObj = JSON.stringify(myObj);

      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(){
        if(xhr.readyState === XMLHttpRequest.DONE) {
          if(xhr.status === 200) {
            // console.log("success");
            var response = JSON.parse(xhr.responseText);
            var data = response;

            data.forEach(function(listing) {
              var FavouriteContainer = document.getElementById('Favourites');
              var maindiv = document.createElement('div');
                              maindiv.className = "List-Agents";
                              maindiv.style.backgroundImage = "url("+listing.images+")";
            
                              var backg = document.createElement('div');
                              backg.className = "backg";
            
                              var heading = document.createElement('h2');
                              heading.className = "Agent1";
                              heading.textContent = listing.title; 
                              backg.appendChild(heading);
            
                              var unorderd = document.createElement('ul');
                              var pri = document.createElement('li');
                              pri.textContent = "Price: R"+ listing.price;
                              var lo = document.createElement('li');
                              lo.textContent = "Location: "+ listing.location;
                              var beds = document.createElement('li');
                              beds.textContent = "Bedrooms: "+ listing.bedrooms;
                              var bath = document.createElement('li');
                              bath.textContent = "Bathrooms: "+ listing.bathrooms;
                              unorderd.appendChild(pri);
                              unorderd.appendChild(lo);
                              unorderd.appendChild(beds);
                              unorderd.appendChild(bath);
                              backg.appendChild(unorderd);
            
                              var btn = document.createElement('button');
                              btn.id = "favourite";
                              var icon = document.createElement('i');
                              icon.className = 'material-icons';
                              icon.textContent = 'Remove from favourites';
                              btn.appendChild(icon);
                              backg.appendChild(btn);
            
                              maindiv.appendChild(backg);
                              FavouriteContainer.appendChild(maindiv);
              
            });

          }
        }
      }
      xhr.open('POST', '../../api.php', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.send(stringObj);
        
    })
    .catch(error => {
      console.error('There was a problem with the fetch operation:', error);
   });
  
});


// when remove from favourites is clicked, remove the favourite 
// document.addEventListener("DOMContentLoaded", function(){
//   var grid = document.getElementById("Favourites");

//   grid.addEventListener('click', function(event){
//     var target = event.target;
//     console.log(target);
//     console.log("clicked");
//     if(target.matches('button')){
//       var parent = target.closest('.backg');

//       var title = parent.qeurySelect('h4');
//       console.log(title.textContent);

//     }
//   })
// })
document.addEventListener("DOMContentLoaded", function(){
  var grid = document.getElementById("Favourites");

  grid.addEventListener('click', function(event){
    var target = event.target.closest('button');

    if(target && target.matches('button')){
      var parent = target.closest('.backg');
      var title = parent.querySelector('h2').textContent;
      var price = parent.querySelector('ul li:first-child').textContent;
      var numericPrice = price.match(/\d+(\.\d+)?/)[0];
      console.log(numericPrice);

      // make request to API to remove from favourites and then reload the page
      // Wat ek gaan stuur: typpe "remove", title = title
      var Obj = {
        "type": "Remove",
        "title": title,
        "price": numericPrice
      }
      Obj.price = parseFloat(Obj.price);
      console.log(Obj);
      var stringObj = JSON.stringify(Obj);
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(){
        if(xhr.readyState === XMLHttpRequest.DONE) {
          if(xhr.status === 200) {
            console.log("success");
            window.location.reload();
          }
        }
      }
      xhr.open('POST', '../../api.php', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.send(stringObj);
      
      
    }
  });
});