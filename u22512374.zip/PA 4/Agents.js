document.addEventListener("DOMContentLoaded", function() {
  // Get the radio buttons for theme selection
  var lightRadio = document.querySelector('input[value="light"]');
  var darkRadio = document.querySelector('input[value="dark"]');

  // Listen for click event on the radio buttons
  lightRadio.addEventListener('click', function(event) {
      event.preventDefault();
    // Set the theme to light when the light radio button is clicked
      //   document.documentElement.setAttribute('data-theme', 'light');
      console.log("Light clicked");
      // send request to api to change the theme in the database 
      fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
      
          // type "changeTheme", theme "newTheme"
          var Obj = {}
          Obj['type'] = "ChangeTheme";
          Obj['NewTheme'] = "light";
          Obj['apikey'] = data.apikey;
          var jsonObj = JSON.stringify(Obj);

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function() {
              if(xhr.readyState === XMLHttpRequest.DONE) {
                          
                  //console.log(responseData);
                    if(xhr.status === 200) {
                      // update was successfull

                      console.log("Update was successfull");
                    } else {
                      console.log("Update was not successfull");
                    }
              }
          };
        
          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);

          this.checked = true;
      location.reload();
          })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
  });

  darkRadio.addEventListener('click', function(event) {
      event.preventDefault();
    // Set the theme to dark when the dark radio button is clicked
    console.log("Dark clicked");
  //   document.documentElement.setAttribute('data-theme', 'dark');
  fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
      
          // type "changeTheme", theme "newTheme"
          var Obj = {}
          Obj['type'] = "ChangeTheme";
          Obj['NewTheme'] = "dark";
          Obj['apikey'] = data.apikey;
          var jsonObj = JSON.stringify(Obj);

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function() {
              if(xhr.readyState === XMLHttpRequest.DONE) {
                          
                  //console.log(responseData);
                    if(xhr.status === 200) {
                      // update was successfull
                      console.log("Update was successfull");
                    } else {
                      console.log("Update was not successfull");
                    }
              }
          };
        
          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);

          this.checked = true;
      location.reload();
          })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
      
  });
});

// replace mock data: 10 agents
var limit = 10;
var myObj = {
  "studentnum": "u22512374",
  "apikey": "e7c1e5d12f5eeab28e47645a8445d161",
  "type": "GetAllAgents",
  "limit": limit
}
var jsonObj = JSON.stringify(myObj);

document.addEventListener('DOMContentLoaded', function() {
  setTimeout(function() {
      var loadingContainer = document.getElementById('loading');
      var gridContainer = document.getElementById('Agents');

      loadingContainer.style.display = 'none';
      gridContainer.style.display = 'block'; 
  }, 500); 
});

document.addEventListener('DOMContentLoaded',function(){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if(xhr.readyState === XMLHttpRequest.DONE) {
      if(xhr.status === 200) {
        var responseData = JSON.parse(xhr.responseText);
        var array = responseData.data; 
        console.log(array);

        var j = 0;
        var Agents = document.getElementById("Agents");
        while (j < 10) {
          (function(j) {
            var secondXhr = new XMLHttpRequest();
            secondXhr.onreadystatechange = function() {
              if (secondXhr.readyState === XMLHttpRequest.DONE) {
                if (secondXhr.status === 200) {
                  var responseData = JSON.parse(secondXhr.responseText);
                  var imglink = responseData.data; 
                  console.log(imglink);
                  if(j%2===0){
                    console.log("even");
                    // <div class='container'>
                    var container = document.createElement("div");
                    container.className = "container";
                    Agents.appendChild(container);
                    // <span class='boc'>
                    var box = document.createElement("span");
                    box.className="box";
                    // box.style.backgroundImage = "url('" + imglink + "')";
                    container.appendChild(box);
                    // description
                    var description = document.createElement("span");
                    description.className = "description";
                    box.appendChild(description);
                    // heading
                    var heading = document.createElement("h3");
                    heading.textContent = array[j].name;
                    description.appendChild(heading);
                    var para = document.createElement("p");
                    para.textContent = array[j].description;
                    description.appendChild(para);
                    var link = document.createElement("a");
                    link.href = array[j].url;
                    link.textContent="Visit our website";
                    description.appendChild(link);

                    // The logo should be added here but i do not know where to get the logo //
                    // var backg = document.createElement("span");
                    var imgbox = document.createElement("span");
                    imgbox.className = "backgroundLogo";
                    box.appendChild(imgbox);
                    var logo = document.createElement("img");
                    logo.src = imglink;
                    imgbox.appendChild(logo);

                  } else {
                    console.log("odd");
                    var container = document.getElementsByClassName("container");
                    var lastContainer = container[container.length - 1];
                    // <span class='boc'>
                    var box = document.createElement("span");
                    box.className="box";
                    // box.style.backgroundImage = "url('" + imglink + "')";
                    lastContainer.appendChild(box);
                    // description
                    var description = document.createElement("span");
                    description.className = "description";
                    box.appendChild(description);
                    // heading
                    var heading = document.createElement("h3");
                    heading.textContent = array[j].name;
                    description.appendChild(heading);
                    var para = document.createElement("p");
                    para.textContent = array[j].description;
                    description.appendChild(para);
                    var link = document.createElement("a");
                    link.textContent="Visit our website";
                    link.href = array[j].url;
                    description.appendChild(link);  
                    // img
                    var imgbox = document.createElement("span");
                    imgbox.className = "backgroundLogo";
                    box.appendChild(imgbox);
                    var logo = document.createElement("img");
                    logo.src = imglink;
                    imgbox.appendChild(logo);
                  }
                  
                } else {
                  console.error('Second request failed with status:', secondXhr.status);
                }
              }
            };
            secondXhr.open('GET', 'https://wheatley.cs.up.ac.za/api/getimage?agency=' + array[j].name, false);
            secondXhr.send();
          })(j);
          j++;
        }
      } else {
        console.error('First request failed with status:', xhr.status);
      }
    }
  };
  xhr.open('POST', 'https://wheatley.cs.up.ac.za/api/', true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.send(jsonObj);
});