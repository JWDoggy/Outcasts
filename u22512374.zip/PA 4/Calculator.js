
document.addEventListener("DOMContentLoaded", function() {
  // Get the radio buttons for theme selection
  var lightRadio = document.querySelector('input[value="light"]');
  var darkRadio = document.querySelector('input[value="dark"]');

  // Listen for click event on the radio buttons
  lightRadio.addEventListener('click', function(event) {
      event.preventDefault();
    // Set the theme to light when the light radio button is clicked
      //   document.documentElement.setAttribute('data-theme', 'light');
      console.log("Light clicked");
      // send request to api to change the theme in the database 
      fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
      
          // type "changeTheme", theme "newTheme"
          var Obj = {}
          Obj['type'] = "ChangeTheme";
          Obj['NewTheme'] = "light";
          Obj['apikey'] = data.apikey;
          var jsonObj = JSON.stringify(Obj);

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function() {
              if(xhr.readyState === XMLHttpRequest.DONE) {
                          
                  //console.log(responseData);
                    if(xhr.status === 200) {
                      // update was successfull

                      console.log("Update was successfull");
                    } else {
                      console.log("Update was not successfull");
                    }
              }
          };
        
          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);

          this.checked = true;
      location.reload();
          })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
  });

  darkRadio.addEventListener('click', function(event) {
      event.preventDefault();
    // Set the theme to dark when the dark radio button is clicked
    console.log("Dark clicked");
  //   document.documentElement.setAttribute('data-theme', 'dark');
  fetch('getSessionData.php')
      .then(response => {
          if (!response.ok) {
              throw new Error('Network response was not ok');
          }
          return response.json();
      })
      .then(data => {
      
          // type "changeTheme", theme "newTheme"
          var Obj = {}
          Obj['type'] = "ChangeTheme";
          Obj['NewTheme'] = "dark";
          Obj['apikey'] = data.apikey;
          var jsonObj = JSON.stringify(Obj);

          var xhr = new XMLHttpRequest();
          xhr.onreadystatechange = function() {
              if(xhr.readyState === XMLHttpRequest.DONE) {
                          
                  //console.log(responseData);
                    if(xhr.status === 200) {
                      // update was successfull
                      console.log("Update was successfull");
                    } else {
                      console.log("Update was not successfull");
                    }
              }
          };
        
          xhr.open('POST', '../../api.php', true);
          xhr.setRequestHeader('Content-Type', 'application/json');
          xhr.send(jsonObj);

          this.checked = true;
      location.reload();
          })
      .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
      });
      
  });
});
// Caluclate Mortage
var Mortage = document.getElementById('Mortage');

Mortage.addEventListener('submit', function(event){
  // get info
  event.preventDefault();
  var HomePrice = document.getElementById('HomePrice').value;
  var Deposit = document.getElementById('Deposit').value;
  var Rate = document.getElementById('InterestRate').value;
  var Months = document.getElementById('LoanTerm').value ;

  Months = Months*12;

  if(HomePrice.value === "" || Deposit.value ==="" || Months.value ===""){
    alert("Please enter all the values");
    return;
  }

  if(HomePrice.value < Deposit.value){
    alert("Please enter correct information. Deposit can not be more than Price!");
    return;
  }

  if(HomePrice < 0 || Deposit < 0 || Months < 0 ){
    alert("Enter information cannot be less than zero!");
    return;
  }

  // Cost per month:
  var CpM = (HomePrice - Deposit) * (Rate / 12/100) * (Math.pow((1 + Rate / 12/100), Months)) / (Math.pow((1 + Rate / 12/100), Months) - 1);
  CpM = CpM.toFixed(2);

  var TotalCost = CpM*Months;
  TotalCost = TotalCost.toFixed(2);

  // update the output
  var output = document.getElementById('OutputMortage');
  var list = output.querySelector('ul');
  if(list){
    list.innerHTML ='';
  }
  

  var Total = document.createElement('li');
  Total.textContent = "Total Cost: R"+ TotalCost;
  Total.style.listStyleType = "none";
  list.appendChild(Total);

  var PerM = document.createElement('li');
  PerM.textContent = "Cost per Month: R"+ CpM;
  PerM.style.listStyleType = "none";
  list.appendChild(PerM);
  
});

var PtR = document.getElementById("PriceRent");
PtR.addEventListener('submit', function(event){
  event.preventDefault();

  var income = document.getElementById('Income');

  if(income.value === ""){
    alert("Enter you mothly income");
    return;
  }

  if(parseFloat(income.value) < 0){
    alert("Entered income can not be less than zero");
    return;
  }

  var QualifyAmount = income.value*0.28;
  QualifyAmount = QualifyAmount.toFixed(2);
  var span = document.getElementById('OutputPricetoRent');
  var output = span.querySelector('p');

  if(output){
    output.innerHTML = "";
  }
  output.innerHTML = "According to the 28/36 rule, you can qualify for a mortage payment of R"+ QualifyAmount+ " monthly";
})