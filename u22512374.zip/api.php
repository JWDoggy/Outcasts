<?php
// $conn is the connection to my database
session_start();
header('Content-Type: application/json');
include "config.php";
$config = config::instance();
$conn = $config->Connection();

$tester = API::instance($conn);
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $post_body = json_decode(file_get_contents("php://input"), true);
    
    if (
        !isset($post_body['type'])
    ) {
        $error ="Type must be specified";
        $response = [
            "status" => "error",
            "timestamp"=> time(),
            "message" => $error,
        ];
        $json_response = json_encode($response);
        echo $json_response;
        exit();

    } else {
        if($post_body['type']=== 'SingeCheck'){
            $tester->SingeCheck();
        }

        if($post_body['type'] === 'Images'){
            $tester->Images();
        }

        if($post_body['type'] === 'GetSeries'){
            $tester->GetSeries();
        }

        if($post_body['type'] === 'GetRatings'){
            $tester->GetRatings();
        }

        if($post_body['type'] === 'filter'){
            $tester->filter();
        }

        if($post_body['type'] === 'RegisterFam'){
            $tester->RegisterFam();
        }

        if($post_body['type'] === 'filterbyOther'){
            $tester->filterbyOther();
        }

        if($post_body['type'] === "Register"){
            $tester->Register();

        }
        if($post_body['type'] === "GetMovies"){
            $tester->GetMovies();
        } 
        if($post_body['type'] === 'Login'){
            $tester->Login();
        }
        if($post_body['type'] === 'favourite'){
            $tester->Favourite();
        }
        if($post_body['type'] === 'getFavourites'){
            $tester->GetFavourites();
        }

        if($post_body['type'] === 'Remove'){
            $tester->Remove();
        }
        if($post_body['type'] === 'ChangeTheme'){
            $tester->ChangeTheme();
        }
    }
} else {
    $error =
                        "Method not supported";
                    $response = [
                        "status" => "error",
                        "timestamp"=> time(),
                        "message" => $error,
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
}



class API
{
    protected $dbconnection;
    public static function instance($conn)
    {
        static $instance = null;
        if ($instance === null) {
            $instance = new API($conn);
        }
        return $instance;
    }
    private function __construct($conn)
    {
        $this->dbconnection = $conn;
    }
    public function __destruct()
    {
        $this->dbconnection->close();
    }

    public function Connection()
    {
        return $this->dbconnection;
    }

    public function RegisterFam(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
            // Check that the entered email and password is in the database
            $require_keys = ['name','surname','mebercount','email','password'];
            foreach ($require_keys as $key) {
                // Check that all the required fields are entered
                if(!isset($post_body[$key])){
                    $response = [
                        "status" => "error",
                        "timestamp"=> time(),
                        "message" =>
                            "Missing Parameters",
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            }

            // Create a new user
            $sql = "INSERT INTO users () VALUES ()";
            if ($conn->query($sql) === TRUE) {
                // Get the last inserted ID
                $id = $conn->insert_id;

                $email = $post_body['email'];
                $password = $post_body['password'];

                //
                
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }

            $conn->close();
            // Get the id of the user
            // Add the login info
            // add them to family table
            // add members to family members table
    }

    public function filterbyOther(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
            // Check that the entered email and password is in the database
            $require_keys = ['case','content'];
            foreach ($require_keys as $key) {
                // Check that all the required fields are entered
                if(!isset($post_body[$key])){
                    $response = [
                        "status" => "error",
                        "timestamp"=> time(),
                        "message" =>
                            "Missing Parameters",
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            }
            $case = $post_body['case'];
            if($case === 'New Releases'){
                if($post_body['content'] === 'movies'){
                    $query_movies = "SELECT * FROM movies WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY release_date DESC";
                    $response = mysqli_query($conn, $query_movies);
                    if (mysqli_num_rows($response) > 0) {
                        $movies = [];
            
                        while ($row = mysqli_fetch_assoc($response)) {
                            $movies[] = $row;
                        }
            
                        // Success response with movies data
                        $response = [
                            "status" => "success",
                            "timestamp" => time(),
                            "data" => $movies
                        ];
                    } else {
                        // No movies found
                        $response = [
                            "status" => "error",
                            "timestamp" => time(),
                            "message" => "No movies found"
                        ];
                    }
            
                    // Output the response as JSON
                    echo json_encode($response);
                } else {
                    $query_movies = "SELECT * FROM series WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY release_date DESC";
                    $response = mysqli_query($conn, $query_movies);
                    if (mysqli_num_rows($response) > 0) {
                        $movies = [];
            
                        while ($row = mysqli_fetch_assoc($response)) {
                            $movies[] = $row;
                        }
            
                        // Success response with movies data
                        $response = [
                            "status" => "success",
                            "timestamp" => time(),
                            "data" => $movies
                        ];
                    } else {
                        // No movies found
                        $response = [
                            "status" => "error",
                            "timestamp" => time(),
                            "message" => "No movies found"
                        ];
                    }
    
                    echo json_encode($response);
                }
            } else {
                if($post_body['content'] === 'movies'){
                    $query_movies = "SELECT * FROM movies WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY rating DESC";
                    $response = mysqli_query($conn, $query_movies);
                    if (mysqli_num_rows($response) > 0) {
                        $movies = [];
            
                        while ($row = mysqli_fetch_assoc($response)) {
                            $movies[] = $row;
                        }
            
                        // Success response with movies data
                        $response = [
                            "status" => "success",
                            "timestamp" => time(),
                            "data" => $movies
                        ];
                    } else {
                        // No movies found
                        $response = [
                            "status" => "error",
                            "timestamp" => time(),
                            "message" => "No movies found"
                        ];
                    }
            
                    // Output the response as JSON
                    echo json_encode($response);
                } else {
                    $query_movies = "SELECT * FROM series WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY rating DESC";
                    $response = mysqli_query($conn, $query_movies);
                    if (mysqli_num_rows($response) > 0) {
                        $movies = [];
            
                        while ($row = mysqli_fetch_assoc($response)) {
                            $movies[] = $row;
                        }
            
                        // Success response with movies data
                        $response = [
                            "status" => "success",
                            "timestamp" => time(),
                            "data" => $movies
                        ];
                    } else {
                        // No movies found
                        $response = [
                            "status" => "error",
                            "timestamp" => time(),
                            "message" => "No movies found"
                        ];
                    }
    
                    echo json_encode($response);
                }
            }
            
    }
    public function filter(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
            // Check that the entered email and password is in the database
            $require_keys = ['genre','content'];
            foreach ($require_keys as $key) {
                // Check that all the required fields are entered
                if(!isset($post_body[$key])){
                    $response = [
                        "status" => "error",
                        "timestamp"=> time(),
                        "message" =>
                            "Missing Parameters",
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            }
            $genre = $post_body['genre'];
            if($post_body['content'] === 'movies'){
                $query_movies = "SELECT * FROM movies WHERE poster IS NOT NULL AND TRIM(poster) <> '' AND genres = '$genre'";
                $response = mysqli_query($conn, $query_movies);
                if (mysqli_num_rows($response) > 0) {
                    $movies = [];
        
                    while ($row = mysqli_fetch_assoc($response)) {
                        $movies[] = $row;
                    }
        
                    // Success response with movies data
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $movies
                    ];
                } else {
                    // No movies found
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "No movies found"
                    ];
                }
        
                // Output the response as JSON
                echo json_encode($response);
            } else {
                $query_movies = "SELECT * FROM series WHERE poster IS NOT NULL AND TRIM(poster) <> '' AND genres = '$genre'";
                $response = mysqli_query($conn, $query_movies);
                if (mysqli_num_rows($response) > 0) {
                    $movies = [];
        
                    while ($row = mysqli_fetch_assoc($response)) {
                        $movies[] = $row;
                    }
        
                    // Success response with movies data
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $movies
                    ];
                } else {
                    // No movies found
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "No movies found"
                    ];
                }

                echo json_encode($response);
            }
        
    }

    public function GetRatings(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
        
            $qeury = "SELECT * FROM movies WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY rating DESC LIMIT 10";
            $response = mysqli_query($conn, $qeury);    
            if(mysqli_num_rows($response) > 0){
                
                $data = [];
        
                while ($row = mysqli_fetch_assoc($response)) {
                    $data[] = $row;
                }
                
                // Construct a successful response
                $response = [
                    "status" => "success",
                    "timestamp" => time(),
                    "data" => $data
                ];
                
                $json_response = json_encode($response);
                echo $json_response;
            } else {
                // email was incorrect
                $response = [
                    "status" => "error",
                    "timestamp" => time(),
                    "message" => "Failure"
                ];
                $json_response = json_encode($response);
                echo $json_response;
                exit();
            }
        
    }

    public function Images(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
        

        if($post_body['content'] === 'movies'){
            if(isset($post_body['rating'])){
                $qeury = "SELECT poster FROM movies WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY CAST(rating AS DECIMAL(3, 1)) DESC LIMIT 5";
                $response = mysqli_query($conn, $qeury);    
                if(mysqli_num_rows($response) > 0){
                    
                    $data = [];
            
                    while ($row = mysqli_fetch_assoc($response)) {
                        $data[] = $row['poster'];
                    }
                    
                    // Construct a successful response
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $data
                    ];
                    
                    $json_response = json_encode($response);
                    echo $json_response;
                } else {
                    // email was incorrect
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "Failure"
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            }
            
            if(isset($post_body['new'])){
                $qeury = "SELECT poster FROM movies WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY CAST(release_date AS UNSIGNED) DESC LIMIT 5";
                $response = mysqli_query($conn, $qeury);    
                if(mysqli_num_rows($response) > 0){
                    
                    $data = [];
            
                    while ($row = mysqli_fetch_assoc($response)) {
                        $data[] = $row['poster'];
                    }
                    
                    // Construct a successful response
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $data
                    ];
                    
                    $json_response = json_encode($response);
                    echo $json_response;
                } else {
                    // email was incorrect
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "Failure"
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            }
        } else {
            if(isset($post_body['rating'])){
                $qeury = "SELECT poster FROM series WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY CAST(rating AS DECIMAL(3, 1)) DESC LIMIT 5";
                $response = mysqli_query($conn, $qeury);    
                if(mysqli_num_rows($response) > 0){
                    
                    $data = [];
            
                    while ($row = mysqli_fetch_assoc($response)) {
                        $data[] = $row['poster'];
                    }
                    
                    // Construct a successful response
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $data
                    ];
                    
                    $json_response = json_encode($response);
                    echo $json_response;
                } else {
                    // email was incorrect
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "Failure"
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            }
            
            if(isset($post_body['new'])){
                $qeury = "SELECT poster FROM series WHERE poster IS NOT NULL AND TRIM(poster) <> '' ORDER BY CAST(release_date AS UNSIGNED) DESC LIMIT 5";
                $response = mysqli_query($conn, $qeury);    
                if(mysqli_num_rows($response) > 0){
                    
                    $data = [];
            
                    while ($row = mysqli_fetch_assoc($response)) {
                        $data[] = $row['poster'];
                    }
                    
                    // Construct a successful response
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $data
                    ];
                    
                    $json_response = json_encode($response);
                    echo $json_response;
                } else {
                    // email was incorrect
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "Failure"
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            }
        }

    }

    public function SingeCheck(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
    
            // Check that the entered email and password is in the database
            $ID = $post_body["ID"];
            $qeury_email = "Select * from single_account where user_id = '$ID'";
            $response = mysqli_query($conn, $qeury_email);    
            if(mysqli_num_rows($response) > 0){
                // email is fine
                // check password
                $return = [
                    "status" => "success",
                    "timestamp"=> time()
                ];
                $json_response = json_encode($return);
                http_response_code(200);
                // header("Content-Type: application/json");
                echo $json_response;
            } else {
                // email was incorrect
                $response = [
                    "status" => "error",
                    "timestamp" => time(),
                    "message" => "Family Account"
                ];
                $json_response = json_encode($response);
                echo $json_response;
                exit();
            }
    }

    public function ChangeTheme(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
        $require_keys = ['NewTheme','apikey'];
        foreach ($require_keys as $key) {
            // Check that all the required fields are entered
            if(!isset($post_body[$key])){
                $response = [
                    "status" => "error",
                    "timestamp"=> time(),
                    "message" =>
                        "Missing Parameters",
                ];
                $json_response = json_encode($response);
                echo $json_response;
                exit();
            }
        }      

        $theme = $post_body["NewTheme"];
        $apikey = $post_body["apikey"];

        $sql = "UPDATE user_information SET theme = ? WHERE api_key = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            // Handle prepare error
            echo "Prepare error: " . $conn->error;
            exit();
        }

        $stmt->bind_param("ss", $theme, $apikey);
        if (!$stmt->execute()) {
            // Handle execute error
            echo "Execute error: " . $stmt->error;
            exit();
        }

        if ($stmt->execute()) {
            // Theme updated successfully
            //echo "Theme updated successfully.";
            $_SESSION['theme'] = $theme;
            http_response_code(200);
            $response = [
                "status" => "success",
                "message" => "Successfully updated theme"
            ];
            echo json_encode($response);
        } else {
            // Failed to update theme
            echo "Failed to update theme: " . $conn->error;
            http_response_code(500);
            $response = [
                "status" => "error",
                "message" => "Failed to update theme"
            ];
            echo json_encode($response);
        }
        $stmt->close();
    }

    public function Remove(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
        $require_keys = ['title',"price"];
        foreach ($require_keys as $key) {
            // Check that all the required fields are entered
            if(!isset($post_body[$key])){
                $response = [
                    "status" => "error",
                    "timestamp"=> time(),
                    "message" =>
                        "Missing Parameters",
                ];
                $json_response = json_encode($response);
                echo $json_response;
                exit();
            }
        }

        $title = $post_body["title"];
        $price = $post_body['price'];
        $result = -1;
        
        $sql = "SELECT id FROM listings WHERE title = ? AND price = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $title, $price);
        $stmt->execute();
        $stmt->bind_result($result); 
        $stmt->fetch();

        $stmt->close();

        $sql = "DELETE FROM favourites where listing_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $result);
        $stmt->execute();
        $affected_rows = $stmt->affected_rows;
        $stmt->close();
        
        if ($affected_rows > 0) {
            // Return success message with HTTP response code 200
            http_response_code(200);
            $response = [
                "status" => "success"
            ];
            echo json_encode($response);
        } else {
            // Return error message with HTTP response code 500 (Internal Server Error)
            http_response_code(500);
            $response = [
                "status" => "error",
                "message" => "Failed to delete favorite"
            ];
            echo json_encode($response);
        }
    }

    public function GetFavourites(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
        $require_keys = ['user_id','content'];
        foreach ($require_keys as $key) {
            // Check that all the required fields are entered
            if(!isset($post_body[$key])){
                $response = [
                    "status" => "error",
                    "timestamp"=> time(),
                    "message" =>
                        "Missing Parameters",
                ];
                $json_response = json_encode($response);
                echo $json_response;
                exit();
            }
        }
        
        if($post_body['content'] === 'movies'){
            $content_id = -1;
        $user_id = $post_body["user_id"];
        $content_ids = []; // Initialize an empty array to store the results
        
        $sql = "SELECT content_id FROM favourites WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $user_id);
        $stmt->execute();
        $stmt->bind_result($content_id); // Bind the result to a variable
        
        // Fetch each row and store in an array of objects
        while ($stmt->fetch()) {
            $content_ids[] = ['content_id' => $content_id]; // Store each result in an object
        }
        
        $stmt->close();

        // now i have all the listing ids, 
        // return image, price title location bedrooms bathrooms
        $all_listing_details = [];
        foreach ($content_ids as $content) {
            //echo $listing['listing_id'] . "<br>";
            $poster = "";
            $title = "";
            $description = "";


            $sql2 = "SELECT poster,Title,Description FROM movies WHERE id = ?";
            $stmt2 = $conn->prepare($sql2);
            $stmt2->bind_param("s", $content["content_id"]);
            $stmt2->execute();
            $stmt2->bind_result($poster, $title, $description); // Bind the result to variables
            
            // Fetch the result
            $stmt2->fetch();
            
            
            // Create an object to store the result
            $listing_details = [
                'poster' => $poster,
                'title' => $title,
                'description' => $description
            ];
            $all_listing_details[] = $listing_details;
            
            $stmt2->close();
            
            // Now $listing_details is an object containing the details of the listing, with only the first image

        }
        http_response_code(200);
        echo json_encode($all_listing_details);
        }
    }

    public function Favourite() {
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
        $require_keys = ['data', 'user_id','content'];
    
        foreach ($require_keys as $key) {
            if (!isset($post_body[$key])) {
                $response = [
                    "status" => "error",
                    "timestamp" => time(),
                    "message" => "Missing Parameters",
                ];
                echo json_encode($response);
                return;
            }
        }
    
        if($post_body['content'] === 'movie'){
            // Directly use the 'data' field as an array
        $data = $post_body['data'];
    
        if (!is_array($data)) {
            $response = [
                "status" => "error",
                "timestamp" => time(),
                "message" => "Invalid data format"
            ];
            echo json_encode($response);
            return;
        }
    
        $title = $data['title'];
        $user_id = $post_body['user_id'];
        $description = $data['description'];
    
        $listing_id = -1;
        $sql = "SELECT id FROM movies WHERE title = ? AND description = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            $response = [
                "status" => "error",
                "timestamp" => time(),
                "message" => "Failed to prepare statement: " . $conn->error
            ];
            echo json_encode($response);
            return;
        }
        
        $stmt->bind_param("ss", $title, $description);
        $stmt->execute();
        $stmt->bind_result($listing_id);
        $stmt->fetch();
        $stmt->close();
    
        if ($listing_id != -1) { 
            $sql = "INSERT INTO favourites (user_id, content_id) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                $response = [
                    "status" => "error",
                    "timestamp" => time(),
                    "message" => "Failed to prepare statement: " . $conn->error
                ];
                echo json_encode($response);
                return;
            }
            $stmt->bind_param("ii", $user_id, $listing_id); 
            $insertResult = $stmt->execute();
            $stmt->close();
    
            if ($insertResult) { 
                $response = [
                    "status" => "success",
                    "timestamp" => time(),
                ];
                http_response_code(200);
                echo json_encode($response);
            } else { 
                $response = [
                    "status" => "error",
                    "timestamp" => time(),
                    "message" => "Failed to add to favourites: " . $stmt->error
                ];
                http_response_code(500); 
                echo json_encode($response);
            }
        } else {
            $response = [
                "status" => "error",
                "timestamp" => time(),
                "message" => "Listing not found."
            ];
            http_response_code(404); 
            echo json_encode($response);
        }
        }
    }
    
    
    public function Register()
    {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $conn = $this->dbconnection;
            $post_body = json_decode(file_get_contents("php://input"), true);

            if (
                isset($post_body["type"]) &&
                $post_body["type"] === "Register"
            ) {
                // Check if any of the keys are entered
                $require_keys = ["name", "surname", "email", "password"];
                foreach ($require_keys as $key) {
                    if (!isset($post_body[$key])) {
                        $response = [
                            "status" => "error",
                            "message" =>
                                "Not all the required keys are filled in",
                        ];
                        $json_response = json_encode($response);
                        echo $json_response;
                        exit();
                    }
                }

                // After checking that all the keys are set, check that the values of the keys arent empty
                foreach ($require_keys as $key) {
                    if (empty($post_body[$key])) {
                        $response = [
                            "status" => "error",
                            "message" => "Some keys have empty values",
                        ];
                        $json_response = json_encode($response);
                        echo $json_response;
                        exit();
                    }
                }
                $name = $post_body["name"];
                $surname = $post_body["surname"];
                $email = $post_body["email"];
                //validate user, check if inputted details exist in the database
                $users_qeury = "Select name,surname from user_information where name = '$name' and surname ='$surname' and email = '$email'";
                $sql_users = mysqli_query($conn, $users_qeury);
                if ($sql_users) {
                    // Fetch rows from the result set
                    if (mysqli_num_rows($sql_users) > 0) {
                        $response = [
                            "status" => "error",
                            "message" => "User already exists",
                        ];
                        $json_response = json_encode($response);
                        echo $json_response;
                        exit();
                    }
                } else {
                    // Handle query error
                    echo "Error: " . mysqli_error($conn);
                }

                //Keys are set and values are entered, check specific cases
                //Test password
                if (!validatePassword($post_body["password"])) {
                    $response = [
                        "status" => "error",
                        "message" => "Password incorrect",
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
                // email
                if (!validateEmail($post_body["email"])) {
                    $response = [
                        "status" => "error",
                        "message" => "Invalid email",
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
                // name
                if (!validateName($post_body["name"])) {
                    $response = [
                        "status" => "error",
                        "message" => "Invalid name",
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
                // surname
                if (!validateSurname($post_body["surname"])) {
                    $response = [
                        "status" => "error",
                        "message" => "Invalid email",
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }

                

                //Get the name, surname, email and password + validate it

                // check email
                $email_query = "SELECT * FROM user_information WHERE email = '$email'";
                $email_result = mysqli_query($conn, $email_query);
                if ($email_result) {
                    if (mysqli_num_rows($email_result) > 0) {
                        $response = [
                            "status" => "error",
                            "message" => "Email already in use",
                        ];
                        $json_response = json_encode($response);
                        echo $json_response;
                        exit();
                    }
                } else {
                    echo "Problem with email qeury" . mysqli_error($conn);
                }
                $password = $post_body["password"];
                // Add salt to password
                
                $salt ="Jf4gK7hP2e" ;
                $password_with_salt =$password . $salt;
                $password_hash = sha1($password_with_salt);
                // create new api key
                $api_key = generateApiKey(15);

                // sanatize input :
                $name = mysqli_real_escape_string($conn, $name);
                $surname = mysqli_real_escape_string($conn, $surname);
                $email = mysqli_real_escape_string($conn, $email);
                $password = mysqli_real_escape_string($conn, $password_hash);
                // add this user to the database
                $sql = "INSERT INTO user_information (name,surname,email,password,api_key) VALUES ('$name','$surname','$email','$password','$api_key')";

                if (mysqli_query($conn, $sql)) {
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => [
                            "apikey" => $api_key
                        ]
                    ];
                    $_SESSION['apikey'] = $api_key;
                    $_SESSION['name'] = "$name";

                    http_response_code(200);
                    $json_response = json_encode($response);
                    echo $json_response;
                } else {
                    $error =
                        "Values was not inserted" . mysqli_error($conn);
                    $response = [
                        "status" => "error",
                        "message" => $error,
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            }
        } 
    }

    public function Login(){
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
        $require_keys = ['email', 'password'];
        foreach ($require_keys as $key) {
            // Check that all the required fields are entered
            if(!isset($post_body[$key])){
                $response = [
                    "status" => "error",
                    "timestamp"=> time(),
                    "message" =>
                        "Missing Parameters",
                ];
                $json_response = json_encode($response);
                echo $json_response;
                exit();
            }
        }
            // Check that the entered email and password is in the database
            $email = $post_body["email"];
            $password = $post_body["password"];
            $qeury_email = "Select * from loginInfo where email = '$email'";
            $response = mysqli_query($conn, $qeury_email);    
            if(mysqli_num_rows($response) > 0){
                // email is fine
                // check password
                $qeury_password = "Select user_id from loginInfo where email = '$email' AND password = '$password'";
                $response2 = mysqli_query($conn, $qeury_password);
                if(mysqli_num_rows($response2) > 0){
                    
                    
                    // password and email is correct
                    // get API key
                    $row = mysqli_fetch_assoc($response2);
                    $user_id = $row['user_id'];

                    
                    $_SESSION['user_id'] = $user_id;
                    // password is fine
                    $return = [
                        "status" => "success",
                        "timestamp"=> time(),
                        "data" =>  $user_id
                    ];
                    $json_response = json_encode($return);
                    http_response_code(200);
	                // header("Content-Type: application/json");
                    echo $json_response;

                    
                    // exit();
                } else {
                    // Password was incorrect
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "Password incorrect"
                    ];
                    $json_response = json_encode($response);
                    echo $json_response;
                    exit();
                }
            } else {
                // email was incorrect
                $response = [
                    "status" => "error",
                    "timestamp" => time(),
                    "message" => "Email does not exist"
                ];
                $json_response = json_encode($response);
                echo $json_response;
                exit();
            }
    }

    public function GetMovies()
    {
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
            // Check that the entered email and password is in the database
            $query_movies = "SELECT * FROM movies";
            $response = mysqli_query($conn, $query_movies);
    
            if(isset($post_body['movie'])){
                $name = $post_body['movie'];
                $name = $this->dbconnection->real_escape_string($name); // Sanitize input to prevent SQL injection

                $query_movies = "SELECT * FROM movies WHERE Title LIKE '%$name%'";
                $response = mysqli_query($this->dbconnection, $query_movies);

                if (mysqli_num_rows($response) > 0) {
                    $movies = [];

                    while ($row = mysqli_fetch_assoc($response)) {
                        $movies[] = $row;
                    }

                    // Success response with movies data
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $movies
                    ];
                } else {
                    // No movies found
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "No movies found"
                    ];
                }

                // Output the response as JSON
                echo json_encode($response);
            } else {
                if (mysqli_num_rows($response) > 0) {
                    $movies = [];
        
                    while ($row = mysqli_fetch_assoc($response)) {
                        $movies[] = $row;
                    }
        
                    // Success response with movies data
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $movies
                    ];
                } else {
                    // No movies found
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "No movies found"
                    ];
                }
        
                // Output the response as JSON
                echo json_encode($response);
            }
    }
    
    public function GetSeries()
    {
        $conn = $this->dbconnection;
        $post_body = json_decode(file_get_contents("php://input"), true);
            // Check that the entered email and password is in the database
            
    
            if(isset($post_body['series'])){
                $name = $post_body['series'];
                $name = $this->dbconnection->real_escape_string($name); // Sanitize input to prevent SQL injection

                $query_movies = "SELECT * FROM series WHERE Title LIKE '%$name%'";
                $response = mysqli_query($this->dbconnection, $query_movies);

                if (mysqli_num_rows($response) > 0) {
                    $movies = [];

                    while ($row = mysqli_fetch_assoc($response)) {
                        $movies[] = $row;
                    }

                    // Success response with movies data
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $movies
                    ];
                } else {
                    // No movies found
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "No movies found"
                    ];
                }

                // Output the response as JSON
                echo json_encode($response);
            } else {
                $query_movies = "SELECT * FROM series";
                $response = mysqli_query($conn, $query_movies);
                if (mysqli_num_rows($response) > 0) {
                    $movies = [];
        
                    while ($row = mysqli_fetch_assoc($response)) {
                        $movies[] = $row;
                    }
        
                    // Success response with movies data
                    $response = [
                        "status" => "success",
                        "timestamp" => time(),
                        "data" => $movies
                    ];
                } else {
                    // No movies found
                    $response = [
                        "status" => "error",
                        "timestamp" => time(),
                        "message" => "No movies found"
                    ];
                }
        
                // Output the response as JSON
                echo json_encode($response);
            }
    }
}

function generateApiKey($length = 15)
{
    $characters =
        "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $apiKey = "";
    $maxIndex = strlen($characters) - 1;

    for ($i = 0; $i < $length; $i++) {
        $apiKey .= $characters[rand(0, $maxIndex)];
    }

    return $apiKey;
}

function validateName($name)
{
    $regexName = "/^([a-zA-Z]+$)/";
    if (preg_match($regexName, $name)) {
        return true;
    } else {
        return false;
    }
}
function validateSurname($surname)
{
    $regexSurnane = "/^([a-zA-Z]+$)/";
    if (preg_match($regexSurnane, $surname)) {
        return true;
    } else {
        return false;
    }
}
function validatePassword($password)
{
    $regexPass =
        "/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+])(?=.*[a-zA-Z]).{8,}$/";
    if (preg_match($regexPass, $password)) {
        return true;
    } else {
        return false;
    }
}
function validateEmail($email)
{
    if (
        preg_match(
            "/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$/",
            $email
        )
    ) {
        return true;
    } else {
        return false;
    }
}
